# Changelog

All notable changes to apptio-mcp are written here. The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and the project uses [Semantic Versioning](https://semver.org/).

## [0.2.1] - 2026-11-25

### Changed

- The README now links the landing page's `llms.txt` and `summary.md`, so people and agents can find the install guides from GitHub.

## [0.2.0] - 2026-11-25

### Added

- Choose your mapping file and your spend rules file in the settings card, not only in Terminal: pick a file or type its path, see what was imported, and remove it. The same card steps show on the final screen.
- Optional spend rules: `spend-rules import | show | clear` (and the card) check a `spend.toml` the way the server uses it, refuse one that wouldn't work, and name any keys that are ignored.
- `mapping clear` removes the imported mapping file.

### Changed

- When the mapping file is missing, the spend tools and `cloudability_setup_status` now say to import it in the settings card, or run the command.
- Files named by path must be absolute paths to regular files, and a file's size is checked before it is read. Errors never repeat the path or the file's content.

## [0.1.1] - 2026-11-25

### Fixed

- The installer's `--status` now reports the server as running once Claude Desktop has started it. It read the start time from the wrong place in Desktop's log, so it always said "hasn't started" and kept asking you to restart.
- The page no longer scrolls sideways on a phone: two long web addresses in the text are now short links.

## [0.1.0] - 2026-11-24

First release.

### Added

- Ask Claude about your cloud spend. apptio-mcp is a local MCP server for Claude Desktop and Claude Code that reads your Apptio Cloudability data as you. Everything it does is read-only.
- 19 Cloudability tools: views, business mappings, budgets, anomalies, cost reports, forecasts, a summary, and five spend tools (spend by platform or project, a category breakdown, and platform and project lookups).
- A setup card in Claude Desktop. It takes your Apptio key pair and environment ID (encrypted before it leaves the card), checks them with Apptio, lets you review the Frontdoor and region defaults, and lets you choose your default view. It opens again until setup is finished.
- A `login` command for Terminal, and for Claude Code, which has no cards.
- Your key is kept only in your macOS login Keychain, and never in a file, the Claude Desktop config, a log or the chat.
- Bring your own mapping file: `mapping import` checks it and keeps a private copy on your Mac. Only the five spend tools need it. The landing page publishes the format and a made-up example.
- `cloudability_setup_status`, which shows what is missing and the next step, without ever showing the key.
- Owner emails are hidden in every result by default.
- A one-command installer, `install.sh`. It asks every question first (or none, with `--no-input`), checks the download's SHA-256, installs into its own folder, and adds a `cloudability` entry to Claude Desktop's config after making a backup. It never quits Claude Desktop. `--dry-run` shows what it would change without changing anything, `--status` shows the install, and `--uninstall` removes it.
- A daily update check that only warns. It fetches `latest.version` from the landing page and never installs anything.
- A landing page, `summary.md` and `llms.txt`, built from the README, with a guide for people and one for AI agents.

### Fixed

- Cost reports now apply the filters you give them.
- Anomalies use your chosen view, and the summary counts budgets correctly and no longer assumes a year.
- The three cluster tools say they are not available yet: Cloudability retired the old cluster endpoint and its replacement needs parameters this version doesn't support. They return that message instead of an error.
- A business mapping is found by exact name first, and when several match you get the candidates back.
- Two unused tools were removed.

### Security

- Only GET requests, plus the login POST (the key pair goes to the Apptio login host only), to a fixed list of Apptio hosts. Redirects to other hosts are never followed.
- Defaults are limited to Frontdoor EU and region US. No view number or team name is built into the code.
