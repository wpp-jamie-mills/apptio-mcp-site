"""Sealing for the setup card: hybrid RSA-OAEP-3072 + AES-256-GCM.

The server makes an RSA key per key step and sends only the SPKI DER (base64) to the card. The card encrypts
`{"public_key", "secret_key"}` with a fresh AES-256-GCM key (tag appended) and wraps that key with RSA-OAEP
(MGF1-SHA256, SHA-256). Every failure raises `SealError` with fixed text: nothing about the input leaks.
"""
from __future__ import annotations

import base64
import binascii
import json

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from .keychain import key_ok

ALG = "RSA-OAEP-3072-SHA256"
RSA_BITS = 3072
MAX_SEALED_BYTES = 64 * 1024
_IV_LEN = 12
_AES_KEY_LEN = 32
_TAG_LEN = 16
_TEXT = "The sealed key could not be opened."


class SealError(Exception):
    def __init__(self) -> None:
        super().__init__(_TEXT)


def new_seal_key() -> tuple[str, str]:
    """(private key PEM, SPKI DER as base64). The PEM goes only into the token record."""
    key = rsa.generate_private_key(public_exponent=65537, key_size=RSA_BITS)
    pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                            serialization.NoEncryption()).decode("ascii")
    spki = key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
    return pem, base64.b64encode(spki).decode("ascii")


def _b64(value: object, *, exact: int | None = None, at_least: int = 1) -> bytes:
    if not isinstance(value, str):
        raise SealError
    try:
        raw = base64.b64decode(value, validate=True)
    except (binascii.Error, ValueError):
        raise SealError from None
    if (exact is not None and len(raw) != exact) or len(raw) < at_least:
        raise SealError
    return raw


def open_sealed(sealed_json: str, private_pem: str) -> tuple[str, str]:
    """Decrypt the card's JSON envelope; return (public_key, secret_key). Raises SealError on ANY failure."""
    try:
        if not isinstance(sealed_json, str) or not isinstance(private_pem, str):
            raise SealError
        if len(sealed_json.encode("utf-8")) > MAX_SEALED_BYTES:
            raise SealError
        env = json.loads(sealed_json)
        if not isinstance(env, dict) or env.get("v") != 1:
            raise SealError
        wrapped = _b64(env.get("wrapped_key"), exact=RSA_BITS // 8)
        iv = _b64(env.get("iv"), exact=_IV_LEN)
        ciphertext = _b64(env.get("ciphertext"), at_least=_TAG_LEN + 1)
        private = serialization.load_pem_private_key(private_pem.encode("ascii"), password=None)
        if not isinstance(private, rsa.RSAPrivateKey):
            raise SealError
        aes_key = private.decrypt(wrapped, padding.OAEP(mgf=padding.MGF1(hashes.SHA256()),
                                                         algorithm=hashes.SHA256(), label=None))
        if len(aes_key) != _AES_KEY_LEN:
            raise SealError
        data = json.loads(AESGCM(aes_key).decrypt(iv, ciphertext, None).decode("utf-8"))
        public, secret = data["public_key"], data["secret_key"]
        if not (isinstance(public, str) and isinstance(secret, str) and public and secret):
            raise SealError
        if not key_ok(public, secret):  # at most 512 plain characters each (the Keychain line limit)
            raise SealError
        return public, secret
    except SealError:
        raise SealError from None
    except Exception:  # noqa: BLE001 - any failure, whatever its cause, becomes the same fixed error
        raise SealError from None
