"""One-time tokens for the setup card.

Records are files in `<data>/settings-tokens/`, named by the token's SHA-256 (the token itself is never stored), so a
token issued by one server process works in another. A record is `{kind, expires, seal_key_pem?}`: the sealing private
key lives only here, until the card's keys are decrypted (`delete_seal_key`) or the record is taken or expires.
Taking or claiming a token renames its file first, which only one process can do, so a token works exactly once.
A claim keeps the record out of reach of every other request while it is acted on; it is either burned or put back.
"""
from __future__ import annotations

import hashlib
import json
import os
import secrets
import subprocess
import threading
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from .paths import atomic_write, data_dir, private_dir

TTL_S = 900
LIMIT = 50
EXPIRED = ("This card has expired or was already used; nothing was saved. "
           "Ask Claude to open the Cloudability settings again.")
FOLDER_NAME = "settings-tokens"


class TokenError(Exception):
    def __init__(self) -> None:
        super().__init__(EXPIRED)


def _exclude_from_backup(folder: Path) -> None:
    """Best effort and silent: keep the folder out of Time Machine. Skipped under tests."""
    if os.environ.get("APPTIO_MCP_SKIP_TMUTIL") or os.environ.get("PYTEST_CURRENT_TEST"):
        return
    try:
        subprocess.run(["/usr/bin/tmutil", "addexclusion", str(folder)], capture_output=True, timeout=5, check=False)
    except Exception:  # noqa: BLE001, S110
        pass


class Claim:
    """A token taken out of the store for the length of one request. `burn()` deletes it for good; `release()` puts
    it back (a refusal that must keep the token). Whichever is not called by the end is `release()`."""

    def __init__(self, record: dict[str, Any], path: Path, claimed: Path) -> None:
        self.record = record
        self._path, self._claimed = path, claimed
        self._open = True

    def burn(self) -> None:
        if self._open:
            self._open = False
            self._claimed.unlink(missing_ok=True)

    def release(self) -> None:
        if self._open:
            self._open = False
            try:
                if self._path.exists():
                    self._claimed.unlink(missing_ok=True)
                else:
                    os.rename(self._claimed, self._path)
            except OSError:
                self._claimed.unlink(missing_ok=True)


class OneTimeTokens:
    def __init__(self, folder: Path | None = None, clock: Callable[[], float] = time.time, ttl: float = TTL_S,
                 limit: int = LIMIT) -> None:
        self._folder = Path(folder) if folder is not None else None
        self._clock, self._ttl, self._limit = clock, ttl, limit
        self._excluded = False
        self.prune()

    @property
    def folder(self) -> Path:
        return self._folder if self._folder is not None else data_dir() / FOLDER_NAME

    def _ensure(self) -> Path:
        folder = private_dir(self.folder)
        if not self._excluded:
            _exclude_from_backup(folder)
            self._excluded = True
        return folder

    def _path(self, token: str) -> Path:
        return self.folder / (hashlib.sha256(str(token or "").encode()).hexdigest() + ".json")

    def _read(self, path: Path) -> dict[str, Any] | None:
        try:
            record = json.loads(path.read_text(encoding="utf-8"))
        except OSError:
            return None
        except ValueError:  # an unparseable record is garbage: remove it
            path.unlink(missing_ok=True)
            return None
        try:
            expires = float(record.get("expires") or 0) if isinstance(record, dict) else 0.0
        except (TypeError, ValueError):
            expires = 0.0
        if expires < self._clock():
            path.unlink(missing_ok=True)
            return None
        return record

    def prune(self) -> None:
        """Delete expired records, leftovers of interrupted writes or claims, and the oldest beyond the limit."""
        folder = self.folder
        if not folder.is_dir():
            return
        live: list = []
        for f in folder.glob("*"):
            if not f.name.endswith(".json"):
                try:
                    if time.time() - f.stat().st_mtime > self._ttl:
                        f.unlink(missing_ok=True)
                except OSError:
                    pass
                continue
            record = self._read(f)
            if record is not None:
                live.append((float(record["expires"]), f.name, f))
        for _, _, f in sorted(live)[: max(0, len(live) - self._limit + 1)]:
            f.unlink(missing_ok=True)

    def issue(self, seal_key_pem: str | None = None) -> str:
        self._ensure()
        self.prune()
        token = secrets.token_urlsafe(16)  # 128 bits
        record: dict[str, Any] = {"kind": "settings", "expires": self._clock() + self._ttl}
        if seal_key_pem:
            record["seal_key_pem"] = seal_key_pem
        atomic_write(self._path(token), json.dumps(record))
        return token

    def peek(self, token: str) -> dict[str, Any]:
        """The token's record, left in place (validate a request before using the token)."""
        self.prune()
        record = self._read(self._path(token)) if token and isinstance(token, str) else None
        if record is None:
            raise TokenError
        return record

    def take(self, token: str) -> dict[str, Any]:
        """The token's record, removed: a token works once, whichever process it reaches."""
        if not token or not isinstance(token, str):
            raise TokenError
        path = self._path(token)
        claimed = path.with_name(f"{path.name}.taken-{os.getpid()}-{threading.get_ident()}")
        try:
            os.rename(path, claimed)  # atomic: only one claimant succeeds
        except OSError:
            raise TokenError from None
        try:
            record = self._read(claimed)
        finally:
            claimed.unlink(missing_ok=True)
        if record is None:
            raise TokenError
        return record

    def claim(self, token: str) -> Claim:
        """Take the token out of the store by an atomic rename BEFORE acting on a request. Only one claimant can
        succeed, so concurrent requests with one token cannot both act."""
        if not token or not isinstance(token, str):
            raise TokenError
        path = self._path(token)
        claimed = path.with_name(f"{path.name}.claim-{os.getpid()}-{threading.get_ident()}-{secrets.token_hex(4)}")
        try:
            os.rename(path, claimed)
        except OSError:
            raise TokenError from None
        record = self._read(claimed)
        if record is None:
            claimed.unlink(missing_ok=True)
            raise TokenError
        return Claim(record, path, claimed)

    def delete_seal_key(self, token: str) -> None:
        """Rewrite the record without its sealing private key (straight after decryption)."""
        record = self.peek(token)
        record.pop("seal_key_pem", None)
        atomic_write(self._path(token), json.dumps(record))

    def clear_all(self) -> None:
        import shutil
        folder = self.folder
        if folder.is_dir() and not folder.is_symlink():
            shutil.rmtree(folder, ignore_errors=True)


def clear_all() -> None:
    """Delete every token record (used by logout)."""
    OneTimeTokens().clear_all()
