"""Import, validate and describe the user's mapping file.

The file maps PAM platforms to cloud subscriptions. None ships with the product: each person imports their own.
`show()` returns counts only, never rows."""
from __future__ import annotations

import csv
import io
from pathlib import Path

from . import filepick
from .paths import atomic_write, data_dir

HEADER = ["PAM Platform", "Cloud Provider", "Cloud subscription"]
MAX_BYTES = 5 * 1024 * 1024
MAX_CELL = 200
IMPORT_COMMAND = "~/.apptio-mcp/current/bin/apptio-mcp mapping import <file>"
IMPORT_HINT = f"Import it in the settings card (ask Claude to open Cloudability settings) or run: {IMPORT_COMMAND}"
FILE_NAME = "mapping.csv"


class MappingError(ValueError):
    """Names the problem (by line number, never by cell value) and how to import."""

    def __init__(self, problem: str):
        self.problem = problem
        super().__init__(f"{problem} {IMPORT_HINT}")


def mapping_path() -> Path:
    return data_dir() / FILE_NAME


def _has_control(text: str) -> bool:
    return any(ord(c) < 32 or ord(c) == 127 for c in text)


def _validate(raw: bytes) -> list[list[str]]:
    """Return the cleaned data rows (stripped cells) or raise MappingError."""
    if len(raw) > MAX_BYTES:
        raise MappingError("The mapping file is larger than 5 MB.")
    try:
        text = raw.decode("utf-8-sig")  # strips a UTF-8 BOM
    except UnicodeDecodeError:
        raise MappingError("The mapping file is not valid UTF-8.") from None
    try:
        reader = csv.reader(io.StringIO(text, newline=""), strict=True)
        records = list(reader)
    except csv.Error:
        raise MappingError("The mapping file is not valid CSV.") from None
    if not records or records[0] != HEADER:
        raise MappingError("The first line must be exactly: " + ",".join(HEADER) + ".")
    rows: list[list[str]] = []
    seen: set[tuple[str, ...]] = set()
    for line_no, rec in enumerate(records[1:], start=2):
        if not rec:  # a blank line
            continue
        if len(rec) != len(HEADER):
            raise MappingError(f"Line {line_no} must have exactly {len(HEADER)} columns.")
        for cell in rec:
            if _has_control(cell):
                raise MappingError(f"Line {line_no} contains a control character.")
            if len(cell) > MAX_CELL:
                raise MappingError(f"Line {line_no} has a cell longer than {MAX_CELL} characters.")
        cells = [c.strip() for c in rec]
        if not all(cells):
            raise MappingError(f"Line {line_no} has an empty cell.")
        key = tuple(cells)
        if key in seen:
            raise MappingError(f"Line {line_no} repeats an earlier row.")
        seen.add(key)
        rows.append(cells)
    if not rows:
        raise MappingError("The mapping file has no data rows.")
    return rows


def _counts(rows: list[list[str]]) -> dict:
    return {"rows": len(rows), "platforms": len({r[0] for r in rows})}


def import_content(raw: bytes | str) -> dict:
    """Validate the file's content, store it atomically at 0600 in the data folder, and return counts only."""
    if isinstance(raw, str):
        try:
            raw = raw.encode("utf-8")
        except UnicodeEncodeError:
            raise MappingError("The mapping file is not valid UTF-8.") from None
    rows = _validate(raw)
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    writer.writerow(HEADER)
    writer.writerows(rows)
    atomic_write(mapping_path(), out.getvalue())
    return _counts(rows)


def import_file(src: Path | str) -> dict:
    """Read the file at the absolute path `src`, then import its content."""
    try:
        raw = filepick.read_file(src, MAX_BYTES)
    except filepick.FilePickError as e:
        raise MappingError(str(e)) from None
    return import_content(raw)


def clear() -> dict:
    """Remove the imported mapping file. -> {"removed": bool}."""
    try:
        mapping_path().unlink()
    except FileNotFoundError:
        return {"removed": False}
    return {"removed": True}


def show() -> dict:
    """Counts only (never rows), or {"imported": false}."""
    path = mapping_path()
    try:
        raw = path.read_bytes()
    except OSError:
        return {"imported": False}
    try:
        return {"imported": True, **_counts(_validate(raw))}
    except MappingError as e:
        return {"imported": False, "error": e.problem}
