"""Cloudability API v3 client (read-only) and the key-check probes.

Key pair only: the pair is exchanged at Apptio Frontdoor for a short-lived opentoken. Every request is sent with
redirects off. Data calls are GET only; the single POST is the Frontdoor login. Error text never carries query
strings, header values, tokens or keys.
"""
from __future__ import annotations

import os
import random
import re
import threading
import time
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor, wait
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import quote, urljoin, urlsplit

import requests

from . import config as settings

LOGIN_PATH = "/service/apikeylogin"
TOKEN_HEADER = "apptio-opentoken"
ENVIRONMENT_HEADER = "apptio-environmentid"

RETRY_STATUSES = (429, 500, 502, 503, 504)
ASYNC_RETRIES = 4
RETRY_BASE_S = 1.0
RETRY_MAX_S = 30.0
CALL_DEADLINE_S = 110.0  # overall per-call deadline; Claude Desktop stops waiting at 140 s (measured)
MAX_REDIRECTS = 3
REDIRECT_STATUSES = (301, 302, 303, 307, 308)
PROBE_TIMEOUT = (3, 8)
VERIFY_DEADLINE_S = 40.0
# Known login error codes that are safe to show; anything else is dropped (never echo a body).
KNOWN_AUTH_CODES = frozenset({
    "invalid_credentials", "invalid_key", "invalid_request", "unauthorized", "forbidden", "expired", "locked",
})
IN_PROGRESS_STATES = frozenset({
    "queued", "pending", "running", "in_progress", "in progress", "inprogress", "enqueued", "processing",
    "started", "waiting", "submitted", "created", "new",
    "saving",  # seen live 2026-11-23: transient state between running and finished
})
FAILED_STATES = frozenset({"failed", "error", "cancelled", "canceled"})
MAX_RESULT_PAGES = 1000

_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$", re.ASCII)
_NUMERIC_RE = re.compile(r"^[0-9]{1,64}$")


# ── Errors (fixed text only) ─────────────────────────────────────────────

class CloudabilityAuthError(RuntimeError):
    """The Apptio Frontdoor login failed. Never contains secrets."""


class UnexpectedRedirect(CloudabilityAuthError):
    """A 3xx where none is allowed, or a redirect off the allow-listed host."""

    def __init__(self) -> None:
        super().__init__("unexpected_redirect")


class ReadOnlyViolation(RuntimeError):
    """Any verb other than GET (the Frontdoor login is not routed through the data client)."""


class InvalidIdentifier(ValueError):
    """A model-supplied ID that is not safe to place in a URL path."""


class DisallowedHost(RuntimeError):
    """A URL that is not https on an allow-listed Apptio host."""


class DeadlineExceeded(RuntimeError):
    """The per-call deadline ran out. `partial` holds any rows gathered so far."""

    def __init__(self, message: str = "Cloudability call deadline exceeded", partial: list | None = None) -> None:
        super().__init__(message)
        self.partial = partial


class CloudabilityHTTPError(requests.exceptions.HTTPError):
    """HTTP error status. The text holds the status and path only (no query string, headers or body)."""

    def __init__(self, status_code: int, path: str) -> None:
        super().__init__(f"Cloudability API request failed: HTTP {status_code} for {path}")
        self.status_code = status_code


class CloudabilityTimeout(requests.exceptions.Timeout):
    pass


class CloudabilityConnectionError(requests.exceptions.ConnectionError):
    pass


_TIMEOUT_TEXT = "Could not reach Apptio Cloudability: the request timed out"
_CONNECTION_TEXT = "Could not reach Apptio Cloudability: connection failed"


# ── HTTP helpers ─────────────────────────────────────────────────────────

def make_session() -> requests.Session:
    """A session that ignores the environment: no HTTPS_PROXY, REQUESTS_CA_BUNDLE, CURL_CA_BUNDLE or .netrc.
    Keys and opentokens must go only where the allow-list says, over the default certificate store."""
    session = requests.Session()
    session.trust_env = False
    return session


def http_post(url: str, **kwargs: Any) -> Any:
    session = make_session()
    try:
        return session.post(url, **kwargs)
    finally:
        session.close()


def http_get(url: str, **kwargs: Any) -> Any:
    session = make_session()
    if kwargs.get("stream"):
        return session.get(url, **kwargs)  # the caller closes the response; the session is collected with it
    try:
        return session.get(url, **kwargs)
    finally:
        session.close()


# ── Allow-list helpers ───────────────────────────────────────────────────

def _origin_ok(url: str, allowed: tuple[str, ...]) -> bool:
    """https, no credentials or port, and the origin is exactly one of `allowed`."""
    try:
        parts = urlsplit(url)
        host, port, user = parts.hostname, parts.port, parts.username
    except ValueError:
        return False
    return parts.scheme == "https" and bool(host) and port is None and user is None and f"https://{host}" in allowed


def _check_url(url: str, allowed: tuple[str, ...]) -> None:
    if not _origin_ok(url, allowed):
        raise DisallowedHost("Refusing to call a host that is not an allow-listed Apptio endpoint")


def _seg(value: Any, numeric: bool = False) -> str:
    """Validate and quote one model-supplied path segment."""
    text = str(value)
    if not (_NUMERIC_RE if numeric else _ID_RE).fullmatch(text):
        raise InvalidIdentifier("Invalid identifier: expected " + ("digits only" if numeric else "letters, digits, - or _"))
    return quote(text, safe="")


def _auth_code(response: Any) -> str:
    try:
        data = response.json()
    except Exception:  # noqa: BLE001
        return ""
    if isinstance(data, dict):
        code = data.get("error") or data.get("code")
        if isinstance(code, str) and code.strip().lower() in KNOWN_AUTH_CODES:
            return code.strip().lower()
    return ""


def _path_only(url: str) -> str:
    return urlsplit(url).path


# ── Configuration ────────────────────────────────────────────────────────

@dataclass
class CloudabilityConfig:
    """Key pair, environment and hosts. Hosts must come from config's allow-lists."""

    public_key: str = field(repr=False)
    secret_key: str = field(repr=False)
    environment_id: str = field(repr=False)
    frontdoor_url: str = settings.DEFAULT_FRONTDOOR
    region: str = settings.DEFAULT_REGION
    base_url: str = field(init=False, default="")

    def __post_init__(self) -> None:
        if not (self.public_key and self.secret_key and self.environment_id):
            raise ValueError("public_key, secret_key and environment_id are all required")
        self.environment_id = settings.validate("environment_id", self.environment_id)
        self.frontdoor_url = settings.validate("frontdoor_url", self.frontdoor_url)
        region = str(self.region).strip().lower()
        if region not in settings.REGIONS:
            raise ValueError("Unknown region: expected one of " + ", ".join(settings.REGIONS))
        self.region = region
        self.base_url = settings.REGIONS[region]

    @classmethod
    def from_env(cls) -> CloudabilityConfig:
        """Key pair from APPTIO_PUBLIC_KEY / APPTIO_SECRET_KEY / APPTIO_ENVIRONMENT_ID (used by `login --from-env`)."""
        public_key = os.getenv("APPTIO_PUBLIC_KEY")
        secret_key = os.getenv("APPTIO_SECRET_KEY")
        environment_id = os.getenv("APPTIO_ENVIRONMENT_ID")
        if not (public_key and secret_key and environment_id):
            raise ValueError(
                "Apptio credentials not found in environment: set APPTIO_PUBLIC_KEY, APPTIO_SECRET_KEY "
                "and APPTIO_ENVIRONMENT_ID."
            )
        return cls(
            public_key=public_key,
            secret_key=secret_key,
            environment_id=environment_id,
            frontdoor_url=os.getenv("APPTIO_FRONTDOOR_URL") or settings.DEFAULT_FRONTDOOR,
            region=os.getenv("CLOUDABILITY_REGION") or settings.DEFAULT_REGION,
        )


def _as_filter_list(filters: str | list[str]) -> list[str]:
    """Normalise a filter argument to a list (sent as repeated `filters` params)."""
    if isinstance(filters, str):
        return [filters]
    return [f for f in filters if f]


# ── Data client ──────────────────────────────────────────────────────────

class CloudabilityClient:
    """Read-only client for Cloudability API v3."""

    def __init__(self, config: CloudabilityConfig, default_view_id: str | int | None = None,
                 key_reloader: Callable[[], tuple[str, str] | None] | None = None):
        self.config = config
        self._key_reloader = key_reloader
        self.default_view_id = str(default_view_id) if default_view_id not in (None, "") else None
        self._base_url = config.base_url
        self._frontdoor_url = config.frontdoor_url
        self.session = make_session()
        self._token: str | None = None
        self._login_lock = threading.Lock()
        self.session.headers.update({"Accept": "application/json", ENVIRONMENT_HEADER: config.environment_id})

    def __repr__(self) -> str:
        return f"<CloudabilityClient region={self.config.region}>"  # never the session: it holds the opentoken

    def _reload_key(self) -> None:
        """After a 401 the stored key may have been replaced by another process: ask the owner of the key store
        for the current pair once, and use it for the retry. Any failure keeps the key we have."""
        if self._key_reloader is None:
            return
        try:
            pair = self._key_reloader()
        except Exception:  # noqa: BLE001 - the retry simply uses the key we already hold
            return
        if pair and pair[0] and pair[1]:
            self.config.public_key, self.config.secret_key = pair

    # -- login --

    def _ensure_token(self, stale: str | None = None) -> None:
        """Log in only if needed, checked under the lock so concurrent callers share one login: no token yet,
        or the token is still the stale one that just got a 401."""
        with self._login_lock:
            if self._token is None or (stale is not None and self._token == stale):
                if stale is not None:
                    self._reload_key()
                self._login_locked()

    def _login_locked(self) -> None:
        _check_url(self._frontdoor_url, settings.FRONTDOOR_HOSTS)
        try:
            response = http_post(
                f"{self._frontdoor_url}{LOGIN_PATH}",
                json={"keyAccess": self.config.public_key, "keySecret": self.config.secret_key},
                headers={"Content-Type": "application/json", "Accept": "application/json"},
                timeout=30,
                allow_redirects=False,
            )
        except requests.exceptions.Timeout:
            raise CloudabilityAuthError("Apptio Frontdoor login failed: timeout") from None
        except requests.exceptions.RequestException:
            raise CloudabilityAuthError("Apptio Frontdoor login failed: connection error") from None
        if 300 <= response.status_code < 400:
            raise UnexpectedRedirect()
        if response.status_code != 200:
            code = _auth_code(response)
            raise CloudabilityAuthError(
                f"Apptio Frontdoor login failed: HTTP {response.status_code}" + (f" ({code})" if code else "")
            )
        token = response.headers.get(TOKEN_HEADER)
        if not token:
            raise CloudabilityAuthError(f"Apptio Frontdoor login returned HTTP 200 but no {TOKEN_HEADER} header")
        # Header first: another thread that sees the new _token must find the matching header.
        self.session.headers[TOKEN_HEADER] = token
        self._token = token

    @staticmethod
    def _retry_delay(attempt: int, response: Any = None) -> float:
        """Exponential backoff with jitter; honours a numeric Retry-After header."""
        delay = min(RETRY_MAX_S, RETRY_BASE_S * (2 ** attempt)) * random.uniform(0.5, 1.0)
        headers = getattr(response, "headers", None) or {}
        try:
            ra = float(headers.get("Retry-After", ""))
        except (TypeError, ValueError):
            ra = 0.0
        return max(delay, min(ra, 120.0))

    # -- transport --

    def _get_following(self, url: str, params: dict | None, timeout: float) -> Any:
        """One GET, following at most MAX_REDIRECTS 3xx hops manually. The apptio-* headers ride along only
        because every hop must be https on the same allow-listed host; anything else raises."""
        origin = urlsplit(url).netloc
        for hop in range(MAX_REDIRECTS + 1):
            response = self.session.request("GET", url, params=params if hop == 0 else None,
                                            timeout=timeout, allow_redirects=False)
            if not 300 <= response.status_code < 400:
                return response
            location = response.headers.get("Location") or ""
            if response.status_code not in REDIRECT_STATUSES or hop == MAX_REDIRECTS or not location:
                raise UnexpectedRedirect()
            url = urljoin(url, location)
            if urlsplit(url).netloc != origin or not _origin_ok(url, settings.API_HOSTS):
                raise UnexpectedRedirect()
        raise UnexpectedRedirect()  # pragma: no cover

    def _request(
        self,
        method: str,
        endpoint: str,
        params: dict | None = None,
        timeout: float = 30,
        retries: int = 0,
        deadline: float | None = None,
    ) -> dict[str, Any]:
        """GET `endpoint` under the region's base URL and return the parsed JSON.

        `deadline` is an absolute time.monotonic() value (default: now + CALL_DEADLINE_S). No attempt starts after
        it, no retry waits past it, and each attempt's timeout is capped to what remains; DeadlineExceeded is
        raised instead. retries > 0 retries 429, 5xx, timeouts and connection errors with backoff and jitter."""
        if method.upper() != "GET":
            raise ReadOnlyViolation("Only GET requests are allowed")
        url = f"{self._base_url}{endpoint}"
        if not _origin_ok(url, settings.API_HOSTS):
            raise DisallowedHost("Refusing to call a host that is not an allow-listed Apptio endpoint")
        if deadline is None:
            deadline = time.monotonic() + CALL_DEADLINE_S
        if self._token is None:
            self._ensure_token()

        attempt = 0
        reauthed = False
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise DeadlineExceeded()
            sent_token = self._token
            try:
                response = self._get_following(url, params, max(1, min(timeout, remaining)))
            except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as exc:
                timed_out = isinstance(exc, requests.exceptions.Timeout)
                delay = self._retry_delay(attempt)
                if attempt >= retries:
                    raise (CloudabilityTimeout(_TIMEOUT_TEXT) if timed_out
                           else CloudabilityConnectionError(_CONNECTION_TEXT)) from None
                if time.monotonic() + delay >= deadline:
                    raise DeadlineExceeded() from None
                time.sleep(delay)
                attempt += 1
                continue
            if response.status_code == 401 and not reauthed:
                reauthed = True
                self._ensure_token(stale=sent_token)
                continue
            if response.status_code in RETRY_STATUSES and attempt < retries:
                delay = self._retry_delay(attempt, response)
                if time.monotonic() + delay < deadline:
                    time.sleep(delay)
                    attempt += 1
                    continue
                raise DeadlineExceeded()
            if response.status_code >= 400:
                raise CloudabilityHTTPError(response.status_code, _path_only(url))
            try:
                return response.json()
            except ValueError:
                raise CloudabilityHTTPError(response.status_code, _path_only(url)) from None

    def _view(self, view_id: str | int | None) -> str:
        chosen = view_id if view_id not in (None, "") else self.default_view_id
        if chosen is None:
            raise ValueError("view_id is required: pass one or configure a default view")
        return str(chosen)

    # ── Budgets ──────────────────────────────────────────────────────────

    def get_budgets(
        self,
        limit: int = 50,
        offset: int = 0,
        filters: str | list[str] | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if filters:
            params["filters"] = _as_filter_list(filters)
        return self._request("GET", "/budgets", params)

    def get_budget(self, budget_id: str) -> dict[str, Any]:
        return self._request("GET", f"/budgets/{_seg(budget_id)}")

    # ── Views ────────────────────────────────────────────────────────────

    def get_views(self) -> dict[str, Any]:
        return self._request("GET", "/views")

    def get_view(self, view_id: str) -> dict[str, Any]:
        return self._request("GET", f"/views/{_seg(view_id, numeric=True)}")

    # ── Business Mappings ────────────────────────────────────────────────

    def get_business_mappings(self) -> dict[str, Any]:
        return self._request("GET", "/business-mappings")

    def get_business_mapping(self, index: int) -> dict[str, Any]:
        return self._request("GET", f"/business-mappings/{_seg(index, numeric=True)}")

    # ── Anomalies ────────────────────────────────────────────────────────

    def get_anomalies(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
        view_id: str | int | None = None,
    ) -> dict[str, Any]:
        """Cost anomalies detected by Cloudability ML.

        Args:
            start_date: Start of the date range in YYYY-MM-DD format (required for results).
            end_date: End of the date range in YYYY-MM-DD format (required for results).
            view_id: View to scope to; falls back to the client's default view, and is omitted if neither is set.
        """
        params: dict[str, Any] = {}
        if start_date:
            params["startDate"] = start_date
        if end_date:
            params["endDate"] = end_date
        view = view_id if view_id not in (None, "") else self.default_view_id
        if view is not None:
            params["viewId"] = str(view)
        return self._request("GET", "/anomalies", params=params or None)

    # ── Forecast ─────────────────────────────────────────────────────────

    def get_forecast(
        self,
        view_id: str | int | None = None,
        basis: str = "amortized",
        months_forward: int = 1,
        months_back: int = 3,
    ) -> dict[str, Any]:
        """Cost forecast for a view.

        Args:
            view_id: Cloudability view ID (or the client's default view).
            basis: Cost basis: cash, adjusted, amortized, adjustedamortized or list.
            months_forward: Months to forecast forward (minimum 1).
            months_back: Historical months used as model input (minimum 3).
        """
        params = {
            "viewId": self._view(view_id),
            "basis": basis,
            "monthsForward": months_forward,
            "monthsBack": months_back,
        }
        return self._request("GET", "/forecast", params=params)

    # ── Reporting ────────────────────────────────────────────────────────

    def run_cost_report(
        self,
        start_date: str,
        end_date: str,
        dimensions: str = "vendor",
        metrics: str = "unblended_cost",
        view_id: str | int | None = None,
        limit: int = 100,
        offset: int = 0,
        filters: str | list[str] | None = None,
    ) -> dict[str, Any]:
        """Run a cost report against the Cloudability reporting engine.

        Args:
            start_date: Report start date (YYYY-MM-DD).
            end_date: Report end date (YYYY-MM-DD).
            dimensions: Comma-separated dimension name(s). Use get_measures() to discover them.
            metrics: Cost metric to return. Use get_measures() to discover them.
            view_id: View to scope the report (or the client's default view).
            limit: Maximum number of rows to return (default 100).
            offset: Row offset for pagination (default 0).
            filters: Filter expression(s) (field==value). A str or a list; each is sent as a repeated
                `filters` query param.
        """
        params: dict[str, Any] = {
            "start_date": start_date,
            "end_date": end_date,
            "dimensions": dimensions,
            "metrics": metrics,
            "view_id": self._view(view_id),
            "limit": limit,
            "offset": offset,
        }
        if filters:
            params["filters"] = _as_filter_list(filters)
        return self._request("GET", "/reporting/cost/run", params=params)

    # ── Async reporting (preferred for large pulls) ─────────────────────

    def enqueue_cost_report(
        self,
        start_date: str,
        end_date: str,
        dimensions: str,
        metrics: str,
        view_id: str | int,
        filters: str | list[str] | None = None,
        deadline: float | None = None,
    ) -> Any:
        """Enqueue an async cost report (GET) and return its report id."""
        params: dict[str, Any] = {
            "start_date": start_date,
            "end_date": end_date,
            "dimensions": dimensions,
            "metrics": metrics,
            "view_id": self._view(view_id),
        }
        if filters:
            params["filters"] = _as_filter_list(filters)
        response = self._request("GET", "/reporting/cost/enqueue", params=params, timeout=120,
                                 retries=ASYNC_RETRIES, deadline=deadline)
        if not isinstance(response, dict) or "id" not in response:
            raise RuntimeError("Cloudability enqueue response did not contain a report id")
        return response["id"]

    def get_report_state(self, report_id: Any, deadline: float | None = None) -> dict[str, Any]:
        return self._request("GET", f"/reporting/reports/{_seg(report_id)}/state", retries=ASYNC_RETRIES,
                             deadline=deadline)

    def get_report_results(self, report_id: Any, token: str | None = None,
                           deadline: float | None = None) -> dict[str, Any]:
        params = {"token": token} if token else None
        return self._request("GET", f"/reporting/reports/{_seg(report_id)}/results", params=params, timeout=300,
                             retries=ASYNC_RETRIES, deadline=deadline)

    def run_cost_report_async(
        self,
        start_date: str,
        end_date: str,
        dimensions: str,
        metrics: str,
        view_id: str | int,
        filters: str | list[str] | None = None,
        timeout_s: float = CALL_DEADLINE_S,
        poll_s: float = 3,
        deadline: float | None = None,
    ) -> list[dict[str, Any]]:
        """Run an async report to completion and return ALL result rows.

        Enqueue, polling and result paging share one deadline (`deadline`, an absolute time.monotonic() value, or
        now + timeout_s). Follows pagination.next (stops on a repeated token or after MAX_RESULT_PAGES).
        Raises RuntimeError on a failed report or unrecognised status, and DeadlineExceeded (with `.partial` set
        to the rows fetched so far) when time runs out.
        """
        if deadline is None:
            deadline = time.monotonic() + timeout_s
        report_id = self.enqueue_cost_report(start_date, end_date, dimensions, metrics, view_id, filters,
                                             deadline=deadline)
        while True:
            status = str(self.get_report_state(report_id, deadline=deadline).get("status", "")).strip().lower()
            if status == "finished":
                break
            if status in FAILED_STATES:
                raise RuntimeError(f"Cloudability report {report_id} ended with status '{status}'")
            if status not in IN_PROGRESS_STATES:
                shown = status[:40] if status else "<missing>"
                raise RuntimeError(f"Cloudability report {report_id} returned an unrecognised status '{shown}'")
            if time.monotonic() + poll_s >= deadline:
                raise DeadlineExceeded(
                    f"Cloudability report {report_id} not finished before the deadline (last status '{status}')"
                )
            time.sleep(poll_s)
        rows: list[dict[str, Any]] = []
        token: str | None = None
        seen = set()
        for _ in range(MAX_RESULT_PAGES):
            try:
                page = self.get_report_results(report_id, token, deadline=deadline)
            except DeadlineExceeded as exc:
                raise DeadlineExceeded(f"Cloudability report {report_id} results not complete before the deadline",
                                       partial=rows) from exc
            rows.extend(page.get("results") or [])
            token = (page.get("pagination") or {}).get("next")
            if not token:
                return rows
            if token in seen:
                raise RuntimeError(f"Cloudability report {report_id} returned a repeating pagination token")
            seen.add(token)
        raise RuntimeError(f"Cloudability report {report_id} exceeded {MAX_RESULT_PAGES} result pages")

    # ── Measures ─────────────────────────────────────────────────────────

    def get_measures(self) -> dict[str, Any]:
        """Available dimensions and metrics for cost reporting."""
        return self._request("GET", "/reporting/cost/measures")


# ── Probe client (key checking) ──────────────────────────────────────────

@dataclass(frozen=True)
class ProbeResult:
    """Outcome of one probe. status: ok | rejected | unreachable | unexpected_redirect.
    `target` is the Frontdoor host or the region; `views` is [{id, title}] for a region probe only."""

    status: str
    code: str
    target: str
    views: tuple = ()


@dataclass(frozen=True)
class VerifyResult:
    """Outcome of verify_key. status: ok | rejected | unreachable | unexpected_redirect | region_unproven."""

    status: str
    code: str
    frontdoor_host: str | None = None
    region: str | None = None
    views: tuple = ()
    hosts_tried: tuple = ()
    regions_tried: tuple = ()

    @property
    def ok(self) -> bool:
        return self.status == "ok"


def _timeout_for(deadline: float | None) -> tuple:
    if deadline is None:
        return PROBE_TIMEOUT
    remaining = max(0.1, deadline - time.monotonic())
    return (min(PROBE_TIMEOUT[0], remaining), min(PROBE_TIMEOUT[1], remaining))


def _classify_status(status_code: int) -> tuple[str, str]:
    if 300 <= status_code < 400:
        return "unexpected_redirect", "unexpected_redirect"
    if 400 <= status_code < 500:
        return "rejected", f"http_{status_code}"
    return "unreachable", f"http_{status_code}"


def _classify_exception(exc: Exception) -> tuple[str, str]:
    if isinstance(exc, requests.exceptions.SSLError):
        return "unreachable", "tls"
    if isinstance(exc, requests.exceptions.Timeout):
        return "unreachable", "timeout"
    if isinstance(exc, requests.exceptions.ConnectionError):
        return "unreachable", "connection"
    return "unreachable", "error"


def _frontdoor_login(host: str, public_key: str, secret_key: str,
                     deadline: float | None = None) -> tuple[ProbeResult, str | None]:
    """One login attempt: no retries, no redirects. Returns the result and, on success, the opentoken."""
    _check_url(host, settings.FRONTDOOR_HOSTS)
    try:
        response = http_post(
            f"{host}{LOGIN_PATH}",
            json={"keyAccess": public_key, "keySecret": secret_key},
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            timeout=_timeout_for(deadline),
            allow_redirects=False,
        )
    except Exception as exc:  # noqa: BLE001 - classified into a fixed code, text discarded
        status, code = _classify_exception(exc)
        return ProbeResult(status, code, host), None
    if response.status_code == 200:
        token = response.headers.get(TOKEN_HEADER)
        if not token:
            return ProbeResult("rejected", "no_token", host), None
        return ProbeResult("ok", "ok", host), token
    status, code = _classify_status(response.status_code)
    return ProbeResult(status, code, host), None


def probe_frontdoor(host: str, public_key: str, secret_key: str) -> ProbeResult:
    """Check a key pair against one Frontdoor host."""
    return _frontdoor_login(host, public_key, secret_key)[0]


def _parse_views(body: Any) -> tuple:
    items = body.get("result") if isinstance(body, dict) else None
    views = []
    for item in items if isinstance(items, list) else []:
        if not isinstance(item, dict) or not _ID_RE.fullmatch(str(item.get("id", ""))):
            continue
        views.append({"id": str(item["id"]), "title": str(item.get("title") or item.get("name") or "")})
    return tuple(views)


def probe_region(region: str, opentoken: str, environment_id: str, deadline: float | None = None) -> ProbeResult:
    """GET /views on one region with an opentoken: no retries, no re-login, no redirects."""
    base = settings.REGIONS.get(region)
    if base is None:
        raise ValueError("Unknown region")
    url = f"{base}/views"
    _check_url(url, settings.API_HOSTS)
    try:
        response = http_get(
            url,
            headers={TOKEN_HEADER: opentoken, ENVIRONMENT_HEADER: environment_id, "Accept": "application/json"},
            timeout=_timeout_for(deadline),
            allow_redirects=False,
        )
    except Exception as exc:  # noqa: BLE001
        status, code = _classify_exception(exc)
        return ProbeResult(status, code, region)
    if response.status_code != 200:
        status, code = _classify_status(response.status_code)
        return ProbeResult(status, code, region)
    try:
        views = _parse_views(response.json())
    except ValueError:
        views = ()
    return ProbeResult("ok", "ok", region, views)


def _worst(results: list[ProbeResult]) -> ProbeResult:
    """The most informative failure: rejected, then unexpected_redirect, then unreachable."""
    for status in ("rejected", "unexpected_redirect"):
        for result in results:
            if result.status == status:
                return result
    return results[0]


def _run_parallel(fn, targets: list, deadline: float) -> list:
    """Run fn(target) for each target in parallel, bounded by the shared deadline. Results keep `targets` order;
    a call still running at the deadline counts as unreachable (code `deadline`)."""
    if not targets:
        return []
    pool = ThreadPoolExecutor(max_workers=len(targets))
    try:
        futures = [pool.submit(fn, t) for t in targets]
        wait(futures, timeout=max(0.0, deadline - time.monotonic()))
        results = []
        for target, future in zip(targets, futures):
            if future.done() and future.exception() is None:
                results.append(future.result())
            else:
                results.append((ProbeResult("unreachable", "deadline", target), None))
        return results
    finally:
        pool.shutdown(wait=False, cancel_futures=True)


def verify_key(
    public_key: str,
    secret_key: str,
    environment_id: str,
    preferred_host: str,
    preferred_region: str,
    deadline_s: float = VERIFY_DEADLINE_S,
) -> VerifyResult:
    """Prove a key pair and infer the Frontdoor host and region, within one monotonic deadline.

    Frontdoor: the preferred host first. The other listed hosts (if any) are tried in parallel only when the
    preferred host is unreachable; a rejection (a 4xx) is final, so a mistyped secret is never sent on to other
    hosts. Region: the preferred region first, then the others in parallel. A region counts as proven by a 200 with a non-empty view list, or
    as the only 200."""
    deadline = time.monotonic() + deadline_s
    hosts = list(settings.FRONTDOOR_HOSTS)
    hosts.sort(key=lambda h: h != preferred_host)  # stable: the preferred host moves to the front
    hosts_tried: list = []

    def login(host: str, _dl=deadline):
        return _frontdoor_login(host, public_key, secret_key, _dl)

    attempts: list[tuple] = []
    winner: tuple | None = None
    first = login(hosts[0]) if time.monotonic() < deadline else (ProbeResult("unreachable", "deadline", hosts[0]), None)
    hosts_tried.append(hosts[0])
    attempts.append(first)
    if first[0].status == "ok":
        winner = first
    elif first[0].status == "unreachable" and len(hosts) > 1:
        rest = _run_parallel(login, hosts[1:], deadline)
        hosts_tried.extend(hosts[1:])
        attempts.extend(rest)
        winner = next((a for a in attempts if a[0].status == "ok"), None)
    if winner is None:
        failure = _worst([a[0] for a in attempts])
        return VerifyResult(failure.status, failure.code, hosts_tried=tuple(hosts_tried))
    host, token = winner[0].target, winner[1]

    regions = list(settings.REGIONS)
    regions.sort(key=lambda r: r != preferred_region)

    def probe(region: str, _dl=deadline):
        return probe_region(region, token, environment_id, _dl), None

    results: list[ProbeResult] = []
    regions_tried: list = []
    if time.monotonic() < deadline:
        results.append(probe(regions[0])[0])
    else:
        results.append(ProbeResult("unreachable", "deadline", regions[0]))
    regions_tried.append(regions[0])
    if not (results[0].status == "ok" and results[0].views) and len(regions) > 1:
        rest = _run_parallel(probe, regions[1:], deadline)
        regions_tried.extend(regions[1:])
        results.extend(r[0] for r in rest)

    ok = [r for r in results if r.status == "ok"]
    proven = next((r for r in ok if r.views), None)
    if proven is None and len(ok) == 1:
        proven = ok[0]
    if proven is not None:
        return VerifyResult("ok", "ok", host, proven.target, proven.views, tuple(hosts_tried), tuple(regions_tried))
    if ok:  # several regions answered 200 with no views: cannot tell which is right
        return VerifyResult("region_unproven", "region_unproven", host, None, (), tuple(hosts_tried),
                            tuple(regions_tried))
    failure = _worst(results)
    return VerifyResult(failure.status, failure.code, host, None, (), tuple(hosts_tried), tuple(regions_tried))
