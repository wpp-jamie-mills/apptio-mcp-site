"""
Categorised spend by project and PAM platform (Cloudability, read-only).

Pure logic (config, CSV, categorisation, month maths, rollups, view
resolution, cache TTLs) is kept separate from I/O (SpendEngine / SpendService)
so it can be unit-tested with synthetic data.

The service takes a client provider and a settings provider, both called on every
call, so a key or environment change is picked up without a restart. The cache lives
in a folder named for the environment, region and key (never stored or logged).
"""

from __future__ import annotations

import csv
import difflib
import fcntl
import gzip
import hashlib
import json
import os
import re
import shutil
import threading
import time
import tomllib
import zlib
from collections.abc import Callable, Iterable, Sequence
from concurrent.futures import ThreadPoolExecutor, as_completed
from contextlib import contextmanager
from dataclasses import dataclass, field, replace
from datetime import UTC, date, datetime, timedelta
from pathlib import Path
from typing import Any

from . import paths, spend_defaults
from .mapping import IMPORT_HINT, mapping_path

CACHE_SCHEMA = 4  # bump when the cached row shape or key layout changes
DEFAULT_DEADLINE_S = 110.0  # Desktop stops waiting at 140 s (measured)
DEADLINE_NOTE = "Time limit reached; ask again to continue; results are cached."
NO_VIEW_NAME = "the default view"

LEVEL_FIELDS = {
    "category": "atum_service_category",
    "type": "atum_service_type",
    "service": "atum_service_name",
}
DIMENSIONS = (
    "vendor,vendor_account_identifier,vendor_account_name,atum_service_category,atum_service_type,"
    "atum_service_name,service_name,transaction_type"
)
INDEX_DIMENSIONS = "vendor_account_identifier,vendor_account_name"
DAILY_DIMENSIONS = "date,vendor"  # small per-day, per-vendor report used only to detect source-data gaps
NOT_SET = "(not set)"
GAP_RATIO = 0.10  # a day below this share of the vendor's typical daily cost is a gap day
GAP_LAG_DAYS = 2  # the 2 most recent days (today and yesterday) are normal ingestion lag: not checked
GAP_MIN_DAYS = 7  # a chunk needs at least this many checkable days for a "typical" level to mean anything
GAP_MIN_TYPICAL = 1.0  # vendors whose typical daily cost is below this are too small to judge
UNATTRIBUTED_THRESHOLD_PCT = 25.0
BILLING_ACCOUNT_ID = re.compile(r"^[0-9a-f]{6}-[0-9a-f]{6}-[0-9a-f]{6}$")
GAP_NOTE = ("Cloudability has little or no {vendor} cost for these days; totals for the period are "
            "understated. This is a source-data gap.")
UNATTRIBUTED_NOTE = ("{view} recorded most GCP spend at billing-account level this month (no project IDs); "
                     "per-project figures come from other views where available, and projects with no data "
                     "in any view are understated.")
MAX_WORKERS = 4
ROUNDING_EPS = 0.005
MAX_RANGE_MONTHS = 24
INDEX_MONTHS = 12
MAX_LISTED = 50  # names listed per excluded status
PRUNE_AFTER_S = 90 * 86400
INDEX_ERROR_RETRY_S = 3600  # an index with failed views is refreshed (failed views only) after this
INDEX_FAIL_BACKOFF_S = 600  # after a failed background build, do not restart for this long
INDEX_REUSE_MAX_AGE_S = 20 * 3600  # a per-view index entry older than this is refetched, not reused
INDEX_COVERAGE_SLACK_DAYS = 1  # a range ending this far past the index window end still counts as covered
STATUS_DATA = ("ok", "no_spend_in_period")
STATUS_EXCLUDED = ("not_visible", "unknown", "unresolved")
STATUSES = STATUS_DATA + STATUS_EXCLUDED
EXCLUDED_NOTES = {
    "not_visible": "No spend in any accessible view during the 12-month view index window (idle, or billed "
                   "outside those views). Excluded from totals, not zero.",
    "unknown": "Visibility could not be determined: the range is outside the 12-month view index window or "
               "newer than the index, or some views failed to index (see view_index). May have spend in a "
               "view other than {view}. Excluded from totals.",
    "unresolved": "The view index is not built yet, so projects missing from {view} could not be resolved. "
                  "Excluded from totals; retry once the index is built.",
}
INDEX_BUILDING_NOTE = "view index building (~4 min); retry for full coverage"
INDEX_AHEAD_NOTE = "view index older than the requested range; refreshing in background"
NO_VIEW_MESSAGE = ("No Cloudability view is set. Call cloudability_settings to choose the view to report on, "
                   "then ask again.")
SPEND_TOML = "spend.toml"


class SpendError(ValueError):
    """User-facing error (bad config, bad arguments). Never contains secrets."""


class DeadlineExceeded(Exception):
    """The overall deadline passed; callers return what they have."""


# ── Settings and cache namespace ─────────────────────────────────────────


@dataclass(frozen=True)
class SpendSettings:
    """What a settings provider returns (any object with these attributes will do).

    `public_key_fingerprint` is used only to name the cache folder; it is never stored or logged."""
    view_id: int | None
    view_name: str
    environment_id: str
    region: str
    public_key_fingerprint: str


def namespace_for(environment_id: str, region: str, public_key_fingerprint: str) -> str:
    """First 16 hex characters of sha256('environment_id|region|public_key'). The inputs are not kept."""
    raw = f"{environment_id}|{region}|{public_key_fingerprint}".encode()
    return hashlib.sha256(raw).hexdigest()[:16]


_NAMESPACE = re.compile(r"^[0-9a-f]{16}$")


def namespace_dir(namespace: str) -> Path:
    return paths.cache_dir() / namespace


def clear_namespace(namespace: str) -> None:
    """Remove one namespace's cache folder (chunks, view index and lock)."""
    if _NAMESPACE.match(namespace):
        shutil.rmtree(paths.cache_dir() / namespace, ignore_errors=True)


def clear_all_caches() -> None:
    """Remove every namespace folder (logout). Files at the top of the cache folder are kept."""
    try:
        entries = list(paths.cache_dir().iterdir())
    except OSError:
        return
    for p in entries:
        if p.is_dir() and not p.is_symlink() and _NAMESPACE.match(p.name):
            shutil.rmtree(p, ignore_errors=True)


def view_label(view_name: str) -> str:
    return (view_name or "").strip() or NO_VIEW_NAME


# ── Config ───────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class EnvRule:
    env: str
    pattern: re.Pattern[str] | None = None  # None => default rule


@dataclass(frozen=True)
class Override:
    name: str
    vendor: str | None
    service_names: frozenset


@dataclass(frozen=True)
class SpendConfig:
    metric: str
    ttl_current_s: float
    ttl_previous_s: float
    ttl_older_s: float
    ttl_index_s: float
    env_rules: tuple[EnvRule, ...]
    overrides: tuple[Override, ...]
    base: str
    unset_label: str
    provisional_lag_s: float = 3 * 86400
    # Filled in per call from the settings provider, never from spend.toml:
    default_view_id: int = 0
    view_name: str = ""
    config_warnings: tuple[str, ...] = ()  # "Not used: <key>" for keys spend.toml may not hold


def _req(table: dict, key: str, typ, where: str):
    if key not in table:
        raise SpendError(f"{SPEND_TOML}: missing '{key}' in {where}")
    val = table[key]
    if typ is float:
        ok = isinstance(val, (int, float)) and not isinstance(val, bool)
    elif typ is int:
        ok = isinstance(val, int) and not isinstance(val, bool)
    else:
        ok = isinstance(val, typ)
    if not ok:
        raise SpendError(f"{SPEND_TOML}: '{key}' in {where} must be {typ.__name__}, got {type(val).__name__}")
    return val


def parse_config(data: dict) -> SpendConfig:
    """Validate a complete configuration document (built-in defaults, possibly overridden) and build a SpendConfig."""
    metric = data.get("metric", spend_defaults.DEFAULT_METRIC)
    if not isinstance(metric, str):
        raise SpendError(f"{SPEND_TOML}: 'metric' must be str")
    validate_metric(metric)

    cache = data.get("cache")
    if not isinstance(cache, dict):
        raise SpendError(f"{SPEND_TOML}: missing [cache] table")
    ttl_current = float(_req(cache, "current_month_hours", float, "[cache]")) * 3600
    ttl_prev = float(_req(cache, "previous_month_hours", float, "[cache]")) * 3600
    ttl_older = float(_req(cache, "older_month_days", float, "[cache]")) * 86400
    ttl_index = float(_req(cache, "view_index_hours", float, "[cache]")) * 3600
    lag_days = cache.get("provisional_lag_days", 3)
    if isinstance(lag_days, bool) or not isinstance(lag_days, (int, float)):
        raise SpendError(f"{SPEND_TOML}: 'provisional_lag_days' in [cache] must be a number")
    if min(ttl_current, ttl_prev, ttl_older, ttl_index, lag_days) < 0:
        raise SpendError(f"{SPEND_TOML}: [cache] TTLs must not be negative")

    raw_rules = data.get("environment_rules")
    if not isinstance(raw_rules, list) or not raw_rules:
        raise SpendError(f"{SPEND_TOML}: [[environment_rules]] must contain at least one rule")
    rules: list[EnvRule] = []
    for i, r in enumerate(raw_rules, 1):
        where = f"environment_rules #{i}"
        if not isinstance(r, dict):
            raise SpendError(f"{SPEND_TOML}: {where} must be a table")
        env = _req(r, "env", str, where)
        if r.get("default"):
            if i != len(raw_rules):
                raise SpendError(f"{SPEND_TOML}: the default environment rule must be last")
            rules.append(EnvRule(env=env))
        else:
            pat = _req(r, "pattern", str, where)
            try:
                rules.append(EnvRule(env=env, pattern=re.compile(pat)))
            except re.error as e:
                raise SpendError(f"{SPEND_TOML}: invalid regex in {where}: {e}") from None
    if rules[-1].pattern is not None:
        raise SpendError(f"{SPEND_TOML}: the last environment rule must be the default (default = true)")

    cats = data.get("categories")
    if not isinstance(cats, dict):
        raise SpendError(f"{SPEND_TOML}: missing [categories] table")
    base = _req(cats, "base", str, "[categories]")
    if base not in LEVEL_FIELDS.values():
        raise SpendError(f"{SPEND_TOML}: categories.base must be one of {sorted(LEVEL_FIELDS.values())}")
    unset_label = _req(cats, "unset_label", str, "[categories]")
    overrides: list[Override] = []
    for i, o in enumerate(cats.get("overrides", []), 1):
        where = f"categories.overrides #{i}"
        if not isinstance(o, dict):
            raise SpendError(f"{SPEND_TOML}: {where} must be a table")
        name = _req(o, "name", str, where)
        vendor = o.get("vendor")
        if vendor is not None and not isinstance(vendor, str):
            raise SpendError(f"{SPEND_TOML}: 'vendor' in {where} must be a string")
        names = _req(o, "service_name", list, where)
        if not names or not all(isinstance(n, str) for n in names):
            raise SpendError(f"{SPEND_TOML}: 'service_name' in {where} must be a non-empty list of strings")
        overrides.append(Override(name=name, vendor=vendor, service_names=frozenset(names)))

    return SpendConfig(
        metric=metric,
        ttl_current_s=ttl_current,
        ttl_previous_s=ttl_prev,
        ttl_older_s=ttl_older,
        ttl_index_s=ttl_index,
        env_rules=tuple(rules),
        overrides=tuple(overrides),
        base=base,
        unset_label=unset_label,
        provisional_lag_s=float(lag_days) * 86400,
    )


def base_level(config: SpendConfig) -> str:
    """The level name (category/type/service) for the configured [categories].base field."""
    return next(k for k, v in LEVEL_FIELDS.items() if v == config.base)


def merge_user_config(user: dict) -> tuple[dict, list[str]]:
    """Overlay a parsed spend.toml on the built-in defaults. -> (document, ["Not used: <key>", ...]).

    Only [cache], [[environment_rules]] and [categories] are honoured; everything else is ignored."""
    data = spend_defaults.defaults()
    notes: list[str] = []
    allowed_inner = {"cache": spend_defaults.ALLOWED_CACHE, "categories": spend_defaults.ALLOWED_CATEGORIES}
    for key, value in user.items():
        if key not in spend_defaults.ALLOWED_TOP:
            notes.append(f"Not used: {key}")
        elif key in allowed_inner and isinstance(value, dict):
            for k, v in value.items():
                if k in allowed_inner[key]:
                    data[key][k] = v
                else:
                    notes.append(f"Not used: {key}.{k}")
        else:
            data[key] = value  # a wrong type is reported by parse_config
    return data, notes


def load_config(path: Path | None = None) -> SpendConfig:
    """Built-in defaults plus the optional spend.toml in the data folder (re-read on every call)."""
    path = Path(path) if path else paths.data_dir() / SPEND_TOML
    user: dict = {}
    try:
        with open(path, "rb") as f:
            user = tomllib.load(f)
    except FileNotFoundError:
        pass
    except tomllib.TOMLDecodeError as e:
        raise SpendError(f"{path.name} is not valid TOML: {e}") from None
    except OSError:
        raise SpendError(f"{path.name} could not be read") from None
    data, notes = merge_user_config(user)
    return replace(parse_config(data), config_warnings=tuple(notes))


def validate_metric(metric: str) -> str:
    if not re.fullmatch(r"[a-z][a-z0-9_]*", metric or ""):
        raise SpendError(f"Invalid metric name: {metric!r}")
    return metric


# ── Mapping file ─────────────────────────────────────────────────────────


@dataclass
class Collections:
    platform_projects: dict[str, list[str]]
    project_platforms: dict[str, list[str]]
    duplicates: dict[str, list[str]]  # project -> platforms (only where >1)


def build_collections(rows: Iterable[tuple[str, str]]) -> Collections:
    pp: dict[str, list[str]] = {}
    rp: dict[str, list[str]] = {}
    for platform, project in rows:
        platform, project = (platform or "").strip(), (project or "").strip()
        if not platform or not project:
            continue
        if project not in pp.setdefault(platform, []):
            pp[platform].append(project)
        if platform not in rp.setdefault(project, []):
            rp[project].append(platform)
    dups = {p: pl for p, pl in rp.items() if len(pl) > 1}
    return Collections(pp, rp, dups)


def load_collections(path: Path | None = None) -> Collections:
    path = Path(path) if path else mapping_path()
    try:
        with open(path, newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            header = {(h or "").strip(): h for h in (reader.fieldnames or [])}
            for need in ("PAM Platform", "Cloud subscription"):
                if need not in header:
                    raise SpendError(f"Your mapping file is missing the column '{need}'. Import a corrected file. "
                                     f"{IMPORT_HINT}")
            rows = [(r[header["PAM Platform"]], r[header["Cloud subscription"]]) for r in reader]
    except FileNotFoundError:
        raise SpendError("No mapping file has been imported yet. " + IMPORT_HINT) from None
    return build_collections(rows)


# ── Environment and category logic ───────────────────────────────────────


def environment_for(project: str, rules: Sequence[EnvRule]) -> str:
    for rule in rules:
        if rule.pattern is None or rule.pattern.search(project):
            return rule.env
    return "Unclassified"


def _field_value(row: dict, field_name: str, unset_label: str) -> str:
    v = row.get(field_name)
    if v is None or str(v).strip() == "" or str(v).strip().lower() == NOT_SET:
        return unset_label
    return str(v)


def categorise(row: dict, config: SpendConfig, level: str = "category") -> str:
    """Overrides first, then the ATUM field for `level`; '(not set)' -> unset_label."""
    if level not in LEVEL_FIELDS:
        raise SpendError(f"level must be one of {sorted(LEVEL_FIELDS)}")
    for o in config.overrides:
        if o.vendor is not None and str(row.get("vendor", "")).lower() != o.vendor.lower():
            continue
        if row.get("service_name") in o.service_names:
            return o.name
    return _field_value(row, LEVEL_FIELDS[level], config.unset_label)


# ── Dates and chunks (all dates are UTC) ─────────────────────────────────


def _parse_date(s: str, what: str) -> date:
    try:
        return date.fromisoformat(s.strip())
    except ValueError:
        raise SpendError(f"{what} must be YYYY-MM-DD, got {s!r}") from None


def _month_end(d: date) -> date:
    nxt = date(d.year + (d.month == 12), d.month % 12 + 1, 1)
    return nxt - timedelta(days=1)


def last_full_month(today: date) -> tuple[date, date]:
    end = today.replace(day=1) - timedelta(days=1)
    return end.replace(day=1), end


def month_chunks(start: date, end: date) -> list[tuple[date, date]]:
    """Split [start, end] (inclusive) into calendar-month chunks; partial months keep exact dates."""
    chunks = []
    cur = start
    while cur <= end:
        stop = min(_month_end(cur), end)
        chunks.append((cur, stop))
        cur = stop + timedelta(days=1)
    return chunks


def resolve_dates(start: str, end: str, today: date) -> tuple[date, date, bool]:
    """Returns (start, end, partial). Dates are UTC and inclusive.

    Defaults: neither given -> last full calendar month. Only start -> to the end of
    start's month. Only end -> from the first of end's month. An end on or after
    today (UTC) is clamped to today and flagged partial (month to date). A start in
    the future, or a range over 24 calendar months, is rejected."""
    start, end = (start or "").strip(), (end or "").strip()
    if not start and not end:
        s, e = last_full_month(today)
    elif start and not end:
        s = _parse_date(start, "start_date")
        e = _month_end(s)
    elif end and not start:
        e = _parse_date(end, "end_date")
        s = e.replace(day=1)
    else:
        s, e = _parse_date(start, "start_date"), _parse_date(end, "end_date")
        if e < s:
            raise SpendError("end_date must not be before start_date")
    if s > today:
        raise SpendError(f"start_date {s.isoformat()} is in the future (dates are UTC; today is {today.isoformat()})")
    partial = False
    if e >= today:
        e, partial = today, True
    if len(month_chunks(s, e)) > MAX_RANGE_MONTHS:
        raise SpendError(f"Date range is limited to {MAX_RANGE_MONTHS} calendar months")
    return s, e, partial


def ttl_for_chunk(chunk_end: date, today: date, config: SpendConfig) -> float:
    diff = (today.year * 12 + today.month) - (chunk_end.year * 12 + chunk_end.month)
    if diff <= 0:
        return config.ttl_current_s
    if diff == 1:
        return config.ttl_previous_s
    return config.ttl_older_s


def final_after(chunk_end: date, config: SpendConfig) -> float:
    """Epoch (UTC) after which data fetched for a chunk is treated as final:
    the day after the chunk ends plus the billing lag."""
    day = datetime(chunk_end.year, chunk_end.month, chunk_end.day, tzinfo=UTC) + timedelta(days=1)
    return day.timestamp() + config.provisional_lag_s


def is_provisional(chunk_end: date, fetched_at: float, config: SpendConfig) -> bool:
    return fetched_at < final_after(chunk_end, config)


def effective_ttl(chunk_end: date, fetched_at: float, today: date, config: SpendConfig) -> float:
    """TTL by the chunk's age now, except data fetched before the period was final
    (period end + 1 day + lag) refreshes at the current-month rate."""
    base = ttl_for_chunk(chunk_end, today, config)
    if is_provisional(chunk_end, fetched_at, config):
        return min(base, config.ttl_current_s)
    return base


# ── Rollup ───────────────────────────────────────────────────────────────


class Agg:
    """Accumulates cost by category, transaction type and month (unrounded)."""

    __slots__ = ("cats", "months", "total", "tx")

    def __init__(self):
        self.total = 0.0
        self.cats: dict[str, float] = {}
        self.tx: dict[str, float] = {}
        self.months: dict[str, float] = {}

    def add(self, cost: float, cat: str, tx: str, month: str) -> None:
        self.total += cost
        self.cats[cat] = self.cats.get(cat, 0.0) + cost
        self.tx[tx] = self.tx.get(tx, 0.0) + cost
        self.months[month] = self.months.get(month, 0.0) + cost

    def merge(self, other: Agg) -> Agg:
        self.total += other.total
        for src, dst in ((other.cats, self.cats), (other.tx, self.tx), (other.months, self.months)):
            for k, v in src.items():
                dst[k] = dst.get(k, 0.0) + v
        return self


def row_cost(row: dict, metric: str) -> float:
    v = row.get(metric)
    if v in (None, ""):
        return 0.0
    try:
        return float(v)
    except (TypeError, ValueError):
        raise SpendError(f"Unexpected non-numeric value in metric '{metric}'") from None


def norm_key(value: Any) -> str:
    """Normalised identifier or name: stripped, lower-case; "" when empty or "(not set)"."""
    s = str(value).strip().lower() if value is not None else ""
    return "" if s in ("", NOT_SET) else s


def row_project(row: dict) -> str:
    """A row's project key: its vendor_account_identifier (stripped), else its name."""
    ident = str(row.get("vendor_account_identifier") or "").strip()
    if ident and ident.lower() != NOT_SET:
        return ident
    return str(row.get("vendor_account_name") or "").strip()


def build_project_aggs(
    records: Iterable[tuple[str, dict]], config: SpendConfig, level: str, metric: str
) -> dict[str, Agg]:
    """records: (month 'YYYY-MM', row). Returns project -> Agg, keyed by identifier (name when unset)."""
    out: dict[str, Agg] = {}
    for month, row in records:
        project = row_project(row)
        if not project:
            continue
        tx = _field_value(row, "transaction_type", "Unknown")
        out.setdefault(project, Agg()).add(row_cost(row, metric), categorise(row, config, level), tx, month)
    return out


def r2(x: float) -> float:
    v = round(x, 2)
    return 0.0 if v == 0 else v


def render_agg(agg: Agg, months: Sequence[str] | None = None) -> dict:
    """Full split. pct is the share of this node's own net total."""
    total = agg.total
    cats = {}
    for name, c in sorted(agg.cats.items(), key=lambda kv: (-kv[1], kv[0])):
        if abs(c) < ROUNDING_EPS:
            continue
        cats[name] = {"cost": r2(c), "pct": r2(c / total * 100) if abs(total) > ROUNDING_EPS else None}
    tx = {
        n: r2(c)
        for n, c in sorted(agg.tx.items(), key=lambda kv: (-kv[1], kv[0]))
        if abs(c) >= ROUNDING_EPS
    }
    out = {"total": r2(total), "categories": cats, "transaction_types": tx}
    if months is not None:
        out["by_month"] = {m: r2(agg.months.get(m, 0.0)) for m in months}
    return out


def top_categories(agg: Agg, n: int = 3) -> dict[str, float]:
    """Top n categories by absolute cost plus an '(other)' bucket so the values add up to the total."""
    items = sorted(((k, v) for k, v in agg.cats.items() if abs(v) >= ROUNDING_EPS), key=lambda kv: (-abs(kv[1]), kv[0]))
    top = items[:n]
    out = {k: r2(v) for k, v in top}
    rest = agg.total - sum(v for _, v in top)
    if abs(rest) >= ROUNDING_EPS:
        out["(other)"] = r2(rest)
    return out


def merge_aggs(aggs: Iterable[Agg]) -> Agg:
    out = Agg()
    for a in aggs:
        out.merge(a)
    return out


Entry = tuple[str, Agg, dict]  # (project, agg, extra fields incl. status/environment)


def render_project(p: str, a: Agg, extra: dict, months: Sequence[str] | None, detail: bool,
                   hide: Sequence[str] = ()) -> dict:
    head = {"project": p, **{k: v for k, v in extra.items() if k not in hide}}
    if detail:
        return {**head, **render_agg(a, months)}
    return {**head, "total": r2(a.total), "top_categories": top_categories(a)}


def render_excluded(excluded: Sequence[tuple[str, str]], limit: int = MAX_LISTED, names_listed: bool = True) -> dict:
    """excluded: (project, status). -> {status: {count, projects[<=limit]}} (counts only without names_listed)."""
    out: dict[str, Any] = {}
    for st in STATUS_EXCLUDED:
        names = sorted(p for p, s in excluded if s == st)
        if names:
            d: dict[str, Any] = {"count": len(names)}
            if names_listed:
                d["projects"] = names[:limit]
                if len(names) > limit:
                    d["truncated"] = True
            out[st] = d
    return out


def limit_projects(
    entries: list[Entry], max_projects: int, months: Sequence[str] | None, detail: bool = False,
    hide: Sequence[str] = (),
) -> tuple[list[dict], dict | None]:
    """Top N by absolute total (large credits stay visible); the remainder is
    aggregated as {"count", "total"}."""
    ordered = sorted(entries, key=lambda e: (-abs(e[1].total), e[0]))
    shown, rest = ordered[:max_projects], ordered[max_projects:]
    rendered = [render_project(p, a, extra, months, detail, hide) for p, a, extra in shown]
    other = {"count": len(rest), "total": r2(sum(a.total for _, a, _ in rest))} if rest else None
    return rendered, other


def build_node(
    entries: list[Entry], excluded: Sequence[tuple[str, str]], max_projects: int,
    months: Sequence[str] | None, detail: bool = False, hide: Sequence[str] = (),
) -> dict:
    node = render_agg(merge_aggs(a for _, a, _ in entries), months)
    node["csv_project_count"] = len(entries) + len(excluded)
    node["visible_project_count"] = len(entries)
    projects, other = limit_projects(entries, max_projects, months, detail, hide)
    node["projects"] = projects
    if other:
        node["other_projects"] = other
    ex = render_excluded(excluded)
    if ex:
        node["excluded"] = ex
    return node


def build_platform_node(
    entries: list[Entry],
    excluded: Sequence[tuple[str, str]],
    by_environment: bool,
    config: SpendConfig,
    max_projects: int,
    months: Sequence[str] | None,
    detail: bool = False,
) -> dict:
    """entries carry extra['environment']. Platform -> environment (optional) -> project."""
    if not by_environment:
        return build_node(entries, excluded, max_projects, months, detail)
    node = render_agg(merge_aggs(a for _, a, _ in entries), months)
    node["csv_project_count"] = len(entries) + len(excluded)
    node["visible_project_count"] = len(entries)
    ex = render_excluded(excluded, names_listed=False)  # names appear only in the environment nodes
    if ex:
        node["excluded"] = ex
    order = [r.env for r in config.env_rules]
    envs: dict[str, list[Entry]] = {}
    env_ex: dict[str, list[tuple[str, str]]] = {}
    for e in entries:
        envs.setdefault(e[2]["environment"], []).append(e)
    for p, st in excluded:
        env_ex.setdefault(environment_for(p, config.env_rules), []).append((p, st))
    names = set(envs) | set(env_ex)
    node["environments"] = {
        env: build_node(envs.get(env, []), env_ex.get(env, []), max_projects, months, detail, hide=("environment",))
        for env in sorted(names, key=lambda x: order.index(x) if x in order else len(order))
    }
    return node


# ── View resolution ──────────────────────────────────────────────────────


def resolve_views(
    projects: Iterable[str], index: dict[int, set[str]], default_view: int,
    names: dict[int, set[str]] | None = None, by_name: Iterable[str] = (),
) -> dict[str, int | None]:
    """Each project -> exactly one view: the default view first, otherwise the
    lowest-id other view that contains it, otherwise None. `index` holds each view's
    identifiers (or names where a row had no identifier); matching is case-insensitive.
    Projects in `by_name` (not CSV identifiers) also match a view's display `names`
    when no identifier matches."""
    lc = {v: {p.strip().lower() for p in ids} for v, ids in index.items()}
    nm = {v: {p.strip().lower() for p in ns} for v, ns in (names or {}).items()}
    fb = {p.strip().lower() for p in by_name}

    def has(v: int, k: str) -> bool:
        return k in lc.get(v, ()) or (k in fb and k in nm.get(v, ()))

    out: dict[str, int | None] = {}
    for p in projects:
        k = p.strip().lower()
        if has(default_view, k):
            out[p] = default_view
            continue
        out[p] = next((v for v in sorted(lc) if v != default_view and has(v, k)), None)
    return out


# ── Source-data checks (detect and report; never change numbers) ──────────


def _median(vals: Sequence[float]) -> float:
    s = sorted(vals)
    n = len(s)
    return 0.0 if not n else (s[n // 2] if n % 2 else (s[n // 2 - 1] + s[n // 2]) / 2)


def detect_gaps(
    daily_rows: Iterable[dict], vendors: Iterable[str], start: date, end: date, today: date, metric: str,
) -> list[dict]:
    """Runs of days in [start, end] where a vendor's daily cost is below GAP_RATIO of its typical
    daily cost in that range. The GAP_LAG_DAYS most recent days (today and yesterday) are
    normal ingestion lag and are not checked; a day with no row counts as zero. "Typical" is the
    median of the highest-cost half of the days, so a gap covering about half the range
    cannot drag the reference down with it; weekend dips stay far above the threshold.
    -> [{vendor, from, to, typical_daily, observed_daily_avg}] (ISO dates), vendor as in the rows."""
    wanted = {str(v).strip().lower() for v in vendors}
    last = min(end, today - timedelta(days=GAP_LAG_DAYS))
    if last < start or (last - start).days + 1 < GAP_MIN_DAYS:
        return []
    per: dict[str, dict[date, float]] = {}
    label: dict[str, str] = {}
    for r in daily_rows:
        vk = str(r.get("vendor") or "").strip().lower()
        if vk not in wanted:
            continue
        try:
            d = date.fromisoformat(str(r.get("date"))[:10])
        except ValueError:
            continue
        label.setdefault(vk, str(r.get("vendor")).strip())
        dd = per.setdefault(vk, {})
        dd[d] = dd.get(d, 0.0) + row_cost(r, metric)
    days = [start + timedelta(days=i) for i in range((last - start).days + 1)]
    out: list[dict] = []
    for vk in sorted(per):
        series = [per[vk].get(d, 0.0) for d in days]
        typical = _median(sorted(series, reverse=True)[: (len(series) + 1) // 2])
        if typical < GAP_MIN_TYPICAL:
            continue
        run: list[int] = []
        for i in range(len(days) + 1):
            if i < len(days) and series[i] < GAP_RATIO * typical:
                run.append(i)
                continue
            if run:
                out.append({"vendor": label[vk], "from": days[run[0]].isoformat(), "to": days[run[-1]].isoformat(),
                            "typical_daily": r2(typical),
                            "observed_daily_avg": r2(sum(series[j] for j in run) / len(run))})
                run = []
    return out


def merge_gaps(gaps: Sequence[dict]) -> list[dict]:
    """Merge runs of the same vendor and view that touch across month chunks."""
    out: list[dict] = []
    for g in sorted(gaps, key=lambda g: (g["vendor"], g["view_id"], g["from"])):
        prev = out[-1] if out else None
        if (prev and prev["vendor"] == g["vendor"] and prev["view_id"] == g["view_id"]
                and date.fromisoformat(g["from"]) - date.fromisoformat(prev["to"]) <= timedelta(days=1)):
            n1 = (date.fromisoformat(prev["to"]) - date.fromisoformat(prev["from"])).days + 1
            n2 = (date.fromisoformat(g["to"]) - date.fromisoformat(g["from"])).days + 1
            prev["observed_daily_avg"] = r2((prev["observed_daily_avg"] * n1 + g["observed_daily_avg"] * n2) / (n1 + n2))
            prev["typical_daily"] = max(prev["typical_daily"], g["typical_daily"])
            prev["to"] = g["to"]
        else:
            out.append(dict(g))
    return out


def unattributed_share(rows: Iterable[dict], metric: str) -> tuple[float, float]:
    """(share %, amount) of a view's GCP cost recorded on billing-account identifiers
    (aaaaaa-bbbbbb-cccccc) rather than project IDs."""
    total = billing = 0.0
    for r in rows:
        if str(r.get("vendor") or "").strip().lower() != "gcp":
            continue
        c = row_cost(r, metric)
        total += c
        if BILLING_ACCOUNT_ID.match(norm_key(r.get("vendor_account_identifier"))):
            billing += c
    return (billing / total * 100 if abs(total) > ROUNDING_EPS else 0.0), billing


# ── Platform matching ────────────────────────────────────────────────────


def match_platform(query: str, platforms: Sequence[str]) -> tuple[str | None, list[str]]:
    """Exact (case-insensitive, also on the code before ' - '), then a unique
    substring. Returns (match, candidates); match None when none/ambiguous."""
    q = (query or "").strip().lower()
    if not q:
        return None, []

    def codes(p: str) -> list[str]:
        parts = re.split(r"\s[–—-]\s", p, maxsplit=1)
        return [p.lower(), parts[0].lower()]

    exact = [p for p in platforms if q in codes(p)]
    if len(exact) == 1:
        return exact[0], []
    if len(exact) > 1:
        return None, exact
    subs = [p for p in platforms if q in p.lower()]
    if len(subs) == 1:
        return subs[0], []
    return None, subs


def suggest_platforms(query: str, platforms: Sequence[str]) -> list[str]:
    """Closest platform names for a query that matched nothing (all of them if none is close)."""
    q = (query or "").strip().lower()
    scored = []
    for p in platforms:
        cands = [p.lower(), re.split(r"\s[–—-]\s", p, maxsplit=1)[0].lower()]
        scored.append((max(difflib.SequenceMatcher(None, q, c).ratio() for c in cands), p))
    close = [p for r, p in sorted(scored, key=lambda t: (-t[0], t[1])) if r >= 0.6]
    return close[:5] or list(platforms)


# ── Errors for tool output ───────────────────────────────────────────────

_URL_QUERY = re.compile(r"(https?://[^\s?#'\"<>)]+)[?#][^\s'\"<>)]*")
_PATH_QUERY = re.compile(r"(?<![\w:/.])(/[^\s?#'\"<>)]*)[?#][^\s'\"<>)]*")  # path-only URLs ("url: /v3/x?token=...")


def sanitise_error(msg: Any, limit: int = 300) -> str:
    """Strip URL query strings and collapse whitespace; never includes response bodies."""
    text = _PATH_QUERY.sub(r"\1", _URL_QUERY.sub(r"\1", str(msg)))
    text = " ".join(text.split())
    return text if len(text) <= limit else text[: limit - 1] + "…"


def error_payload(exc: BaseException) -> dict:
    if isinstance(exc, SpendError):
        return {"error": sanitise_error(exc)}
    return {"error": f"{type(exc).__name__}: {sanitise_error(exc)}"}


# ── I/O: cache + fetching ────────────────────────────────────────────────

_ANY = object()


def _hash(*parts: Any) -> str:
    return hashlib.sha1(json.dumps(parts, sort_keys=True, default=str).encode()).hexdigest()[:20]


def _iso(ts: float) -> str:
    return datetime.fromtimestamp(ts, UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _norm(key: Any) -> Any:
    return json.loads(json.dumps(key, default=str))


class DiskCache:
    """gzip-JSON cache. Entries: {"fetched_at": epoch, "key": ..., "payload": ...}.
    Anything unreadable, mis-shaped or with a different key counts as a miss."""

    def __init__(self, cache_dir: Path):
        self.dir = Path(cache_dir)
        self._pruned = False

    def _path(self, name: str) -> Path:
        return self.dir / f"{name}.json.gz"

    @staticmethod
    def _load(path: Path) -> dict | None:
        try:
            with gzip.open(path, "rt", encoding="utf-8") as f:
                entry = json.load(f)
        except FileNotFoundError:
            return None
        except (gzip.BadGzipFile, EOFError, zlib.error, ValueError):  # JSON/Unicode errors are ValueErrors
            DiskCache._drop(path)  # undecodable content: drop it
            return None
        except OSError:
            return None  # EMFILE, EIO, EACCES...: a transient problem, not a bad file; keep it
        ok = (
            isinstance(entry, dict)
            and isinstance(entry.get("fetched_at"), (int, float))
            and not isinstance(entry.get("fetched_at"), bool)
            and isinstance(entry.get("payload"), (list, dict))
            and "key" in entry
        )
        if not ok:
            DiskCache._drop(path)  # decoded, but the wrong shape
            return None
        return entry

    @staticmethod
    def _drop(path: Path) -> None:
        try:
            path.unlink()
        except OSError:
            pass

    def read(self, name: str, ttl_s: float | None, now: float, key: Any = _ANY) -> dict | None:
        """ttl_s None ignores age (used for stale-while-revalidate)."""
        entry = self._load(self._path(name))
        if entry is None:
            return None
        if key is not _ANY and entry["key"] != _norm(key):
            return None
        if ttl_s is not None and not (now - float(entry["fetched_at"]) < ttl_s):
            return None
        return entry

    def read_latest(self, prefix: str, match: Callable[[Any], bool]) -> dict | None:
        """Newest valid entry among files named `prefix*` whose key satisfies `match`."""
        best = None
        try:
            paths = list(self.dir.glob(f"{prefix}*.json.gz"))
        except OSError:
            return None
        for path in paths:
            entry = self._load(path)
            if entry is None or not match(entry["key"]):
                continue
            if best is None or entry["fetched_at"] > best["fetched_at"]:
                best = entry
        return best

    def write(self, name: str, key: Any, payload: Any, now: float) -> None:
        try:
            paths.private_dir(self.dir)
            blob = gzip.compress(json.dumps({"fetched_at": now, "key": key, "payload": payload}).encode("utf-8"))
            paths.atomic_write(self._path(name), blob)
            self._prune()
        except OSError:
            pass  # cache is best-effort

    def _prune(self) -> None:
        if self._pruned:
            return
        self._pruned = True
        cutoff = time.time() - PRUNE_AFTER_S
        try:
            for path in self.dir.iterdir():
                if ".json.gz" in path.name:  # chunk files and any stray temp copies of them
                    try:
                        if path.stat().st_mtime < cutoff:
                            path.unlink()
                    except OSError:
                        pass
        except OSError:
            pass


@dataclass
class ChunkData:
    view_id: int
    start: date
    end: date
    rows: list[dict]
    fetched_at: float
    from_cache: bool
    provisional: bool = False


@dataclass
class ScopeData:
    records: list[tuple[str, dict]]  # (month, row) for requested projects only
    status: dict[str, str]  # project -> ok | no_spend_in_period | not_visible | unknown | unresolved
    view_of: dict[str, int | None]  # project -> main view (the default view if it served any month)
    freshness: list[dict]
    view_titles: dict[int, str]
    index_errors: dict[int, str]
    index_used: bool
    index_state: str = ""  # fresh | stale | building | none ("" when no index was needed)
    index_window: tuple[str, str] | None = None
    index_build_started: bool = False
    provisional: bool = False
    index_ahead: bool = False  # range ends after the index window end (+ slack): refresh requested
    index_error: str = ""  # sanitised reason the last background build failed ("" if none/building)
    sources: dict[str, dict[int, list[str]]] = field(default_factory=dict)  # project -> view -> months served
    names: dict[str, str] = field(default_factory=dict)  # project -> display name Cloudability shows for it
    gaps: list[dict] = field(default_factory=list)  # cost_data_gaps: merged runs, see detect_gaps
    gap_check_failed: int = 0  # (view, month) daily reports that could not be fetched
    unattributed: list[dict] = field(default_factory=list)  # default-view months with most GCP on billing-account ids
    deadline_hit: bool = False  # the overall deadline passed before every phase finished


class _Build:
    """One index build (foreground or background) in the per-cache-folder registry."""

    def __init__(self):
        self.thread: threading.Thread | None = None
        self.failed_at: float | None = None
        self.error: str = ""
        self.exc: BaseException | None = None
        self.result: dict[str, Any] | None = None
        self.done = threading.Event()


_BUILD_LOCK = threading.Lock()
_BUILDS: dict[str, _Build] = {}


def wait_for_all_builds(timeout: float | None = None) -> bool:
    """Join every index build in this process (tests and scripts, before removing a cache folder)."""
    with _BUILD_LOCK:
        builds = list(_BUILDS.values())
    deadline = None if timeout is None else time.monotonic() + timeout
    for b in builds:
        if b.thread is not None and b.thread is not threading.current_thread():
            b.done.wait(None if deadline is None else max(0.0, deadline - time.monotonic()))
    return all(b.done.is_set() for b in builds)


class SpendEngine:
    def __init__(
        self,
        client: Any,
        config: SpendConfig,
        cache_dir: Path,
        now: Callable[[], float] | None = None,
        max_workers: int = MAX_WORKERS,
        background_builds: bool = True,
    ):
        self.client = client
        self.config = config
        self.cache = DiskCache(cache_dir)
        self._now = now or (lambda: datetime.now(UTC).timestamp())
        self.max_workers = max_workers
        self.background_builds = background_builds  # False: never start a background build thread

    def today(self) -> date:
        return datetime.fromtimestamp(self._now(), UTC).date()

    # chunk rows -------------------------------------------------------

    def _chunk_key(self, view_id: int, start: date, end: date, metric: str,
                   dims: str | None = None) -> tuple[str, list]:
        dims = dims or DIMENSIONS
        key = [CACHE_SCHEMA, view_id, start.isoformat(), end.isoformat(), dims, metric]
        return f"{'rows' if dims == DIMENSIONS else 'daily'}-{_hash(*key)}", key

    def _read_chunk(self, view_id: int, chunk: tuple[date, date], metric: str, now: float, today: date,
                    dims: str | None = None) -> ChunkData | None:
        start, end = chunk
        name, key = self._chunk_key(view_id, start, end, metric, dims)
        entry = self.cache.read(name, None, now, key)
        if entry is None or not isinstance(entry["payload"], list):
            return None
        fetched = float(entry["fetched_at"])
        if now - fetched >= effective_ttl(end, fetched, today, self.config):
            return None  # stale (or provisional data past its short TTL)
        return ChunkData(view_id, start, end, entry["payload"], fetched, True,
                         is_provisional(end, fetched, self.config))

    def _fetch_chunk(self, view_id: int, chunk: tuple[date, date], metric: str,
                     dims: str | None = None) -> ChunkData:
        start, end = chunk
        dims = dims or DIMENSIONS
        name, key = self._chunk_key(view_id, start, end, metric, dims)
        now = self._now()
        rows = self.client.run_cost_report_async(
            start.isoformat(), end.isoformat(), dims, metric, view_id
        )
        keep = dims.split(",") + [metric]
        rows = [{k: r.get(k) for k in keep} for r in rows]
        self.cache.write(name, key, rows, now)
        return ChunkData(view_id, start, end, rows, now, False, is_provisional(end, now, self.config))

    def load_many(self, pairs: Sequence[tuple[int, tuple[date, date]]], metric: str,
                  dims: str | None = None, safe: bool = False) -> list[ChunkData | None]:
        """(view, chunk) pairs: warm ones come from disk; cold ones are fetched in
        parallel (bounded by max_workers) across views and months. With `safe`, a failed
        fetch yields None for that pair instead of raising."""
        now, today = self._now(), self.today()
        results: dict[int, ChunkData | None] = {}
        cold: list[int] = []
        for i, (v, ch) in enumerate(pairs):
            hit = self._read_chunk(v, ch, metric, now, today, dims)
            if hit is not None:
                results[i] = hit
            else:
                cold.append(i)

        def fetch(j: int) -> ChunkData | None:
            try:
                return self._fetch_chunk(pairs[j][0], pairs[j][1], metric, dims)
            except Exception:
                if safe:
                    return None
                raise

        if len(cold) == 1:
            results[cold[0]] = fetch(cold[0])
        elif cold:
            with ThreadPoolExecutor(max_workers=min(self.max_workers, len(cold))) as ex:
                for i, cd in zip(cold, ex.map(fetch, cold)):
                    results[i] = cd
        return [results[i] for i in range(len(pairs))]

    def load_chunks(self, view_id: int, chunks: Sequence[tuple[date, date]], metric: str) -> list[ChunkData | None]:
        return self.load_many([(view_id, ch) for ch in chunks], metric)

    # view index -------------------------------------------------------
    # One index per cache folder, always built for the configured default metric:
    # whether a project is present in a view does not depend on the metric, so a
    # per-call metric override never builds (or reads) a second index.

    def _index_window(self) -> tuple[date, date]:
        t = self.today()
        y, m = divmod(t.year * 12 + t.month - 1 - (INDEX_MONTHS - 1), 12)
        return date(y, m + 1, 1), t

    def _index_names(self, metric: str, start: date) -> tuple[str, list]:
        tag = f"{start.strftime('%Y%m')}-{_hash(metric)[:6]}"
        return f"viewindex-{tag}", [CACHE_SCHEMA, "view-index", metric, start.isoformat()]

    def _view_index_entry(self, vid: int, metric: str, start: date) -> tuple[str, list]:
        tag = f"{vid}-{start.strftime('%Y%m')}-{_hash(metric)[:6]}"
        return f"viewindexv-{tag}", [CACHE_SCHEMA, "view-index-view", vid, metric, start.isoformat()]

    @staticmethod
    def _index_ok(payload: Any) -> bool:
        return isinstance(payload, dict) and isinstance(payload.get("views"), dict) and all(
            isinstance(v, dict) and isinstance(v.get("projects"), list) for v in payload["views"].values()
        )

    @staticmethod
    def _view_entry_window_end(payload: Any) -> date | None:
        """A per-view entry is {"projects": [...], "window_end": "YYYY-MM-DD"}; the older bare list has
        no window end, so it cannot be reused."""
        if not (isinstance(payload, dict) and isinstance(payload.get("projects"), list)):
            return None
        try:
            return date.fromisoformat(str(payload.get("window_end")))
        except ValueError:
            return None

    def read_index(self, metric: str | None = None) -> tuple[dict[str, Any] | None, str]:
        """(payload, "fresh" | "stale" | "none"). Stale = served while a refresh runs.
        `metric` is accepted for compatibility and ignored (one index, default metric)."""
        metric = self.config.metric
        now = self._now()
        start, _ = self._index_window()
        name, key = self._index_names(metric, start)
        entry = self.cache.read(name, None, now, key)
        current = entry is not None and self._index_ok(entry["payload"])
        if not current:
            entry = self.cache.read_latest(
                "viewindex-",
                lambda k: isinstance(k, list) and k[:3] == [CACHE_SCHEMA, "view-index", metric],
            )
            if entry is None or not self._index_ok(entry["payload"]):
                return None, "none"
        payload = entry["payload"]
        ttl = self.config.ttl_index_s
        if payload.get("errors"):
            ttl = min(ttl, INDEX_ERROR_RETRY_S)
        fresh = current and (now - float(entry["fetched_at"]) < ttl)
        return payload, "fresh" if fresh else "stale"

    def cached_index(self, metric: str | None = None) -> dict[str, Any] | None:
        """Any cached index (fresh or stale); never builds."""
        return self.read_index()[0]

    @contextmanager
    def _index_flock(self):
        """A cross-process lock (flock on index.lock in the cache folder) held for a whole build, in addition
        to the in-process registry. Yields True when it had to wait for another process. Best-effort: with no
        lock file (read-only folder) the build goes ahead unlocked."""
        fd = None
        try:
            fd = os.open(paths.private_dir(self.cache.dir) / "index.lock", os.O_RDWR | os.O_CREAT, 0o600)
        except OSError:
            pass
        waited = False
        try:
            if fd is not None:
                try:
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError:
                    waited = True
                    fcntl.flock(fd, fcntl.LOCK_EX)
            yield waited
        finally:
            if fd is not None:
                try:
                    fcntl.flock(fd, fcntl.LOCK_UN)
                finally:
                    os.close(fd)

    def _build_key(self) -> str:
        return str(self.cache.dir)

    def index_building(self) -> bool:
        with _BUILD_LOCK:
            b = _BUILDS.get(self._build_key())
            return bool(b and b.thread is not None and not b.done.is_set())

    def _start_build(self, progress: Callable[[str], None] | None, background: bool) -> tuple[_Build | None, bool]:
        """The single-flight registry. Starts a build thread, or returns the one already running
        (False). Background starts are skipped for a while after a failed build; a foreground
        caller is not."""
        key = self._build_key()
        with _BUILD_LOCK:
            b = _BUILDS.get(key)
            if b is not None:
                if b.thread is not None and not b.done.is_set():
                    return b, False
                if background and b.failed_at is not None and time.monotonic() - b.failed_at < INDEX_FAIL_BACKOFF_S:
                    return b, False
            nb = _Build()

            def run() -> None:
                try:
                    with self._index_flock() as waited:
                        if waited:  # another process was building: use what it stored if that is fresh
                            idx, st = self.read_index()
                            if idx is not None and st == "fresh":
                                nb.result = idx
                                return
                        nb.result = self._build_index_now(progress)
                except Exception as e:  # noqa: BLE001 - recorded; a background start is retried after the backoff
                    nb.exc = e
                    nb.failed_at = time.monotonic()
                    nb.error = f"{type(e).__name__}: {sanitise_error(e, 120)}"
                finally:
                    nb.done.set()

            nb.thread = threading.Thread(target=run, daemon=True, name="cloudability-index-build")
            _BUILDS[key] = nb
            nb.thread.start()
            return nb, True

    def start_index_build(self, metric: str | None = None) -> bool:
        """Start a background (daemon thread) index build. Single-flight per cache
        folder, shared with foreground builds; not restarted for a while after a
        failed build; never started when background builds are disabled. True if started."""
        if not self.background_builds:
            return False
        return self._start_build(None, background=True)[1]

    def wait_for_index_build(self, timeout: float | None = None) -> bool:
        """Join a running build (foreground or background). True when none is running afterwards."""
        with _BUILD_LOCK:
            b = _BUILDS.get(self._build_key())
        if b is not None and b.thread is not None and b.thread is not threading.current_thread():
            b.done.wait(timeout)
        return not self.index_building()

    wait_for_builds = wait_for_index_build

    def last_build_error(self) -> str:
        with _BUILD_LOCK:
            b = _BUILDS.get(self._build_key())
            return b.error if b else ""

    def index_status(self, metric: str | None = None) -> dict:
        idx, st = self.read_index()
        building = self.index_building()
        out: dict[str, Any] = {"state": "building" if building else st, "cached": st if idx else "none"}
        if idx:
            out.update({"views": len(idx["views"]),
                        "failed_views": {str(k): v for k, v in idx.get("errors", {}).items()},
                        "window": idx.get("window"), "built_at": idx.get("built_at")})
        err = self.last_build_error()
        if err and not building:
            out["last_build_error"] = err
        return out

    def _build_index_now(self, progress: Callable[[str], None] | None = None) -> dict[str, Any]:
        """Blocking build (run through the registry): every view's trailing 12 months of
        projects. A per-view entry is reused only while younger than INDEX_REUSE_MAX_AGE_S
        (and the index TTL); each stores the date its data runs to, and the combined
        window ends at the earliest of those, so coverage is never overstated. Failures are
        recorded in "errors" (successes are still cached) and retried on the next refresh."""
        metric = self.config.metric
        now = self._now()
        views = self.client.get_views().get("result", [])
        start, end = self._index_window()
        say = progress or (lambda _m: None)
        reuse_age = min(INDEX_REUSE_MAX_AGE_S, self.config.ttl_index_s)
        done = [0]
        total = len(views)

        def one(v: dict):
            vid = int(v["id"])
            name, key = self._view_index_entry(vid, metric, start)
            hit = self.cache.read(name, reuse_age, now, key)
            if hit is not None:
                wend = self._view_entry_window_end(hit["payload"])
                if wend is not None:
                    return vid, v, hit["payload"]["projects"], wend, None, "cached", hit["payload"].get("names") or {}
            try:
                rows = self.client.run_cost_report_async(
                    start.isoformat(), end.isoformat(), INDEX_DIMENSIONS, metric, vid
                )
            except Exception as e:  # noqa: BLE001 - recorded, view skipped
                return vid, v, None, None, f"{type(e).__name__}: {sanitise_error(e, 120)}", "failed", {}
            found: dict[str, str] = {}  # identifier (name when unset) -> display name seen
            for r in rows:
                pk = row_project(r)
                if pk:
                    found.setdefault(pk, str(r.get("vendor_account_name") or "").strip())
            projects = sorted(found)
            names = {k.lower(): n for k, n in sorted(found.items()) if n and n.lower() != k.lower()}
            self.cache.write(name, key, {"projects": projects, "names": names, "window_end": end.isoformat()}, now)
            return vid, v, projects, end, None, "fetched", names

        out: dict[str, Any] = {"views": {}, "errors": {}, "window": [start.isoformat(), end.isoformat()],
                               "built_at": _iso(now)}
        ends: list[date] = []
        with ThreadPoolExecutor(max_workers=self.max_workers) as ex:
            futures = [ex.submit(one, v) for v in views]
            for fut in as_completed(futures):
                vid, v, projects, wend, err, how, vnames = fut.result()
                if err:
                    out["errors"][str(vid)] = err
                else:
                    out["views"][str(vid)] = {"title": str(v.get("title", "")).strip(), "projects": projects,
                                              "names": vnames, "window_end": wend.isoformat()}
                    ends.append(wend)
                done[0] += 1
                say(f"index: view {vid} {how} ({done[0]}/{total})")
        if ends:
            out["window"][1] = min(ends + [end]).isoformat()
        name, key = self._index_names(metric, start)
        self.cache.write(name, key, out, now)
        return out

    def build_index(self, metric: str | None = None, progress: Callable[[str], None] | None = None,
                    force: bool = False, deadline: float | None = None) -> dict[str, Any]:
        """Blocking. Returns a fresh cached index unless force; otherwise starts the build through
        the single-flight registry, or joins the one already running, and waits for it. Per-view
        entries older than 20 hours are refetched either way. Raises if that build failed outright, and
        DeadlineExceeded if `deadline` (a time.monotonic() value) passes first (the build carries on)."""
        if not force:
            idx, st = self.read_index()
            if idx is not None and st == "fresh":
                return idx
        b, started = self._start_build(progress, background=False)
        if not started and progress is not None:
            progress("index: joining a build already running")
        assert b is not None
        if not b.done.wait(None if deadline is None else max(0.0, deadline - time.monotonic())):
            raise DeadlineExceeded()
        if b.exc is not None:
            raise b.exc
        assert b.result is not None
        return b.result

    def index_for_request(self, metric: str | None = None) -> tuple[dict[str, Any] | None, str, bool]:
        """Never blocks on a build. (index or None, state, build_started). A stale
        index is served while a background refresh runs; with none at all, a
        background build is started and the caller should degrade."""
        idx, st = self.read_index()
        if st == "fresh":
            return idx, "fresh", False
        started = self.start_index_build()
        if idx is not None:
            return idx, "stale", started
        return None, "building" if (started or self.index_building()) else "none", started

    # scope ------------------------------------------------------------

    def _gap_check(self, used: dict[tuple[int, date, date], dict[str, str]], metric: str) -> tuple[list[dict], int]:
        """cost_data_gaps: for each (view, month chunk) that served rows, a small date,vendor report
        (cached like the chunk rows); runs of low-cost days per vendor present in those rows.
        -> (merged runs, number of reports that could not be fetched). Never raises."""
        if not used:
            return [], 0
        keys = sorted(used)
        try:
            loaded = self.load_many([(v, (s, e)) for v, s, e in keys], metric, DAILY_DIMENSIONS, safe=True)
        except Exception:  # noqa: BLE001 - detection is best-effort
            return [], len(keys)
        today = self.today()
        runs: list[dict] = []
        failed = 0
        for (v, s, e), cd in zip(keys, loaded):
            if cd is None:
                failed += 1
                continue
            try:
                for g in detect_gaps(cd.rows, used[(v, s, e)], s, e, today, metric):
                    runs.append({"vendor": g["vendor"], "view_id": v, **{k: g[k] for k in g if k != "vendor"}})
            except SpendError:
                failed += 1
        return merge_gaps(runs), failed

    def collect(self, projects: Iterable[str], start: date, end: date, metric: str,
                name_match: Iterable[str] = (), deadline: float | None = None) -> ScopeData:
        """Fetch records for `projects` over [start, end]. Every requested project ends with
        exactly one status, and each (project, month chunk) is served by exactly one view:
        the default view when it has rows for the project in that chunk, otherwise the first other view
        (ascending id) that the 12-month index lists for the project and that has rows for it.
        A row belongs to a requested project when its vendor_account_identifier equals it (a row
        with an empty or "(not set)" identifier falls back to its name). Names in `name_match`
        (requested values that are not CSV identifiers) also match a row's display name, but only
        when no identifier matched in that chunk. Values are whitespace-stripped and matched
        case-insensitively; records carry the requested spelling in vendor_account_identifier.
        Also detects source-data gaps and unattributed default-view spend (reported, never applied to the
        numbers). Never waits for the view index: with none cached, projects without any
        default-view rows are `unresolved` and a background build starts. `deadline` (a time.monotonic()
        value) is checked between batches of chunks and between phases: when it passes, what has been
        loaded is returned with deadline_hit set (loaded chunks are cached, so a retry continues)."""
        names = list(dict.fromkeys(p for p in projects if p and p.strip()))
        canon: dict[str, str] = {}
        for p in names:
            canon.setdefault(p.strip().lower(), p)
        by_name = {p.strip().lower() for p in name_match}
        fb = {k: v for k, v in canon.items() if k in by_name}  # display-name fallback targets
        chunks = month_chunks(start, end)
        default = self.config.default_view_id
        freshness: list[dict] = []
        records: list[tuple[str, dict]] = []
        status: dict[str, str] = {}
        view_of: dict[str, int | None] = {}
        served: dict[str, dict[int, list[str]]] = {}  # project -> view -> months it served
        provisional = [False]
        display: dict[str, str] = {}  # project -> display name
        used: dict[tuple[int, date, date], dict[str, str]] = {}  # (view, chunk) -> vendors of the rows used
        unattributed: list[dict] = []
        hit = [False]

        def expired() -> bool:
            if deadline is not None and time.monotonic() >= deadline:
                hit[0] = True
            return hit[0]

        def load_batched(pairs: Sequence[tuple[int, tuple[date, date]]]) -> list[ChunkData | None]:
            """load_many in batches of max_workers, checking the deadline between batches (None = not loaded)."""
            if deadline is None:
                return self.load_many(pairs, metric)
            out: list[ChunkData | None] = [None] * len(pairs)
            step = max(1, self.max_workers)
            for i in range(0, len(pairs), step):
                if expired():
                    break
                out[i:i + step] = self.load_many(pairs[i:i + step], metric)
            return out

        def ingest(cd: ChunkData, only: set[str]) -> set[str]:
            """Add this chunk's rows for the requested projects named in `only` (canonical names)."""
            freshness.append({
                "view_id": cd.view_id, "start": cd.start.isoformat(), "end": cd.end.isoformat(),
                "fetched_at": _iso(cd.fetched_at), "from_cache": cd.from_cache,
                "provisional": cd.provisional,
            })
            provisional[0] = provisional[0] or cd.provisional
            month = cd.start.strftime("%Y-%m")
            seen: set[str] = set()
            hits: list[tuple[str, dict, bool]] = []  # (requested name, row, row has an identifier)
            late: list[tuple[str, dict]] = []
            for r in cd.rows:
                ident, nm = norm_key(r.get("vendor_account_identifier")), norm_key(r.get("vendor_account_name"))
                name = canon.get(ident or nm)
                if name is not None and name in only:
                    hits.append((name, r, bool(ident)))
                    seen.add(name)
                elif ident and nm in fb:
                    late.append((fb[nm], r))
            matched = set(seen)
            for name, r in late:  # display-name fallback: only for projects no identifier matched here
                if name in only and name not in matched:
                    hits.append((name, r, True))
                    seen.add(name)
            vend = used.setdefault((cd.view_id, cd.start, cd.end), {}) if hits else {}
            for name, r, has_ident in hits:
                disp = str(r.get("vendor_account_name") or "").strip()
                if disp:
                    display.setdefault(name, disp)
                r = {**r, "vendor_account_identifier": name}
                if not has_ident:
                    r["vendor_account_name"] = name
                v = str(r.get("vendor") or "").strip()
                if v:
                    vend[v.lower()] = v
                records.append((month, r))
            for name in seen:
                served.setdefault(name, {}).setdefault(cd.view_id, []).append(month)
            return seen

        everyone = set(names)
        pending: list[set[str]] = []  # per chunk: projects with no row yet
        for ch, cd in zip(chunks, load_batched([(default, ch) for ch in chunks])):
            if cd is None:  # deadline: this chunk was not loaded
                pending.append(set(everyone))
                continue
            pending.append(everyone - ingest(cd, everyone))
            share, amount = unattributed_share(cd.rows, metric)
            if share > UNATTRIBUTED_THRESHOLD_PCT:
                unattributed.append({"month": ch[0].strftime("%Y-%m"), "view_id": default,
                                     "share_pct": r2(share), "amount": r2(amount)})
        no_rows = [p for p in names if p not in served]  # no rows in any chunk so far

        titles: dict[int, str] = {}
        errors: dict[int, str] = {}
        index_used = any(pending) and not hit[0]
        index_state, window, started, ahead = "", None, False, False
        idx = None
        if index_used:
            idx, index_state, started = self.index_for_request()
        if hit[0]:  # out of time before the view index could be consulted
            for p in no_rows:
                status[p], view_of[p] = "unknown", None
        elif idx is None:
            for p in no_rows:
                if any(p in pc for pc in pending):
                    status[p], view_of[p] = "unresolved", None
        else:
            titles = {int(k): v["title"] for k, v in idx["views"].items()}
            errors = {int(k): v for k, v in idx.get("errors", {}).items()}
            index = {int(k): {n.strip().lower() for n in v["projects"] if n and n.strip()}
                     for k, v in idx["views"].items()}
            name_idx = {int(k): {n.strip().lower() for n in (v.get("names") or {}).values() if n and n.strip()}
                        for k, v in idx["views"].items()}
            window = tuple(idx.get("window") or ())  # type: ignore[assignment]
            covered = False
            try:
                if len(window) == 2:
                    w0, w1 = date.fromisoformat(window[0]), date.fromisoformat(window[1])
                    inside = w0 <= start
                    covered = inside and end <= w1 + timedelta(days=INDEX_COVERAGE_SLACK_DAYS)
                    ahead = inside and not covered  # not covered only because the index is older than the range
            except ValueError:
                pass
            if ahead and index_state == "fresh":
                started = self.start_index_build() or started  # month to date: refresh in the background
            fallbacks = sorted(v for v in index if v != default)
            def listed(p: str, v: int) -> bool:
                k = p.strip().lower()
                return k in index[v] or (k in by_name and k in name_idx[v])

            cand = {p: [v for v in fallbacks if listed(p, v)] for p in names}
            # Round r: every project still without rows in a chunk tries its r-th fallback view, so
            # each (project, chunk) is taken from the first view (ascending id) that has rows for it.
            rnd = 0
            while True:
                want: dict[tuple[int, int], set[str]] = {}
                for ci, pc in enumerate(pending):
                    for p in pc:
                        if len(cand[p]) > rnd:
                            want.setdefault((cand[p][rnd], ci), set()).add(p)
                if not want:
                    break
                order = sorted(want)
                loaded = load_batched([(v, chunks[ci]) for v, ci in order])
                for (v, ci), cd in zip(order, loaded):
                    if cd is not None:
                        pending[ci] -= ingest(cd, want[(v, ci)])
                if hit[0]:
                    break
                rnd += 1
            assign = resolve_views(no_rows, index, default, name_idx, by_name)
            for p in no_rows:
                v = assign[p]
                view_of[p] = v
                if v is None:
                    status[p] = "unknown" if (errors or not covered) else "not_visible"
                else:
                    status[p] = "no_spend_in_period" if covered else "unknown"
        for p, by_view in served.items():
            status[p] = "ok"
            view_of[p] = default if default in by_view else min(by_view, key=lambda v: (-len(by_view[v]), v))
        sources = {p: {v: sorted(ms) for v, ms in sorted(bv.items(), key=lambda kv: (kv[0] != default, kv[0]))}
                   for p, bv in served.items()}
        building = self.index_building()
        gaps, gap_failed = ([], 0) if expired() else self._gap_check(used, metric)
        return ScopeData(records, status, view_of, freshness, titles, errors, index_used,
                         index_state, window, started or (ahead and building), provisional[0], ahead,
                         "" if building else self.last_build_error(), sources, display, gaps, gap_failed,
                         unattributed, hit[0])


# ── Service (what the MCP tools call) ────────────────────────────────────


def _validate_common(granularity: str, level: str, metric: str, config: SpendConfig) -> tuple[str, str, str]:
    granularity = (granularity or "total").lower()
    if granularity not in ("total", "month"):
        raise SpendError("granularity must be 'total' or 'month'")
    level = (level or "").strip().lower() or base_level(config)
    if level not in LEVEL_FIELDS:
        raise SpendError("level must be one of: category, type, service")
    return granularity, level, validate_metric(metric.strip()) if metric else config.metric


def month_labels(start: date, end: date) -> list[str]:
    return [c[0].strftime("%Y-%m") for c in month_chunks(start, end)]


def _split_names(text: str) -> list[str]:
    return [p.strip() for p in (text or "").split(",") if p.strip()]


class SpendService:
    """What the MCP tools call.

    `client_provider()` returns the Cloudability client and `settings_provider()` returns an object with
    view_id, view_name, environment_id, region and public_key_fingerprint. Both are called on every call, so
    a key, environment, region or view change takes effect without a restart."""

    def __init__(
        self,
        client_provider: Callable[[], Any],
        settings_provider: Callable[[], Any],
        now: Callable[[], float] | None = None,
        background_builds: bool = True,
    ):
        self.client_provider = client_provider
        self.settings_provider = settings_provider
        self._now = now
        self.background_builds = background_builds  # False: tools never start a background index build

    # helpers --------------------------------------------------------

    def _namespace(self, st: Any) -> str:
        return namespace_for(str(st.environment_id or ""), str(st.region or ""),
                             str(st.public_key_fingerprint or ""))

    def _setup(self) -> tuple[SpendConfig, Collections, SpendEngine]:
        st = self.settings_provider()  # read on every call
        if st.view_id in (None, ""):
            raise SpendError(NO_VIEW_MESSAGE)
        try:
            view_id = int(st.view_id)
        except (TypeError, ValueError):
            raise SpendError(NO_VIEW_MESSAGE) from None
        cfg = replace(load_config(), default_view_id=view_id, view_name=str(st.view_name or "").strip())
        cols = load_collections()
        cache_dir = paths.private_dir(namespace_dir(self._namespace(st)))
        return cfg, cols, SpendEngine(self.client_provider(), cfg, cache_dir, self._now,
                                      background_builds=self.background_builds)

    def clear_cache(self) -> None:
        """Remove this environment/region/key's cache folder (replace key, environment or region change)."""
        clear_namespace(self._namespace(self.settings_provider()))

    @staticmethod
    def _deadline(deadline: float | None) -> float:
        """`deadline` is an absolute time.monotonic() value; the default is DEFAULT_DEADLINE_S from now."""
        return time.monotonic() + DEFAULT_DEADLINE_S if deadline is None else deadline

    @staticmethod
    def _finish(out: dict, cfg: SpendConfig, hit: bool = False) -> dict:
        """Attach the spend.toml "Not used: ..." notes and, when the deadline passed, the partial flag and note."""
        if cfg.config_warnings or hit:
            w = out.setdefault("warnings", {})
            if cfg.config_warnings:
                w["config"] = list(cfg.config_warnings)
            if hit:
                out["partial"] = True
                w["deadline"] = {"note": DEADLINE_NOTE}
        return out

    @staticmethod
    def _canon_projects(names: Iterable[str], cols: Collections) -> list[str]:
        """De-duplicate case-insensitively, using your mapping file's spelling when it matches."""
        lc = {p.lower(): p for p in cols.project_platforms}
        out: dict[str, str] = {}
        for n in names:
            n = n.strip()
            if n:
                out.setdefault(n.lower(), lc.get(n.lower(), n))
        return list(out.values())

    @staticmethod
    def _partition(
        projects: Sequence[str], aggs: dict[str, Agg], scope: ScopeData, cfg: SpendConfig,
        with_sources: bool = False,
    ) -> tuple[list[Entry], list[tuple[str, str]]]:
        """-> (entries with data status, [(project, excluded status)]). with_sources adds each
        project's provenance: {view id: [months it served]}."""
        entries: list[Entry] = []
        excluded: list[tuple[str, str]] = []
        default = cfg.default_view_id
        for p in projects:
            st = scope.status.get(p, "unknown")
            if st in STATUS_EXCLUDED:
                excluded.append((p, st))
                continue
            extra: dict[str, Any] = {"status": st, "environment": environment_for(p, cfg.env_rules)}
            v = scope.view_of.get(p)
            if v is not None and v != default:
                extra["view"] = f"{v} {scope.view_titles.get(v, '')}".strip()
            nm = scope.names.get(p)
            if nm and norm_key(nm) != norm_key(p):
                extra["cloudability_name"] = nm
            if with_sources and scope.sources.get(p):
                extra["sources"] = {str(k): list(ms) for k, ms in scope.sources[p].items()}
            entries.append((p, aggs.get(p) or Agg(), extra))
        return entries, excluded

    @staticmethod
    def _head(rng: tuple[date, date, bool], scope: ScopeData, metric: str, level: str,
              granularity: str | None = None) -> dict:
        h: dict[str, Any] = {
            "range": {"start": rng[0].isoformat(), "end": rng[1].isoformat(), "timezone": "UTC"},
            "partial": rng[2] or scope.deadline_hit, "provisional": scope.provisional, "metric": metric, "level": level,
        }
        if granularity:
            h["granularity"] = granularity
        return h

    def _warnings(
        self, projects: Sequence[str], scope: ScopeData, top: Agg, cfg: SpendConfig,
        cols: Collections, include_duplicates: bool, rng: tuple[date, date, bool], names: bool = False,
    ) -> dict:
        w: dict[str, Any] = {}
        if rng[2]:
            w["partial"] = {"note": "The range includes today (UTC), so it is month to date; the end was "
                                    "clamped to today and the latest days are incomplete."}
        if scope.provisional:
            lag = cfg.provisional_lag_s / 86400
            w["provisional"] = {"note": f"Some data was fetched within about {lag:g} days of the period end and "
                                        "may still change as billing data lands; it refreshes every few hours "
                                        "until final."}
        if include_duplicates:
            dups = {p: cols.duplicates[p] for p in projects if p in cols.duplicates}
            if dups:
                w["duplicate_membership"] = {
                    "note": "These projects belong to more than one platform and are counted in each.",
                    "projects": dups,
                }
        view = view_label(cfg.view_name)
        ex = render_excluded([(p, scope.status.get(p, "unknown")) for p in projects])
        if ex:
            w["excluded"] = {
                st: {"count": d["count"], "note": EXCLUDED_NOTES[st].format(view=view),
                     **({"projects": d["projects"], **({"truncated": True} if d.get("truncated") else {})}
                        if names else {})}
                for st, d in ex.items()
            }
        if scope.index_used:
            vi: dict[str, Any] = {"state": scope.index_state}
            if scope.index_state in ("building", "none"):
                vi["note"] = INDEX_BUILDING_NOTE if scope.index_state == "building" else (
                    "view index unavailable and a build was not started (recent failure); retry later")
            elif scope.index_state == "stale":
                vi["note"] = "using a stale view index; refreshing in the background"
            if scope.index_ahead:
                vi["note"] = INDEX_AHEAD_NOTE
            if scope.index_error:
                vi["last_build_error"] = scope.index_error
            if scope.index_window:
                vi["window"] = list(scope.index_window)
            if scope.index_errors:
                vi["failed_views"] = {str(k): v for k, v in scope.index_errors.items()}
            w["view_index"] = vi
        non_default: dict[str, int] = {}  # projects with at least one month served by a view other than the default
        by_month: dict[str, dict[str, int]] = {}  # month -> view id -> projects served from it
        for p in projects:
            for v, ms in scope.sources.get(p, {}).items():
                if v == cfg.default_view_id:
                    continue
                label = f"{v} {scope.view_titles.get(v, '')}".strip()
                non_default[label] = non_default.get(label, 0) + 1
                for m in ms:
                    d = by_month.setdefault(m, {})
                    d[str(v)] = d.get(str(v), 0) + 1
        if non_default:
            w["non_default_view"] = {"projects_by_view": non_default}
            w["non_default_months"] = {
                "note": f"{view} ({cfg.default_view_id}) had no rows for these projects in these months (its GCP "
                        "spend can be listed under billing-account IDs or labels instead of project names), so "
                        "each project-month was taken from the first other view, in ascending view-id order, "
                        "that had rows for it. Exactly one view serves each project-month, so nothing is "
                        "double counted. Counts are projects per view.",
                "months": {m: dict(sorted(by_month[m].items(), key=lambda kv: int(kv[0])))
                           for m in sorted(by_month)},
            }
        nsp = sum(1 for p in projects if scope.status.get(p) == "no_spend_in_period")
        if nsp:
            w["no_spend_in_period"] = {"count": nsp}
        if top.total > ROUNDING_EPS:
            share = top.cats.get(cfg.unset_label, 0.0) / top.total * 100
            if share > 5:
                w["unclassified_share_pct"] = r2(share)
        if scope.gaps:
            vendors = "/".join(sorted({g["vendor"] for g in scope.gaps}))
            w["cost_data_gaps"] = {"note": GAP_NOTE.format(vendor=vendors), "gaps": scope.gaps}
        if scope.gap_check_failed:
            w["cost_data_gaps_check"] = {"note": "The daily gap check could not run for some view-months; "
                                                 "gaps there would not be flagged.",
                                         "failed": scope.gap_check_failed}
        if scope.unattributed:
            w["unattributed_spend"] = {"note": UNATTRIBUTED_NOTE.format(view=view), "months": scope.unattributed}
        w["data_freshness"] = scope.freshness
        return w

    @staticmethod
    def _name_match(names: Iterable[str], cols: Collections) -> list[str]:
        """Requested values that are not CSV identifiers: these may also match a display name."""
        return [p for p in names if p not in cols.project_platforms]

    # tools ----------------------------------------------------------

    def get_platform_spend(
        self, platform: str, start_date: str = "", end_date: str = "", by_environment: bool = True,
        granularity: str = "total", level: str = "", max_projects: int = 10, metric: str = "",
        detail: bool = False, deadline: float | None = None,
    ) -> dict:
        deadline = self._deadline(deadline)
        cfg, cols, eng = self._setup()
        granularity, level, metric = _validate_common(granularity, level, metric, cfg)
        if max_projects < 1:
            raise SpendError("max_projects must be at least 1")
        rng = resolve_dates(start_date, end_date, eng.today())
        start, end, _ = rng
        months = month_labels(start, end) if granularity == "month" else None
        is_all = (platform or "").strip().lower() == "all"
        plats = list(cols.platform_projects)
        if is_all:
            names = plats
        else:
            match, cands = match_platform(platform, plats)
            if match is None:
                return {"error": "Platform not found" if not cands else "Ambiguous platform",
                        "candidates": cands or suggest_platforms(platform, plats)}
            names = [match]
        all_projects = sorted({p for n in names for p in cols.platform_projects[n]})
        scope = eng.collect(all_projects, start, end, metric, deadline=deadline)
        aggs = build_project_aggs(scope.records, cfg, level, metric)
        head = self._head(rng, scope, metric, level, granularity)
        if is_all:
            rows = []
            for n in names:
                projs = cols.platform_projects[n]
                ents, _exc = self._partition(projs, aggs, scope, cfg)
                node = render_agg(merge_aggs(a for _, a, _ in ents), months)
                sts = [scope.status.get(p, "unknown") for p in projs]
                counts = {
                    "ok": sts.count("ok"),
                    "with_nonzero_spend": sum(1 for _, a, x in ents if x["status"] == "ok"
                                              and abs(a.total) >= ROUNDING_EPS),
                    **{s: sts.count(s) for s in ("no_spend_in_period", "not_visible", "unknown", "unresolved")},
                }
                rows.append({"platform": n, "csv_project_count": len(projs), "visible_project_count": len(ents),
                             **node, "status_counts": counts})
            uniq_ents, _ = self._partition(all_projects, aggs, scope, cfg)
            top = merge_aggs(a for _, a, _ in uniq_ents)
            sum_platforms = sum(merge_aggs(
                (aggs.get(p) or Agg()) for p in cols.platform_projects[n]
                if scope.status.get(p) in STATUS_DATA).total for n in names)
            out = {**head, **render_agg(top, months),
                   "unique_project_count": len(all_projects),
                   "unique_visible_project_count": len(uniq_ents),
                   "sum_of_platform_totals": r2(sum_platforms),
                   "note": "total counts each project once. sum_of_platform_totals counts a project listed "
                           "under several platforms once per platform, so it exceeds total by the duplicates' "
                           "extra copies.",
                   "platforms": rows}
            out["warnings"] = self._warnings(all_projects, scope, top, cfg, cols, True, rng)
            return self._finish(out, cfg, scope.deadline_hit)
        n = names[0]
        projs = cols.platform_projects[n]
        ents, exc = self._partition(projs, aggs, scope, cfg, with_sources=detail)
        node = build_platform_node(ents, exc, by_environment, cfg, max_projects, months, detail)
        top = merge_aggs(a for _, a, _ in ents)
        out = {**head, "platform": n, **node}
        out["warnings"] = self._warnings(projs, scope, top, cfg, cols, True, rng)
        return self._finish(out, cfg, scope.deadline_hit)

    def get_project_spend(
        self, projects: str, start_date: str = "", end_date: str = "", granularity: str = "total",
        level: str = "", metric: str = "", detail: bool = True, deadline: float | None = None,
    ) -> dict:
        deadline = self._deadline(deadline)
        cfg, cols, eng = self._setup()
        granularity, level, metric = _validate_common(granularity, level, metric, cfg)
        names = self._canon_projects(_split_names(projects), cols)
        if not names:
            raise SpendError("projects must be a comma-separated list of project names")
        rng = resolve_dates(start_date, end_date, eng.today())
        start, end, _ = rng
        months = month_labels(start, end) if granularity == "month" else None
        scope = eng.collect(names, start, end, metric, self._name_match(names, cols), deadline=deadline)
        aggs = build_project_aggs(scope.records, cfg, level, metric)
        ents, exc = self._partition(names, aggs, scope, cfg, with_sources=True)

        def ident(p: str) -> dict:
            return {"platforms": cols.project_platforms.get(p, []), "in_csv": p in cols.project_platforms}

        rendered = [render_project(p, a, {**ident(p), **extra}, months, detail)
                    for p, a, extra in sorted(ents, key=lambda e: (-abs(e[1].total), e[0]))]
        for p, st in sorted(exc):
            rendered.append({"project": p, **ident(p), "status": st,
                             "environment": environment_for(p, cfg.env_rules), "total": None})
        top = merge_aggs(a for _, a, _ in ents)
        out = {**self._head(rng, scope, metric, level, granularity), **render_agg(top, months),
               "requested_project_count": len(names),
               "csv_project_count": sum(1 for p in names if p in cols.project_platforms),
               "visible_project_count": len(ents), "projects": rendered}
        out["warnings"] = self._warnings(names, scope, top, cfg, cols, False, rng)
        return self._finish(out, cfg, scope.deadline_hit)

    def explain_category(
        self, target: str, category: str, start_date: str = "", end_date: str = "", top_n: int = 25,
        metric: str = "", level: str = "", deadline: float | None = None,
    ) -> dict:
        deadline = self._deadline(deadline)
        cfg, cols, eng = self._setup()
        _, level, metric = _validate_common("total", level, metric, cfg)
        if top_n < 1:
            raise SpendError("top_n must be at least 1")
        rng = resolve_dates(start_date, end_date, eng.today())
        start, end, _ = rng
        tgt = (target or "").strip()
        if not tgt:
            raise SpendError("target must be a platform, 'all', or a comma-separated list of projects")
        plats = list(cols.platform_projects)
        if tgt.lower() == "all":
            names, label = sorted(cols.project_platforms), {"platform": "all"}
        else:
            match, cands = match_platform(tgt, plats)
            if match:
                names, label = list(cols.platform_projects[match]), {"platform": match}
            elif cands:
                return {"error": "Ambiguous platform", "candidates": cands}
            elif "," in tgt:
                names = self._canon_projects(_split_names(tgt), cols)
                label = {"projects": names if len(names) <= 20 else f"{len(names)} projects"}
            else:
                lc = {p.lower(): p for p in cols.project_platforms}
                known = lc.get(tgt.lower())
                if known is None:
                    idx = eng.cached_index(metric)
                    t = tgt.lower()
                    if idx and any(t == p.strip().lower() for v in idx["views"].values() for p in v["projects"]) or (
                            idx and any(t == n.strip().lower() for v in idx["views"].values()
                                        for n in (v.get("names") or {}).values())):
                        known = tgt
                if known is None:
                    return {"error": "Platform not found", "candidates": suggest_platforms(tgt, plats),
                            "hint": "Use 'all', a platform name, or a comma-separated list of project names "
                                    "(get_project_spend handles a single project outside your mapping file)."}
                names, label = [known], {"projects": [known]}
        scope = eng.collect(names, start, end, metric, self._name_match(names, cols), deadline=deadline)
        want = (category or "").strip().lower()
        sel = [(m, r) for m, r in scope.records if categorise(r, cfg, level).lower() == want]
        known_cats = sorted({categorise(r, cfg, level) for _, r in scope.records})
        total = sum(row_cost(r, metric) for _, r in sel)

        def group(keyfn) -> dict:
            acc: dict[str, float] = {}
            for _, r in sel:
                k = keyfn(r)
                acc[k] = acc.get(k, 0.0) + row_cost(r, metric)
            items = sorted(acc.items(), key=lambda kv: (-abs(kv[1]), kv[0]))

            def pct(v: float) -> float | None:
                return r2(v / total * 100) if abs(total) > ROUNDING_EPS else None

            shown = {k: {"cost": r2(v), "pct": pct(v)} for k, v in items[:top_n] if abs(v) >= ROUNDING_EPS}
            rest = items[top_n:]
            if rest:
                rv = sum(v for _, v in rest)
                shown["(other)"] = {"count": len(rest), "cost": r2(rv), "pct": pct(rv)}
            return shown

        canonical = next((c for c in known_cats if c.lower() == want), (category or "").strip())
        out = {**self._head(rng, scope, metric, level), **label, "category": canonical,
               "total": r2(total), "row_count": len(sel),
               "by_service_name": group(lambda r: _field_value(r, "service_name", cfg.unset_label)),
               "by_atum_service_name": group(lambda r: _field_value(r, "atum_service_name", cfg.unset_label)),
               "by_transaction_type": group(lambda r: _field_value(r, "transaction_type", "Unknown")),
               "by_project": group(lambda r: row_project(r) or "?")}
        if not sel:
            out["note"] = "No spend in that category for this scope and period."
            out["categories_present"] = known_cats
        top = merge_aggs(build_project_aggs(scope.records, cfg, level, metric).values())
        out["warnings"] = self._warnings(names, scope, top, cfg, cols, False, rng, names=len(names) <= 200)
        return self._finish(out, cfg, scope.deadline_hit)

    def _visibility(self, cols: Collections, cfg: SpendConfig, eng: SpendEngine, build: bool,
                    deadline: float | None = None) -> tuple[dict[str, str] | None, dict[str, str]]:
        """-> ({project: default_view | other_view | not_visible | unknown}, failed_views) or (None, {}).
        While any view failed to index, a project found in none of the others is `unknown`.
        Raises DeadlineExceeded when a build was needed and `deadline` passed first."""
        idx = eng.build_index(force=False, deadline=deadline) if build else eng.cached_index()
        if idx is None:
            return None, {}
        failed = {str(k): v for k, v in idx.get("errors", {}).items()}
        sets = {int(k): set(v["projects"]) for k, v in idx["views"].items()}
        res = resolve_views(cols.project_platforms, sets, cfg.default_view_id)
        missing = "unknown" if failed else "not_visible"
        return ({p: ("default_view" if v == cfg.default_view_id else "other_view" if v is not None else missing)
                 for p, v in res.items()}, failed)

    def list_platforms(self, check_visibility: bool = False, deadline: float | None = None) -> dict:
        deadline = self._deadline(deadline)
        cfg, cols, eng = self._setup()
        hit = False
        try:
            vis, failed = self._visibility(cols, cfg, eng, check_visibility, deadline)
        except DeadlineExceeded:  # the build carries on in the background and is cached for the retry
            vis, failed, hit = None, {}, True
        rows = []
        for n, projs in cols.platform_projects.items():
            envs: dict[str, int] = {}
            for p in projs:
                e = environment_for(p, cfg.env_rules)
                envs[e] = envs.get(e, 0) + 1
            row: dict[str, Any] = {"platform": n, "csv_project_count": len(projs), "environments": envs}
            if vis is not None:
                c = {"default_view": 0, "other_view": 0, "not_visible": 0, "unknown": 0}
                for p in projs:
                    c[vis[p]] += 1
                row["index_visibility_12m"] = c
            rows.append(row)
        out: dict[str, Any] = {"platforms": rows, "unique_project_count": len(cols.project_platforms),
                               "duplicates": cols.duplicates, "view_index": eng.index_status()}
        out["index_visibility_basis"] = (
            "trailing 12 months of spend, per view (not the requested period)" if vis is not None
            else "not checked (pass check_visibility=true; builds the view index, which takes several minutes "
                 "when cold)" if not hit else "not available yet: the view index is still building")
        if vis is not None:
            out["failed_views"] = failed
        if failed:
            out["index_visibility_note"] = ("Some views failed to index, so projects found in no indexed view are "
                                            "counted as unknown, not not_visible.")
        return self._finish(out, cfg, hit)

    def find_projects(self, search: str, limit: int = 50) -> dict:
        cfg, cols, eng = self._setup()
        s = (search or "").strip().lower()
        if not s:
            raise SpendError("search must not be empty")
        vis, failed = self._visibility(cols, cfg, eng, False)
        idx = eng.cached_index()
        display: dict[str, str] = {}  # identifier -> display name, from the cached view index
        for v in (idx["views"].values() if idx else ()):
            for k, n in (v.get("names") or {}).items():
                display.setdefault(k, n)
        hits = [p for p in cols.project_platforms
                if s in p.lower() or s in display.get(p.strip().lower(), "").lower()]
        out = []
        for p in sorted(hits)[: max(1, limit)]:
            d = {"project": p, "platforms": cols.project_platforms[p],
                 "environment": environment_for(p, cfg.env_rules)}
            if display.get(p.strip().lower()):
                d["cloudability_name"] = display[p.strip().lower()]
            if vis is not None:
                d["index_visibility_12m"] = vis[p]
            out.append(d)
        res = {"search": search, "match_count": len(hits), "returned": len(out), "projects": out,
               "index_visibility_basis": "trailing 12 months" if vis is not None
               else "not available (index not cached)"}
        if vis is not None:
            res["failed_views"] = failed
        return self._finish(res, cfg)

    # maintenance ----------------------------------------------------

    def index_status(self) -> dict:
        cfg, _cols, eng = self._setup()
        return eng.index_status(cfg.metric)

    def wait_for_index(self, timeout: float | None = None) -> bool:
        _cfg, _cols, eng = self._setup()
        return eng.wait_for_index_build(timeout)

    wait_for_builds = wait_for_index

    def warm(self, months: int = 3, progress: Callable[[str], None] = print,
             deadline: float | None = None) -> dict:
        """Build the view index, then fetch the last `months` full months for every
        project in your mapping file (the default view plus the fallback views they need). Reports
        progress and counts only, never cost data. Unlike the tools it has no deadline unless one
        is given (an absolute time.monotonic() value); at the deadline it returns what it has with
        "partial": true."""
        if months < 1 or months > MAX_RANGE_MONTHS:
            raise SpendError(f"months must be between 1 and {MAX_RANGE_MONTHS}")
        cfg, cols, eng = self._setup()
        t0 = time.monotonic()
        progress("index: refreshing (per-view entries under 20 hours old are reused)")
        try:
            idx = eng.build_index(progress=progress, force=True, deadline=deadline)
        except DeadlineExceeded:
            return self._finish({"months": []}, cfg, True)
        progress(f"index: {len(idx['views'])} views indexed, {len(idx.get('errors', {}))} failed "
                 f"({time.monotonic() - t0:.0f}s)")
        first = last_full_month(eng.today())[0]
        ranges = []
        cur = first
        for _ in range(months):
            ranges.append((cur, _month_end(cur)))
            cur = (cur - timedelta(days=1)).replace(day=1)
        ranges.reverse()
        projects = sorted(cols.project_platforms)
        summary = []
        hit = False
        for s, e in ranges:
            if deadline is not None and time.monotonic() >= deadline:
                hit = True
                break
            t = time.monotonic()
            scope = eng.collect(projects, s, e, cfg.metric, deadline=deadline)
            hit = hit or scope.deadline_hit
            counts: dict[str, int] = {}
            for st in scope.status.values():
                counts[st] = counts.get(st, 0) + 1
            fetched = sum(1 for f in scope.freshness if not f["from_cache"])
            cached = len(scope.freshness) - fetched
            views = len({f["view_id"] for f in scope.freshness})
            month = s.strftime("%Y-%m")
            mix: dict[int, int] = {}  # view id -> projects served from it this month (default view first)
            for bv in scope.sources.values():
                for v, ms in bv.items():
                    if month in ms:
                        mix[v] = mix.get(v, 0) + 1
            mix = dict(sorted(mix.items(), key=lambda kv: (kv[0] != cfg.default_view_id, kv[0])))
            flags = [f"unattributed({u['view_id']} GCP {u['share_pct']:.0f}%)" for u in scope.unattributed]
            flags += [f"gap({g['vendor']} v{g['view_id']} {g['from'][5:]}..{g['to'][5:]})" for g in scope.gaps]
            if scope.gap_check_failed:
                flags.append(f"gapcheck-failed({scope.gap_check_failed})")
            summary.append({"month": month, "fetched": fetched, "cached": cached, "views": views,
                            "sources": mix, **({"flags": flags} if flags else {})})
            progress(f"{month}: chunks fetched={fetched} cached={cached} views={views} "
                     f"sources={mix} statuses={dict(sorted(counts.items()))}"
                     f"{' flags=' + ','.join(flags) if flags else ''} ({time.monotonic() - t:.0f}s)")
        progress(f"done in {time.monotonic() - t0:.0f}s")
        return self._finish({"months": summary}, cfg, hit)
