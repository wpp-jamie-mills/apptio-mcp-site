"""Read a file the owner named by path, safely. Errors are fixed text: never the path, the content or an OS message."""
from __future__ import annotations

import os
import stat
from pathlib import Path

NOT_A_FILE = "That path isn't a readable file."


class FilePickError(ValueError):
    """Fixed text only (NOT_A_FILE or `too_big`)."""


def too_big(cap: int) -> str:
    if cap < 1024:
        size = f"{cap} bytes"
    else:
        size = f"{cap // 1024} KB" if cap < 1024 * 1024 else f"{cap // (1024 * 1024)} MB"
    return f"That file is larger than {size}."


def resolve(path_text: str | Path) -> Path:
    """expanduser, require an absolute path, then resolve symlinks (the final component may be a legitimate link)."""
    try:
        text = os.fspath(path_text)
        if not text or "\x00" in text:
            raise FilePickError(NOT_A_FILE)
        path = Path(text).expanduser()
        if not path.is_absolute():
            raise FilePickError(NOT_A_FILE)
        return path.resolve()
    except FilePickError:
        raise
    except (OSError, RuntimeError, ValueError):
        raise FilePickError(NOT_A_FILE) from None


def read_file(path_text: str | Path, cap: int) -> bytes:
    """Return the bytes of a regular file of at most `cap` bytes; refuse anything else.

    The size is checked on the open descriptor before reading, and at most cap + 1 bytes are read."""
    path = resolve(path_text)
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)  # NONBLOCK: opening a FIFO must not hang
    except OSError:
        raise FilePickError(NOT_A_FILE) from None
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode):
            raise FilePickError(NOT_A_FILE)
        if info.st_size > cap:
            raise FilePickError(too_big(cap))
        with os.fdopen(fd, "rb", closefd=False) as fh:
            raw = fh.read(cap + 1)
    except FilePickError:
        raise
    except OSError:
        raise FilePickError(NOT_A_FILE) from None
    finally:
        os.close(fd)
    if len(raw) > cap:
        raise FilePickError(too_big(cap))
    return raw
