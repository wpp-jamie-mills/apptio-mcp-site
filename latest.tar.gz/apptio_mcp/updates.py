"""Update check: warn only, never automatic.

`<site>/latest.version` is fetched in one background thread, at most once a day. The result lives in a shared 0600
state file (`update-check.json` in the cache folder: `checked_at`, `latest`, `noted_at`) so both processes of the
entry see it. Everything else (`sentence`, `available`, `note_for_tool`, `warn`) only reads that file.
"""
from __future__ import annotations

import json
import os
import re
import sys
import threading
import time
import tomllib
from collections.abc import Callable
from pathlib import Path
from typing import Any

from . import __version__, config
from .client import http_get
from .paths import atomic_write, cache_dir

NAME = "apptio-mcp"
SITE_BASE = "https://wpp-jamie-mills.github.io/apptio-mcp-site"
CHECK_EVERY_S = 24 * 3600
NOTE_EVERY_S = 24 * 3600
FETCH_TIMEOUT_S = 5
MAX_VERSION_BYTES = 64
_VERSION = re.compile(r"^([0-9]{1,6})\.([0-9]{1,6})\.([0-9]{1,6})$")


def install_page(site_base: str) -> str:
    """The page that tells the owner how to install or update (no command is built or shown here)."""
    return site_base.rstrip("/") + "/"


def parse_version(text: object) -> tuple[int, int, int] | None:
    """Strict X.Y.Z (no v prefix, no suffix) as a tuple, else None."""
    if not isinstance(text, str):
        return None
    m = _VERSION.fullmatch(text)
    return (int(m.group(1)), int(m.group(2)), int(m.group(3))) if m else None


def _newer(candidate: object, running: str) -> bool:
    a, b = parse_version(candidate), parse_version(running)
    return a is not None and b is not None and a > b


def enabled() -> bool:
    if os.environ.get("APPTIO_MCP_CHECK_UPDATES", "").strip().lower() in ("0", "false", "no", "off"):
        return False
    return bool(config.get("check_updates", True))


def _site_ok(site_base: object) -> bool:
    """A missing or non-https site means the check is off."""
    return isinstance(site_base, str) and site_base.strip().lower().startswith("https://")


def install_dir() -> Path:
    env = os.environ.get("APPTIO_MCP_INSTALL_DIR")
    return Path(env) if env else Path.home() / ".apptio-mcp"


def installed_version() -> str | None:
    """The version in `<install folder>/current/pyproject.toml`, or None."""
    try:
        data = tomllib.loads((install_dir() / "current" / "pyproject.toml").read_text(encoding="utf-8"))
        version = data["project"]["version"]
    except (OSError, ValueError, KeyError, TypeError):
        return None
    return version if parse_version(version) else None


def _default_fetch(url: str) -> str | None:
    """GET `url`: 200 only, no redirects, 5 s, at most 64 bytes read. Returns the text or None."""
    resp = http_get(url, timeout=FETCH_TIMEOUT_S, allow_redirects=False, stream=True,
                        headers={"User-Agent": f"{NAME}/{__version__}"})
    try:
        if resp.status_code != 200:
            return None
        raw = next(iter(resp.iter_content(MAX_VERSION_BYTES + 1)), b"")
    finally:
        resp.close()
    if len(raw) > MAX_VERSION_BYTES:
        return None
    return raw.decode("utf-8", "replace").strip()


class UpdateCheck:
    def __init__(self, site_base: str, current_version: str, state_path: Path,
                 fetch: Callable[[str], Any] | None = None, now: Callable[[], float] | None = None) -> None:
        self.site_base = site_base.rstrip("/")
        self.current_version = current_version
        self.state_path = Path(state_path)
        self._fetch = fetch or _default_fetch
        self._now = now or time.time
        self._lock = threading.Lock()
        self._started = False
        self._warned = False

    # ---- state (a corrupt or odd file is treated as empty)
    def _load(self) -> dict[str, Any]:
        try:
            data = json.loads(self.state_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        if not isinstance(data, dict):
            return {}
        out: dict[str, Any] = {}
        for key in ("checked_at", "noted_at"):
            v = data.get(key)
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                out[key] = float(v)
        if parse_version(data.get("latest")):
            out["latest"] = data["latest"]
        return out

    def _save(self, data: dict[str, Any]) -> None:
        try:
            self.state_path.parent.mkdir(parents=True, exist_ok=True)
            atomic_write(self.state_path, json.dumps(data))
        except OSError:
            pass  # nothing to remember with: checked again next time

    # ---- the check (called from the background thread only)
    def check_now(self, force: bool = False) -> None:
        if not self._on():
            return
        with self._lock:
            state = self._load()
            if not force and self._now() - state.get("checked_at", 0.0) < CHECK_EVERY_S:
                return
            state["checked_at"] = self._now()  # a failure is retried tomorrow, not on every start
            try:
                text = self._fetch(f"{self.site_base}/latest.version")
                if isinstance(text, bytes):
                    text = text[: MAX_VERSION_BYTES + 1].decode("utf-8", "replace")
                text = text.strip() if isinstance(text, str) else None
                if text and len(text.encode("utf-8")) <= MAX_VERSION_BYTES and parse_version(text):
                    state["latest"] = text
            except Exception:  # noqa: BLE001, S110 - OSError, requests errors, anything: a check never breaks the server
                pass
            self._save(state)

    def start_background(self) -> threading.Thread | None:
        """Warn from what was last seen, then check in one daemon thread (once per process)."""
        if not self._on():
            return None
        with self._lock:
            if self._started:
                return None
            self._started = True
        self.warn()

        def run() -> None:
            self.check_now()
            self.warn()

        thread = threading.Thread(target=run, daemon=True, name="apptio-mcp-update-check")
        thread.start()
        return thread

    # ---- readers (state file only, never the network)
    def available(self) -> str | None:
        if not self._on():
            return None
        latest = self._load().get("latest")
        return latest if _newer(latest, self.current_version) else None

    def _on(self) -> bool:
        return enabled() and _site_ok(self.site_base)

    def sentence(self) -> str | None:
        if not self._on():
            return None
        installed = installed_version()
        if installed and _newer(installed, self.current_version):
            return (f"{NAME} {installed} is installed but not running yet. "
                    "Quit and reopen Claude Desktop (or run /mcp in Claude Code).")
        latest = self.available()
        if latest:
            return (f"{NAME} {latest} is available (you have {self.current_version}). "
                    "Tell the owner to re-run the installer they used (the install page is "
                    f"{install_page(self.site_base)}), then quit and reopen Claude Desktop. "
                    "Don't run it yourself.")
        return None

    def note_for_tool(self) -> str | None:
        """The sentence for a tool result, at most once a day across processes (shared `noted_at`)."""
        text = self.sentence()
        if not text:
            return None
        with self._lock:
            state = self._load()
            if self._now() - state.get("noted_at", 0.0) < NOTE_EVERY_S:
                return None
            state["noted_at"] = self._now()
            self._save(state)
        return text

    def warn(self) -> None:
        """The sentence on stderr, once per process."""
        text = self.sentence()
        with self._lock:
            if not text or self._warned:
                return
            self._warned = True
        try:
            print(f"{NAME}[{os.getpid()}]: {text}", file=sys.stderr, flush=True)
        except Exception:  # noqa: BLE001, S110 - logging never breaks a call
            pass


_instance: UpdateCheck | None = None
_instance_lock = threading.Lock()


def get_update_check() -> UpdateCheck:
    """The process-wide instance."""
    global _instance
    with _instance_lock:
        if _instance is None:
            _instance = UpdateCheck(SITE_BASE, __version__, cache_dir() / "update-check.json")
        return _instance


def reset_update_check() -> None:
    """Forget the process-wide instance (tests)."""
    global _instance
    with _instance_lock:
        _instance = None
