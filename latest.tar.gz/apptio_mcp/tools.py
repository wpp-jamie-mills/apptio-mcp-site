"""The tool catalogue: names and descriptions.

Descriptions never name a mapping file's real name, a team, or a view: they say "your mapping file" and "your
default view". Behaviour lives in `mcp_server.py`.
"""
from __future__ import annotations

from mcp_types import ToolAnnotations

# readOnlyHint true, destructiveHint false, idempotentHint true, openWorldHint false.
READ_ONLY = ToolAnnotations(readOnlyHint=True, destructiveHint=False, idempotentHint=True, openWorldHint=False)

SETUP_STATUS = "cloudability_setup_status"

_VIEW_ARG = "view_id: Cloudability view ID. Defaults to your default view."
_SPEND_NEEDS = ("Needs your mapping file (import it once in the settings card: ask Claude to open Cloudability "
                "settings; cloudability_setup_status shows whether it is there).")
_DATES = "start_date: YYYY-MM-DD, inclusive, UTC. Default: first day of the last full month."

DESCRIPTIONS: dict[str, str] = {
    "cloudability_list_views": (
        "List all Cloudability cost views. Returns view IDs, titles, owners, filter counts and which view is your "
        "default."
    ),
    "cloudability_get_view": (
        "Get detailed information about one Cloudability view, including all its filters.\n\n"
        "Args:\n    " + _VIEW_ARG
    ),
    "cloudability_list_business_mappings": (
        "List all Cloudability business dimension and metric mappings. Returns mapping names, kinds "
        "(BUSINESS_DIMENSION or BUSINESS_METRIC), default values and rule counts."
    ),
    "cloudability_get_business_mapping": (
        "Get one business mapping by name, including all match/value expression rules. An exact name (any case) "
        "wins; otherwise a partial match is used. When several mappings match partially, the candidate names are "
        "returned instead.\n\nArgs:\n    name: Business mapping name or part of it."
    ),
    "cloudability_list_clusters": (
        "List Kubernetes container clusters monitored by Cloudability. Not available in this version: Cloudability "
        "retired the old cluster endpoint, so this explains why instead of returning data."
    ),
    "cloudability_get_cluster": (
        "Get one Kubernetes cluster by ID. Not available in this version: it explains why instead of returning data."
        "\n\nArgs:\n    cluster_id: A cluster ID."
    ),
    "cloudability_search_clusters": (
        "Search clusters by name. Not available in this version: it explains why instead of returning data."
        "\n\nArgs:\n    query: Part of the cluster name."
    ),
    "cloudability_list_budgets": (
        "List Cloudability budgets with optional filtering.\n\n"
        "Args:\n"
        "    limit: Maximum budgets to return (default 50).\n"
        "    offset: Row offset for pagination (default 0).\n"
        "    filter: Filter syntax field==value, field!=value, field>value, field<value, field=@value (contains). "
        "Separate several with commas, for example status==active,totalBudget>10000."
    ),
    "cloudability_get_budget": (
        "Get detailed information about one budget by ID.\n\nArgs:\n    budget_id: The budget ID from "
        "cloudability_list_budgets."
    ),
    "cloudability_list_anomalies": (
        "List cost anomalies detected by Cloudability for a date range: unusual jumps in spend that deviate "
        "significantly from historical norms for a service, account or usage family. Both dates are required; "
        "without them the API returns an empty list.\n\n"
        "Args:\n"
        "    start_date: Start of the range, YYYY-MM-DD.\n"
        "    end_date: End of the range, YYYY-MM-DD.\n"
        "    " + _VIEW_ARG
    ),
    "cloudability_list_measures": (
        "List the dimensions and metrics available to cloudability_run_cost_report. Call this to discover valid "
        "names before running a report. Returns each measure's name, label, description, data type and group.\n\n"
        "Args:\n    type: Optional filter, 'dimension' or 'metric'. Empty returns both."
    ),
    "cloudability_run_cost_report": (
        "Run a cost report against the Cloudability reporting engine. Returns spend broken down by the chosen "
        "dimension, with pagination metadata and aggregate totals. Use cloudability_list_measures to discover "
        "names. Common dimensions: vendor, region, account_name, vendor_account_name, usage_family, "
        "enhanced_service_name, category1, date, month. Common metrics: unblended_cost, adjusted_cost, "
        "total_amortized_cost, public_on_demand_cost.\n\n"
        "Args:\n"
        "    start_date: Report start, YYYY-MM-DD.\n"
        "    end_date: Report end, YYYY-MM-DD.\n"
        "    dimensions: Dimension name(s). Default vendor.\n"
        "    metrics: Cost metric(s). Default unblended_cost.\n"
        "    " + _VIEW_ARG + "\n"
        "    limit: Maximum rows (default 100).\n"
        "    offset: Row offset for pagination (default 0).\n"
        "    filter: Optional filter expression, for example vendor==Amazon."
    ),
    "cloudability_get_forecast": (
        "Get a cost forecast for a Cloudability view: the month-to-date estimate (currentEstimate), the "
        "statistical forecast total (forecastTotal), actual spend to date (actualTotal), monthly actuals (actual) "
        "and per-service detail (actualDetail).\n\n"
        "Args:\n"
        "    " + _VIEW_ARG + "\n"
        "    basis: cash, adjusted, amortized, adjustedamortized or list. Default amortized.\n"
        "    months_forward: Months to project forward (minimum 1). Default 1.\n"
        "    months_back: Historical months used as model input (minimum 3). Default 3."
    ),
    "cloudability_get_platform_spend": (
        "Categorised cloud spend for a platform from your mapping file, rolled up platform, environment "
        "(production, non-production, shared, unclassified), project, each with a category split, a "
        "transaction-type split and optional monthly totals. " + _SPEND_NEEDS + "\n\n"
        "Answers questions such as: what did a platform cost last month by category; production against "
        "non-production for a quarter; compare all platforms for a month (platform='all'). Costs are amortised net "
        "cost from your default view, falling back per project to another accessible view.\n\n"
        "Dates are UTC. An end date on or after today is clamped to today and flagged partial (month to date). "
        "Data within about 3 days of a period end is flagged provisional. Ranges are capped at 24 months. Each "
        "project has a status: ok, no_spend_in_period, not_visible, unknown or unresolved; the last three are "
        "excluded from totals, never shown as zero.\n\n"
        "Args:\n"
        "    platform: Platform name (case-insensitive: exact, short code or unique substring), or 'all'.\n"
        "    " + _DATES + "\n"
        "    end_date: YYYY-MM-DD, inclusive, UTC. Default: last day of the last full month.\n"
        "    by_environment: Group projects by environment (default true).\n"
        "    granularity: 'total' or 'month'.\n"
        "    level: 'category', 'type' or 'service'. Default from your spend rules.\n"
        "    max_projects: Projects listed per node, largest first; the rest are summed (default 10).\n"
        "    metric: Override the cost metric (default total_amortized_cost).\n"
        "    detail: true adds each project's full category and transaction-type split."
    ),
    "cloudability_get_project_spend": (
        "Categorised cloud spend for one or more projects (cloud project or account names). " + _SPEND_NEEDS + " "
        "Projects need not be in your mapping file as long as they are visible in an accessible view. Every "
        "requested project gets a status (ok, no_spend_in_period, not_visible, unknown, unresolved); the last "
        "three have total null and are excluded from the aggregate.\n\n"
        "Args:\n"
        "    projects: Comma-separated project names (case-insensitive).\n"
        "    " + _DATES + "\n"
        "    end_date: YYYY-MM-DD, inclusive, UTC. Default: end of the same month. Clamped to today and flagged "
        "partial when it is on or after today.\n"
        "    granularity: 'total' or 'month'.\n"
        "    level: 'category', 'type' or 'service'.\n"
        "    metric: Override the cost metric (default total_amortized_cost).\n"
        "    detail: true (default) gives the full splits; false gives total, status and top categories."
    ),
    "cloudability_explain_category": (
        "Break one spend category down for a platform or projects, by service, transaction type and project. "
        + _SPEND_NEEDS + "\n\n"
        "Args:\n"
        "    target: A platform name, 'all' (every project in your mapping file), a project name, or "
        "comma-separated project names.\n"
        "    category: Category name at `level` (case-insensitive).\n"
        "    " + _DATES + "\n"
        "    end_date: YYYY-MM-DD, inclusive, UTC. Default: end of the same month.\n"
        "    top_n: Rows per breakdown (default 25; the rest are summed as '(other)').\n"
        "    metric: Override the cost metric (default total_amortized_cost).\n"
        "    level: 'category', 'type' or 'service' (what `category` names)."
    ),
    "cloudability_list_platforms": (
        "List the platforms in your mapping file with project counts and environment mix, and (when requested or "
        "already cached) how many projects are visible in your default view, another view or none. " + _SPEND_NEEDS
        + " check_visibility=true may take a few minutes on a cold cache because it queries every accessible "
        "view.\n\nArgs:\n    check_visibility: Build the view index now if it is not cached."
    ),
    "cloudability_find_projects": (
        "Find projects in your mapping file by name substring (case-insensitive), with their platform and "
        "environment. " + _SPEND_NEEDS + "\n\n"
        "Args:\n    search: Substring of the project name.\n    limit: Maximum matches (default 50)."
    ),
    "cloudability_summary": (
        "A high-level summary of the Cloudability data: view count, business mapping count, "
        "budget count and recent anomalies for your default view. Use it as a starting point."
    ),
}

DATA_TOOLS: tuple[str, ...] = tuple(DESCRIPTIONS)

SPEND_TOOLS: frozenset[str] = frozenset({
    "cloudability_get_platform_spend", "cloudability_get_project_spend", "cloudability_explain_category",
    "cloudability_list_platforms", "cloudability_find_projects",
})

SETUP_STATUS_DESCRIPTION = (
    "Show whether Cloudability setup is complete: what is missing, what still needs the owner's review, where each "
    "setting comes from, whether a key is stored (never the key), the last login result, whether the mapping file "
    "is imported, the running version and the next step. Works before setup is finished."
)
