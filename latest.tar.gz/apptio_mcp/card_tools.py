"""The setup card's two tools: `cloudability_settings` (model-visible) and `save_settings` (app-only).

Order everywhere: claim the token (an atomic rename, so one request wins), validate and act, then burn it and issue a
fresh one. A refused save puts the token back; a key check always burns it and returns a fresh token and a fresh
sealing key, so the card stays usable. An expired or used token saves nothing. No key, opentoken or sealing private
key is ever put in a result, a log line, an exception or a file other than the token record. Log lines carry names
and lengths only.

`import_file` and `clear_file` (the mapping file and spend rules) follow the same order, need no key or finished
setup and do not count as the review. A success burns the token and issues a fresh one (no sealing key); a refusal
puts it back. A path or file content is never logged or echoed: only the kind, the outcome and counts.

Residual risk, accepted: `save_settings` is listed to every client (it is hidden from the model by metadata only),
and the token is its only guard. The token is 128 random bits, shown only to the card, so a party that merely reads
the conversation text cannot use it. A party that can read structuredContent of the open result could; that is why
the environment ID and the token are not placed where no card is shown. No MAC is added.

`setup` and `redact` are looked up at call time (as in mcp_server.py), so tests can substitute them.
"""
from __future__ import annotations

import hashlib
import importlib
import os
import sys
import time
from pathlib import Path

from mcp.server.apps import Apps, client_supports_apps
from mcp.server.mcpserver import Context
from mcp_types import CallToolResult, TextContent, ToolAnnotations

from . import config, keychain, mapping, seal, spend_rules, tokens
from .paths import data_dir

CARD_FILE = Path(__file__).with_name("settings_card.html")
_STUB_HTML = "<!doctype html><title>Cloudability settings</title><p>Setup card unavailable.</p>"
MIME = "text/html;profile=mcp-app"

OPEN_TEXT = ("The Cloudability setup card is open. Ask the owner to finish it in the card, then end your turn. "
             "When they send their next message, call the original tool again with the same arguments.")
BANNER = "Check these settings. Keep the defaults or change any that don't fit you."
EXPIRED = tokens.EXPIRED
VIEW_LIST_S = 10.0
CHECK_S = 40.0
LOGIN = "~/.apptio-mcp/current/bin/apptio-mcp login"
_ACTIONS = ("check_key", "save", "replace_key", "import_file", "clear_file")
_FILE_KINDS = ("mapping", "spend_rules")

SAVE_ANNOTATIONS = ToolAnnotations(readOnlyHint=False, destructiveHint=False, idempotentHint=False,
                                   openWorldHint=False)
SETTINGS_ANNOTATIONS = ToolAnnotations(readOnlyHint=True, destructiveHint=False, idempotentHint=True,
                                       openWorldHint=False)
SETTINGS_DESCRIPTION = (
    "Open the Cloudability setup card, where the owner enters their Apptio key, checks the settings and chooses a "
    "view. Call it when another tool says setup isn't finished. Then ask the owner to finish the card and end your "
    "turn."
)
SAVE_DESCRIPTION = "Used by the setup card only. Not for the model."


def _setup():
    return importlib.import_module("apptio_mcp.setup")


def _redact():
    return importlib.import_module("apptio_mcp.redact")


def _log(message: str) -> None:
    try:
        print(f"apptio-mcp[{os.getpid()}]: {message}", file=sys.stderr, flush=True)
    except Exception:  # noqa: BLE001, S110
        pass


# ── The card resource ────────────────────────────────────────────────────

def card_html() -> str:
    try:
        return CARD_FILE.read_text(encoding="utf-8")
    except OSError:
        return _STUB_HTML


def card_uri(html: str | None = None) -> str:
    digest = hashlib.sha256((html if html is not None else card_html()).encode("utf-8")).hexdigest()[:12]
    return f"ui://apptio-mcp/settings-{digest}.html"


# ── State ────────────────────────────────────────────────────────────────

def _tilde(path: Path) -> str:
    text = str(path)
    home = str(Path.home())
    return "~" + text[len(home):] if text == home or text.startswith(home + os.sep) else text


def _field(value, source: str, default, locked: bool, **extra) -> dict:
    return {"value": value, "source": source, "default": default, "locked": locked, **extra}


def _profile_default(name: str):
    try:
        raw = _setup()._profile_value(name)
        return config.validate(name, raw) if raw else None
    except (config.SettingError, AttributeError):
        return None


def _fields(views: tuple | None, mask_env: bool = False) -> dict:
    setup = _setup()
    out: dict = {}
    for name in ("environment_id", "frontdoor_url", "region", "view_id", "view_name"):
        value, source = config.lookup(name)
        default = config.CODE_DEFAULTS.get(name)
        if name == "view_id":
            default = _profile_default("view_id")
            if (views is not None and value is not None and source not in ("settings", "environment")
                    and str(value) not in {str(v["id"]) for v in views}):
                value, source = None, "unset"  # an unlisted view from a profile or default is not kept
            if value is None and views is not None:
                value, source = setup.preselect_view(views)
        if name == "view_name":
            value = setup.sanitize_title(value) if value else None
        if name == "environment_id" and mask_env and value:
            value = setup.mask_env_id(str(value))
        extra = {}
        if name == "frontdoor_url":
            extra["choices"] = list(config.FRONTDOOR_HOSTS)
        elif name == "region":
            extra["choices"] = list(config.REGIONS)
        out[name] = _field(value, source, default, source == "environment", **extra)
    value, source = config.lookup("check_updates")
    out["check_updates"] = _field(True if value is None else bool(value), "default" if value is None else source,
                                  True, source == "environment")
    return out


def _view_list(views) -> list | None:
    if views is None:
        return None
    setup = _setup()
    return [{"id": str(v["id"]), "title": setup.sanitize_title(v.get("title")) or "(untitled)"} for v in views]


def _mapping_info() -> dict:
    shown = mapping.show()
    if shown.get("imported"):
        return {"imported": True, "rows": shown.get("rows"), "platforms": shown.get("platforms"),
                "command": mapping.IMPORT_COMMAND}
    return {"imported": False, "rows": None, "platforms": None, "command": mapping.IMPORT_COMMAND,
            "error": shown.get("error")}


def _spend_rules_info() -> dict:
    shown = spend_rules.show()
    return {"present": bool(shown.get("present")), "ignored_keys": list(shown.get("ignored_keys") or []),
            "error": shown.get("error"), "command": spend_rules.IMPORT_COMMAND}


def _info() -> dict:
    emails = "shown" if config.get("show_owner_emails", False) else "hidden"
    return {"data_dir": _tilde(data_dir()), "emails": emails}


def _seal_key(spki_b64: str | None) -> dict | None:
    return {"alg": seal.ALG, "spki_b64": spki_b64} if spki_b64 else None


def _base(*, views: tuple | None, views_error: str | None = None, mask_env: bool = False) -> dict:
    """The fields shared by the open result and every save_settings result."""
    setup = _setup()
    st = setup.status()
    reviewed = setup.is_reviewed()
    return {
        "key_stored": bool(st.key_stored), "needs_key": not st.key_stored, "reviewed": reviewed,
        "banner": None if reviewed else BANNER,
        "missing": list(st.missing), "to_review": list(st.to_review),
        "fields": _fields(views, mask_env), "views": _view_list(views), "views_error": views_error,
        "mapping": _mapping_info(), "spend_rules": _spend_rules_info(),
    }


def _issue(*, with_seal_key: bool) -> tuple[str, dict | None]:
    store = tokens.OneTimeTokens()
    if with_seal_key:
        pem, spki = seal.new_seal_key()
        return store.issue(seal_key_pem=pem), _seal_key(spki)
    return store.issue(), None


def _clean(obj: dict) -> dict:
    return _redact().redact(obj)


# ── cloudability_settings ────────────────────────────────────────────────

def _text_fallback(state: dict) -> str:
    parts = ["Cloudability setup can't be done in a card here."]
    if state["missing"]:
        parts.append("Missing: " + ", ".join(state["missing"]) + ".")
    if state["to_review"]:
        parts.append("Defaults to review: " + ", ".join(state["to_review"]) + ".")
    parts.append(f"Settings file: {state['info']['data_dir']}/settings.toml. "
                 "Environment names: APPTIO_ENVIRONMENT_ID, APPTIO_FRONTDOOR_URL, CLOUDABILITY_REGION, "
                 "CLOUDABILITY_VIEW_ID.")
    parts.append(f"Tell the owner to run `{LOGIN}` in Terminal (it asks for the key and checks the settings), "
                 "then call the original tool again with the same arguments.")
    return " ".join(parts)


def open_card(cards: bool) -> CallToolResult:
    setup = _setup()
    st = setup.status()
    views, views_error = None, None
    if cards and st.key_stored:
        views, views_error = setup.stored_key_views(VIEW_LIST_S)
        if views_error:
            views_error = f"Couldn't list views: {views_error}"
    token, seal_key = (None, None)
    if cards:
        token, seal_key = _issue(with_seal_key=not st.key_stored)
    state = {"state": "open", "token": token, "seal_key": seal_key,
             **_base(views=views, views_error=views_error, mask_env=not cards),  # no card: no full environment ID
             "info": _info(), "fallback_command": LOGIN}
    state = _clean(state)
    _log(f"settings card cards={'yes' if cards else 'no'} key_stored={'yes' if st.key_stored else 'no'} "
         f"token={'yes' if token else 'no'} seal_key={'yes' if seal_key else 'no'}")
    meta = {"apptio": {"token": token, "seal_key": seal_key}} if token else None
    return CallToolResult(content=[TextContent(type="text", text=OPEN_TEXT if cards else _text_fallback(state))],
                          structured_content=state, meta=meta)


# ── save_settings ────────────────────────────────────────────────────────

def _respond(*, ok: bool, code: str, message: str, token: str | None, seal_key: dict | None, views=None,
             views_error: str | None = None, done: bool = False) -> CallToolResult:
    body = {"ok": ok, "code": code, "message": message, "token": token, "seal_key": seal_key,
            **_base(views=views, views_error=views_error), "done": done}
    body = _clean(body)
    meta = {"apptio": {"token": token, "seal_key": seal_key}} if token else None
    return CallToolResult(content=[TextContent(type="text", text=message)], structured_content=body, meta=meta,
                          is_error=False)


def _expired() -> CallToolResult:
    return _respond(ok=False, code="expired", message=EXPIRED, token=None, seal_key=None)


def _validate(given: dict) -> dict:
    """Clean the given values; raise config.SettingError (value-free text) on the first bad one."""
    clean: dict = {}
    for name, value in given.items():
        if value is None:
            continue
        if name == "check_updates" and not isinstance(value, bool):
            raise config.SettingError("check_updates: expected true or false")
        clean[name] = config.validate(name, value)
    return clean


def _refused(message: str, code: str = "invalid_setting", *, token: str) -> CallToolResult:
    """A refused save: nothing saved, the token (and the claim on it) is put back by the caller."""
    return _respond(ok=False, code=code, message=f"{message} Nothing was saved.", token=token, seal_key=None)


def _burned(message: str, code: str) -> CallToolResult:
    """A refused or failed key step: the old token and its sealing key are gone; the result carries a FRESH token
    and a FRESH sealing key, so the card can try again."""
    new_token, new_seal = _issue(with_seal_key=True)
    return _respond(ok=False, code=code, message=message, token=new_token, seal_key=new_seal)


def _file_failure(exc: Exception, token: str) -> CallToolResult:
    if isinstance(exc, (mapping.MappingError, spend_rules.SpendRulesError)):
        return _refused(getattr(exc, "problem", None) or str(exc), "invalid_file", token=token)
    return _refused("The file could not be written.", "write_failed", token=token)


def _file_action(claim: tokens.Claim, token: str, action: str, kind: str, file_path: str,
                 file_content: str) -> CallToolResult:
    """import_file / clear_file: needs no key and does not count as the review. Never logs a path or content."""
    if kind not in _FILE_KINDS:
        return _refused("kind: not recognised.", "invalid_kind", token=token)
    module = mapping if kind == "mapping" else spend_rules
    label = "mapping file" if kind == "mapping" else "spend rules"
    if action == "clear_file":
        try:
            removed = module.clear()["removed"]
        except OSError:
            _log(f"clear_file kind={kind} ok=no")
            return _refused(f"The {label} could not be removed.", "write_failed", token=token)
        message = f"Removed the {label}." if removed else f"There was no {label} to remove."
        _log(f"clear_file kind={kind} ok=yes removed={'yes' if removed else 'no'}")
    else:
        if bool(file_path) == bool(file_content):
            return _refused("Choose a file, or type a path (not both).", "invalid_file", token=token)
        try:
            done = module.import_file(file_path) if file_path else module.import_content(file_content)
        except (mapping.MappingError, spend_rules.SpendRulesError, OSError) as exc:
            _log(f"import_file kind={kind} ok=no source={'path' if file_path else 'content'}")
            return _file_failure(exc, token)
        ignored = done.get("ignored_keys") or []
        if kind == "mapping":
            message = f"Imported {done['rows']} rows ({done['platforms']} platforms)."
        else:
            message = "Imported the spend rules." + (f" Not used: {', '.join(ignored)}." if ignored else "")
        _log(f"import_file kind={kind} ok=yes source={'path' if file_path else 'content'} "
             f"rows={done.get('rows', '-')} ignored={len(ignored)}")
    claim.burn()
    new_token, _ = _issue(with_seal_key=False)
    return _respond(ok=True, code="ok", message=message, token=new_token, seal_key=None)


def _check_key(claim: tokens.Claim, given: dict, sealed_key: str | None) -> CallToolResult:
    setup = _setup()
    claim.burn()  # always: whatever happens next, this token and its private key are used up
    record = claim.record
    try:
        values = _validate(given)
    except config.SettingError as exc:
        return _burned(f"{exc}. Nothing was saved.", "invalid_setting")
    env_id = values.get("environment_id") or config.get("environment_id")
    if not env_id:
        return _burned("environment_id: not a valid value. Nothing was saved.", "invalid_setting")
    frontdoor = values.get("frontdoor_url") or config.get("frontdoor_url", config.DEFAULT_FRONTDOOR)
    region = values.get("region") or config.get("region", config.DEFAULT_REGION)
    pem = record.get("seal_key_pem")
    try:
        public, secret = seal.open_sealed(sealed_key or "", pem or "")
    except seal.SealError:
        return _expired()
    finally:
        pem = None
        record.pop("seal_key_pem", None)
    try:
        out = setup.check_and_store_key(public, secret, env_id, frontdoor, region, deadline_s=CHECK_S)
    except Exception:  # noqa: BLE001 - fixed text only: the exception could carry anything
        out = setup.fail_result("internal", "Something went wrong while checking the key.")
    finally:
        public = secret = ""
    _log(f"check_key ok={'yes' if out.get('ok') else 'no'} code={out.get('code')}")
    if not out.get("ok"):
        return _burned(out.get("message", "The key was not saved."), str(out.get("code") or "failed"))
    new_token, _ = _issue(with_seal_key=False)
    return _respond(ok=True, code="ok", message=out["message"], token=new_token, seal_key=None,
                    views=tuple(out.get("views") or ()))


def _replace_key(claim: tokens.Claim) -> CallToolResult:
    claim.burn()
    new_token, new_seal = _issue(with_seal_key=True)
    return _respond(ok=True, code="ok", message="Enter the new key pair.", token=new_token, seal_key=new_seal)


def _save(claim: tokens.Claim, token: str, given: dict, reviewed: bool) -> CallToolResult:
    setup = _setup()
    try:
        values = _validate(given)
    except config.SettingError as exc:
        return _refused(str(exc), token=token)
    st = setup.status()
    views = None
    views_error = None
    changed = {n: values[n] for n in ("environment_id", "frontdoor_url", "region")
               if n in values and values[n] != config.get(n)}
    if changed and st.key_stored:
        env_id = values.get("environment_id") or config.get("environment_id")
        if not env_id:
            return _refused("environment_id: not a valid value.", token=token)
        try:
            res = setup.verify_stored_key(env_id, values.get("frontdoor_url") or config.get("frontdoor_url"),
                                          values.get("region") or config.get("region"), CHECK_S)
        except keychain.KeychainError as exc:
            return _refused(str(exc), "keychain", token=token)
        except Exception:  # noqa: BLE001
            return _refused("Something went wrong while checking the key.", "internal", token=token)
        if not res.ok:
            return _refused(setup.verify_message(res, env_id), str(res.code or res.status), token=token)
        values["frontdoor_url"], values["region"] = res.frontdoor_host or values.get("frontdoor_url"), res.region
        values = {k: v for k, v in values.items() if v is not None}
        views = tuple(res.views)
    if "view_id" in values and st.key_stored:
        if views is None:
            views, error = setup.stored_key_views(VIEW_LIST_S)
            views_error = f"Couldn't list views: {error}" if error else None
        if views is not None:
            titles = {v["id"]: v["title"] for v in views}
            if values["view_id"] in titles:
                values["view_name"] = setup.sanitize_title(titles[values["view_id"]]) or None
            elif not (values["view_id"] == config.get("view_id")
                      and config.lookup("view_id")[1] in ("settings", "environment")):
                # "Keep the current view" is allowed only for a view the owner chose (saved or from the
                # environment); a view from a profile or default that this key cannot see is never kept.
                return _refused("view_id: that view isn't visible to this key.", "view_not_visible", token=token)
    try:
        saved = setup.save_reviewed_settings(values, reviewed=reviewed)
    except config.SettingError as exc:
        return _refused(str(exc), token=token)
    except OSError:
        return _refused("The settings could not be written.", "write_failed", token=token)
    claim.burn()
    done = bool(setup.status().complete and (reviewed or setup.is_reviewed()))
    new_token, _ = _issue(with_seal_key=False)
    names = ", ".join(n for n in saved if n != "view_name") or "no changes"
    message = f"Saved: {names}." if saved else "Saved."
    _log(f"save names={','.join(saved) or '-'} reviewed={'yes' if reviewed else 'no'} done={'yes' if done else 'no'}")
    return _respond(ok=True, code="ok", message=message, token=new_token, seal_key=None,
                    views=None if done else views, views_error=None if done else views_error, done=done)


def save_settings_impl(token: str, action: str, sealed_key: str | None = None, environment_id: str | None = None,
                       frontdoor_url: str | None = None, region: str | None = None, view_id: str | None = None,
                       check_updates: bool | None = None, reviewed: bool = False, kind: str = "",
                       file_path: str = "", file_content: str = "") -> CallToolResult:
    t0 = time.monotonic()
    claim = None
    try:
        store = tokens.OneTimeTokens()  # prunes expired records
        try:
            claim = store.claim(token)
        except tokens.TokenError:
            return _expired()
        if action not in _ACTIONS:
            return _refused("action: not recognised.", "invalid_action", token=token)
        given = {"environment_id": environment_id, "frontdoor_url": frontdoor_url, "region": region,
                 "view_id": view_id, "check_updates": check_updates}
        if action in ("import_file", "clear_file"):
            return _file_action(claim, token, action, kind, file_path, file_content)
        if action == "replace_key":
            return _replace_key(claim)
        if action == "check_key":
            return _check_key(claim, given, sealed_key)
        return _save(claim, token, given, bool(reviewed))
    except Exception:  # noqa: BLE001 - never put exception text (it could carry anything) into a result
        _log(f"save_settings action={action} failed unexpectedly")
        return _respond(ok=False, code="internal", message="Something went wrong. Nothing was saved.", token=None,
                        seal_key=None)
    finally:
        if claim is not None:
            claim.release()  # a no-op once burned; otherwise the token goes back for the next try
        _log(f"save_settings action={action} ms={int((time.monotonic() - t0) * 1000)}")


# ── Registration ─────────────────────────────────────────────────────────

def build_apps() -> Apps:
    """The `Apps` extension with the card resource and its two tools. Call BEFORE building `MCPServer`."""
    apps = Apps()
    html = card_html()
    uri = card_uri(html)
    apps.add_html_resource(uri, html, name="Cloudability settings", title="Cloudability settings",
                           description="Setup card for the Apptio key and Cloudability settings")

    @apps.tool(resource_uri=uri, name="cloudability_settings", description=SETTINGS_DESCRIPTION,
               annotations=SETTINGS_ANNOTATIONS, structured_output=False)
    def cloudability_settings(ctx: Context) -> CallToolResult:
        try:
            cards = bool(client_supports_apps(ctx))
        except Exception:  # noqa: BLE001
            cards = False
        return open_card(cards)

    @apps.tool(resource_uri=uri, visibility=["app"], name="save_settings", description=SAVE_DESCRIPTION,
               annotations=SAVE_ANNOTATIONS, structured_output=False)
    # Every string parameter is annotated exactly `str`: the SDK runs json.loads over any string argument whose
    # annotation is anything else (`str | None`), and the card's sealed envelope would arrive as a dict and be
    # refused. "" means "not given". The bool parameters are real JSON booleans, which the SDK leaves alone.
    def save_settings(token: str, action: str, sealed_key: str = "", environment_id: str = "",
                      frontdoor_url: str = "", region: str = "", view_id: str = "",
                      check_updates: bool | None = None, reviewed: bool = False, kind: str = "",
                      file_path: str = "", file_content: str = "") -> CallToolResult:
        return save_settings_impl(token, action, sealed_key, environment_id or None, frontdoor_url or None,
                                  region or None, view_id or None, check_updates, reviewed, kind, file_path,
                                  file_content)

    _ = (cloudability_settings, save_settings)
    return apps


