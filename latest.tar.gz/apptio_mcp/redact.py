"""Owner-email redaction for tool results and card data.

While hiding is on (the default), every `ownerEmail` key is removed and every email-shaped string value is
replaced with a fixed marker. Turning hiding off is CLI only (`config set show_owner_emails true`).

Matching is Unicode-aware (non-ASCII local parts and domains), and common disguises of the at sign are undone first:
percent-encoded (`%40`), fullwidth (`＠`, via NFKC) and HTML entities (`&#64;`, `&#x40;`, `&commat;`). The whole local
part and domain are replaced, never a fragment."""
from __future__ import annotations

import re
import unicodedata

from . import config

HIDDEN = "[email hidden]"
_STOP = r"""\s@<>()\[\]",;:"""
_EMAIL = re.compile(rf"[^{_STOP}]+@(?:[^{_STOP}.]+\.)+[^{_STOP}.]+")
_AT = re.compile(r"%40|&#0*64;|&#x0*40;|&commat;", re.IGNORECASE)


def _scrub(text: str) -> str:
    if "@" not in text and "%" not in text and "&" not in text and text.isascii():
        return text
    plain = _AT.sub("@", unicodedata.normalize("NFKC", text))
    return _EMAIL.sub(HIDDEN, plain) if _EMAIL.search(plain) else text


def _walk(obj):
    if isinstance(obj, dict):
        return {
            (_scrub(k) if isinstance(k, str) else k): _walk(v)
            for k, v in obj.items()
            if not (isinstance(k, str) and k.lower() == "owneremail")
        }
    if isinstance(obj, list):
        return [_walk(v) for v in obj]
    if isinstance(obj, tuple):
        return tuple(_walk(v) for v in obj)
    if isinstance(obj, str):
        return _scrub(obj)
    return obj


def redact(obj, *, show_emails: bool | None = None):
    """Return a redacted copy of `obj` (dicts, lists, tuples, strings); other values pass through."""
    if show_emails is None:
        show_emails = bool(config.get("show_owner_emails", False))
    return obj if show_emails else _walk(obj)
