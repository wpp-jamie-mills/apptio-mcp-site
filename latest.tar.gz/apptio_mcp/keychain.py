"""macOS login Keychain backend for the Apptio key pair.

One item: service `apptio-mcp`, account `key-pair`, holding base64url of the JSON {public_key, secret_key}.
`/usr/bin/security` is the only backend. Writes go over stdin to `security -i`, so the secret is never on argv.
The text `security` prints is never copied into an exception or a log: every message below is fixed.
"""
from __future__ import annotations

import base64
import binascii
import json
import os
import re
import secrets
import subprocess
import time

SERVICE = "apptio-mcp"
ACCOUNT = "key-pair"
SECURITY_BIN = "/usr/bin/security"
DEFAULT_TIMEOUT_S = 10.0
MAX_KEY_CHARS = 512  # per key; `security -i` splits any line over 4095 characters into two commands
MAX_LINE_CHARS = 4000
RESTORE_GRACE_S = 1.0  # a restore may run this long past the deadline so the key and settings never disagree

_TEST_SERVICE = re.compile(r"^apptio-mcp-test-[a-z0-9-]{1,40}$")
_B64URL = re.compile(r"^[A-Za-z0-9_-]+$")
_NOT_FOUND = 44  # `security` exit status for errSecItemNotFound

LOGIN_HINT = "~/.apptio-mcp/current/bin/apptio-mcp login"
UNAVAILABLE_MESSAGE = (
    "macOS Keychain wouldn't give apptio-mcp the Apptio key (locked or access denied). "
    f"Unlock your login keychain and try again, or run `{LOGIN_HINT}` in Terminal."
)
NO_KEY_MESSAGE = f"No Apptio key is stored in the macOS Keychain for apptio-mcp. Run `{LOGIN_HINT}` in Terminal."
UNREADABLE_MESSAGE = (
    f"The Apptio key item in the macOS Keychain is unreadable. Run `{LOGIN_HINT}` in Terminal to replace it."
)
BAD_SERVICE_MESSAGE = "APPTIO_MCP_SERVICE is not an allowed test service name"
KEY_TOO_LONG_MESSAGE = (f"A key is longer than {MAX_KEY_CHARS} characters or has characters that are not plain text; "
                        "that is not an Apptio key. Check what was pasted.")


class KeychainError(Exception):
    pass


class NoKey(KeychainError):
    """The item does not exist (security exit 44)."""

    def __init__(self) -> None:
        super().__init__(NO_KEY_MESSAGE)


class KeychainUnavailable(KeychainError):
    """Any other failure: locked, denied, timed out, or an unreadable item."""

    def __init__(self, message: str = UNAVAILABLE_MESSAGE) -> None:
        super().__init__(message)


class KeyTooLong(KeychainError):
    def __init__(self) -> None:
        super().__init__(KEY_TOO_LONG_MESSAGE)


class InvalidService(KeychainError, ValueError):
    def __init__(self) -> None:
        super().__init__(BAD_SERVICE_MESSAGE)


def service() -> str:
    """The Keychain service: `apptio-mcp`, or a validated test override."""
    override = os.environ.get("APPTIO_MCP_SERVICE")
    if not override or override == SERVICE:
        return SERVICE
    if not _TEST_SERVICE.fullmatch(override):
        raise InvalidService()
    return override


def _binary() -> str:
    """The fake `security` is honoured only together with a validated test service."""
    override = os.environ.get("APPTIO_MCP_SECURITY_BIN")
    if override and service() != SERVICE:
        return override
    return SECURITY_BIN


def _run(args: list[str], stdin: bytes | None = None, timeout: float = DEFAULT_TIMEOUT_S) -> bytes:
    """Run `security`; return stdout. Exit 44 -> NoKey; anything else non-zero, or a timeout -> KeychainUnavailable."""
    try:
        proc = subprocess.run(
            [_binary(), *args], input=stdin, capture_output=True, timeout=timeout, check=False,
        )
    except (subprocess.TimeoutExpired, OSError):
        raise KeychainUnavailable() from None
    if proc.returncode == _NOT_FOUND:
        raise NoKey()
    if proc.returncode != 0:
        raise KeychainUnavailable()
    return proc.stdout


def key_ok(*keys: object) -> bool:
    """A key is a non-empty plain-ASCII string of at most MAX_KEY_CHARS characters."""
    return all(isinstance(k, str) and 0 < len(k) <= MAX_KEY_CHARS and k.isascii() for k in keys)


def _budget(timeout: float, deadline: float | None) -> float:
    """The timeout for one `security` call: the usual one, capped to what is left of an overall deadline."""
    if deadline is None:
        return timeout
    left = deadline - time.monotonic()
    if left <= 0:
        raise KeychainUnavailable()
    return min(timeout, left)


def _encode(public_key: str, secret_key: str) -> str:
    raw = json.dumps({"public_key": public_key, "secret_key": secret_key}).encode("utf-8")
    # Unpadded: keeps "=" out of the `security -i` line.
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _decode(value: str) -> tuple[str, str]:
    try:
        raw = base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))
        data = json.loads(raw)
        public_key, secret_key = data["public_key"], data["secret_key"]
    except (binascii.Error, ValueError, KeyError, TypeError):
        raise KeychainUnavailable(UNREADABLE_MESSAGE) from None
    if not (isinstance(public_key, str) and isinstance(secret_key, str) and public_key and secret_key):
        raise KeychainUnavailable(UNREADABLE_MESSAGE)
    return public_key, secret_key


def _read_raw(timeout: float, deadline: float | None = None) -> str:
    out = _run(["find-generic-password", "-s", service(), "-a", ACCOUNT, "-w"], timeout=_budget(timeout, deadline))
    text = out.decode("utf-8", "replace")
    return text.removesuffix("\n")


def _write_raw(value: str, timeout: float, deadline: float | None = None) -> None:
    if not _B64URL.fullmatch(value):
        raise KeychainUnavailable(UNREADABLE_MESSAGE)
    line = f"add-generic-password -U -s {service()} -a {ACCOUNT} -w {value}\n"
    if len(line) >= MAX_LINE_CHARS:  # `security -i` would split it into two commands
        raise KeyTooLong()
    _run(["-i"], stdin=line.encode("ascii"), timeout=_budget(timeout, deadline))


def get(timeout: float = DEFAULT_TIMEOUT_S, deadline: float | None = None) -> tuple[str, str]:
    """Return (public_key, secret_key). Raises NoKey or KeychainUnavailable. `deadline` is an absolute
    time.monotonic() value that caps the call."""
    return _decode(_read_raw(timeout, deadline))


def exists(timeout: float = DEFAULT_TIMEOUT_S, deadline: float | None = None) -> bool:
    """Item present? Uses find-generic-password WITHOUT -w/-g, so no secret is requested or printed."""
    try:
        _run(["find-generic-password", "-s", service(), "-a", ACCOUNT], timeout=_budget(timeout, deadline))
    except NoKey:
        return False
    return True


def delete(timeout: float = DEFAULT_TIMEOUT_S, deadline: float | None = None) -> None:
    """Remove the item. Deleting a missing item is not an error."""
    try:
        _run(["delete-generic-password", "-s", service(), "-a", ACCOUNT], timeout=_budget(timeout, deadline))
    except NoKey:
        pass


def put(public_key: str, secret_key: str, timeout: float = DEFAULT_TIMEOUT_S, deadline: float | None = None) -> None:
    """Store the pair, verify it, and restore the previous state if verification fails. Every `security` call is
    capped to what is left of `deadline` (an absolute time.monotonic() value); the restore after a failure may run
    RESTORE_GRACE_S past it."""
    if not (isinstance(public_key, str) and isinstance(secret_key, str) and public_key and secret_key):
        raise ValueError("public_key and secret_key must be non-empty strings")
    if not key_ok(public_key, secret_key):
        raise KeyTooLong()
    value = _encode(public_key, secret_key)
    try:
        previous: str | None = _read_raw(timeout, deadline)
    except NoKey:
        previous = None
    try:
        _write_raw(value, timeout, deadline)
        try:
            present = exists(timeout, deadline)
            stored = _read_raw(timeout, deadline) if present else ""
        except NoKey:
            present, stored = False, ""
        if not present or not secrets.compare_digest(stored.encode(), value.encode()):
            raise KeychainUnavailable()
    except BaseException:
        _restore(previous, timeout, time.monotonic() + RESTORE_GRACE_S if deadline is not None else None)
        raise


def _restore(previous: str | None, timeout: float, deadline: float | None = None) -> None:
    try:
        if previous is None:
            delete(timeout, deadline)
        else:
            _write_raw(previous, timeout, deadline)
    except (KeychainError, ValueError):
        pass  # best effort: the original failure is the one to report
