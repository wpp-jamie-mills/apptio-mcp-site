"""Folders, modes and atomic writes. Every folder is 0700 and every file 0600."""
from __future__ import annotations

import os
import secrets
import threading
from pathlib import Path


def private_dir(path: Path) -> Path:
    """Create `path` (and parents) and force mode 0700 on it."""
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    os.chmod(path, 0o700)
    return path


def data_dir() -> Path:
    env = os.environ.get("APPTIO_MCP_DATA_DIR")
    return private_dir(Path(env) if env else Path.home() / "Library" / "Application Support" / "apptio-mcp")


def cache_dir() -> Path:
    env = os.environ.get("APPTIO_MCP_CACHE_DIR")
    return private_dir(Path(env) if env else Path.home() / "Library" / "Caches" / "apptio-mcp")


def atomic_write(path: Path, data: str | bytes) -> None:
    """Write via a unique O_EXCL 0600 temp file in the same folder, fsync, then os.replace."""
    path = Path(path)
    raw = data.encode("utf-8") if isinstance(data, str) else data
    tmp = path.parent / f".{path.name}.{os.getpid()}.{threading.get_ident()}.{secrets.token_hex(4)}"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(raw)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
