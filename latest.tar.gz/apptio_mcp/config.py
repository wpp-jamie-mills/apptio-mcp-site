"""Settings, read on every call: environment > settings.toml > defaults.toml (profile) > code default.

The only code defaults are Frontdoor EU and region us. There is no default view.
"""
from __future__ import annotations

import os
import re
import tomllib
from pathlib import Path

from .paths import data_dir

# Exact allow-list of Frontdoor origins. Only hosts verified with a real key are listed (the EU host was verified
# on 2026-11-24). To add another host, add one line below with a comment that cites where Apptio documents it;
# never add a host from a guess. The login call goes to the preferred host first and to the other listed hosts only
# when that host is unreachable.
FRONTDOOR_HOSTS = (
    "https://frontdoor-eu.apptio.com",
)
DEFAULT_FRONTDOOR = FRONTDOOR_HOSTS[0]
REGIONS = {
    "us": "https://api.cloudability.com/v3",
    "eu": "https://api-eu.cloudability.com/v3",
    "apac": "https://api-au.cloudability.com/v3",
    "me": "https://api-me.cloudability.com/v3",
}
DEFAULT_REGION = "us"
API_HOSTS = tuple(v.split("/v3")[0] for v in REGIONS.values())

ENV_NAMES = {
    "environment_id": "APPTIO_ENVIRONMENT_ID",
    "frontdoor_url": "APPTIO_FRONTDOOR_URL",
    "region": "CLOUDABILITY_REGION",
    "view_id": "CLOUDABILITY_VIEW_ID",
    "view_name": "CLOUDABILITY_VIEW_NAME",
    "show_owner_emails": "APPTIO_MCP_SHOW_OWNER_EMAILS",
    "check_updates": "APPTIO_MCP_CHECK_UPDATES",
}
CODE_DEFAULTS = {"frontdoor_url": DEFAULT_FRONTDOOR, "region": DEFAULT_REGION}

_PATTERNS = {
    "environment_id": re.compile(r"^[A-Za-z0-9_-]{1,64}$"),
    "view_id": re.compile(r"^[0-9]{1,12}$"),
    "view_name": re.compile(r"^[^\x00-\x1f\x7f-\x9f]{1,120}$"),
}
_BOOLS = {"show_owner_emails", "check_updates"}


class SettingError(ValueError):
    pass


def validate(name: str, value):
    """Return the cleaned value or raise SettingError (never echoes the value)."""
    if name in _BOOLS:
        if isinstance(value, bool):
            return value
        v = str(value).strip().lower()
        if v in ("1", "true", "yes", "on"):
            return True
        if v in ("0", "false", "no", "off"):
            return False
        raise SettingError(f"{name}: expected true or false")
    v = str(value).strip()
    if name == "frontdoor_url":
        if v.rstrip("/") not in FRONTDOOR_HOSTS:
            raise SettingError("frontdoor_url: not a known Apptio Frontdoor host")
        return v.rstrip("/")
    if name == "region":
        if v.lower() not in REGIONS:
            raise SettingError("region: not one of " + ", ".join(REGIONS))
        return v.lower()
    pat = _PATTERNS.get(name)
    if pat is None or not pat.match(v):
        raise SettingError(f"{name}: not a valid value")
    return v


def _read_toml(path: Path) -> dict:
    try:
        return tomllib.loads(path.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError):
        return {}


def settings_path() -> Path:
    return data_dir() / "settings.toml"


def defaults_path() -> Path:
    return data_dir() / "defaults.toml"


def lookup(name: str) -> tuple[object | None, str]:
    """Return (value, source) where source is environment|settings|profile|default|unset. Invalid values are skipped."""
    env = os.environ.get(ENV_NAMES.get(name, ""), "")
    if env:
        try:
            return validate(name, env), "environment"
        except SettingError:
            pass
    for path, src in ((settings_path(), "settings"), (defaults_path(), "profile")):
        raw = _read_toml(path).get(name)
        if raw is not None:
            try:
                return validate(name, raw), src
            except SettingError:
                continue
    if name in CODE_DEFAULTS:
        return CODE_DEFAULTS[name], "default"
    return None, "unset"


def get(name: str, default=None):
    value, _ = lookup(name)
    return default if value is None else value
