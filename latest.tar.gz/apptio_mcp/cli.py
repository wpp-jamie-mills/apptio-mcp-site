"""Command line: `apptio-mcp mcp | login | logout | status | mapping | spend-rules | config | defaults`.

No key ever goes on argv, and nothing printed here contains key material."""
from __future__ import annotations

import argparse
import getpass
import os
import sys
import tomllib
from pathlib import Path

from . import config, keychain, mapping, setup, spend_rules
from .paths import atomic_write

_PROFILE_FIELDS = ("frontdoor_url", "region", "view_id", "view_name")


# ── terminal access (replaced in tests) ──────────────────────────────────


def _tty_available() -> bool:
    # os.open, because Python 3.13 refuses a text-mode read-write open of the tty (it is not seekable).
    try:
        os.close(os.open("/dev/tty", os.O_RDWR))
        return True
    except OSError:
        return False


def _ask(prompt: str, secret: bool = False) -> str:
    """Prompt on the controlling terminal. Secrets are read with getpass (no echo)."""
    if secret:
        return getpass.getpass(prompt)
    with open("/dev/tty", "w") as out, open("/dev/tty") as inp:
        out.write(prompt)
        out.flush()
        return inp.readline().rstrip("\n")


def _out(text: str = "") -> None:
    print(text)


def _err(text: str) -> None:
    print(text, file=sys.stderr)


# ── commands ─────────────────────────────────────────────────────────────


def _cmd_mcp(args) -> int:
    setup.warn_ignored_env_keys()
    from .mcp_server import build_server  # lazy: the CLI works without the server's dependencies loaded

    build_server().run(transport="stdio")
    return 0


def _cmd_login(args) -> int:
    if args.stdin and args.from_env:
        _err("Use either --stdin or --from-env, not both.")
        return 2
    stdin_lines = None
    if args.stdin:
        if sys.stdin.isatty():
            _err("--stdin is refused on a terminal: the keys would echo into the screen and its history. "
                 "Pipe them in instead, for example: pbpaste | apptio-mcp login --stdin")
            return 2
        stdin_lines = [sys.stdin.readline(1024), sys.stdin.readline(1024)]  # a longer line fails the key length check
    try:
        result = setup.run_login(
            ask=_ask, environment_id=args.environment_id, view_id=args.view_id,
            accept_defaults=args.accept_defaults, from_env=args.from_env, stdin_lines=stdin_lines,
            no_verify=args.no_verify, interactive=_tty_available(),
        )
    except (KeyboardInterrupt, EOFError):
        _err("Cancelled. Nothing was changed.")
        return 1
    except Exception as e:  # noqa: BLE001 - never print str(e): it could carry something the user typed
        _err(f"Login failed unexpectedly ({type(e).__name__}). Nothing was stored.")
        return 1
    (_out if result["ok"] else _err)(result["message"])
    return 0 if result["ok"] else 1


def _cmd_logout(args) -> int:
    try:
        setup.logout()
    except keychain.KeychainError as e:
        _err("The local status, caches and pending setup tokens were removed, but the Keychain item was not: "
             + str(e))
        return 1
    _out("Signed out: the Keychain item, status, caches and pending setup tokens were removed.")
    _out("To revoke the key itself, use Apptio Access Administration.")
    return 0


def _yn(value: bool) -> str:
    return "yes" if value else "no"


def _cmd_status(args) -> int:
    st = setup.status()
    if args.installer:
        _out(f"complete={_yn(st.complete)}")
        _out(f"key_stored={_yn(st.key_stored)}")
        _out(f"missing={','.join(st.missing)}")
        _out(f"to_review={','.join(st.to_review)}")
        _out(f"settings_error={_yn(bool(st.settings_error))}")
        for name, source in st.sources.items():
            _out(f"{name}={source}")
        return 0
    _out("Setup: " + ("complete" if st.complete else "not finished"))
    _out(f"Key pair: {'stored in the macOS Keychain' if st.key_stored else 'not stored'}")
    if st.settings_error:
        _out(f"Problem: {st.settings_error} doesn't parse (the next save keeps a copy and starts afresh)")
    if st.missing:
        _out("Missing: " + ", ".join(st.missing))
    if st.to_review:
        _out("Defaults to review: " + ", ".join(st.to_review))
    _show_settings(st.sources)
    if not st.complete:
        _out(f"To finish: run `{setup.LOGIN_PATH}`")
    return 0


def _display(name: str, value) -> str:
    if value is None:
        return "(not set)"
    if name == "environment_id":
        return setup.mask_env_id(value)
    return str(value).lower() if isinstance(value, bool) else str(value)


def _show_settings(sources: dict | None = None) -> None:
    for name in setup.SETTING_NAMES:
        value, source = config.lookup(name)
        _out(f"  {name}: {_display(name, value)} ({source})")


def _abs(name: str) -> Path:
    return Path(name).expanduser().absolute()


def _cmd_mapping(args) -> int:
    if args.action == "show":
        info = mapping.show()
        if info.get("imported"):
            _out(f"Mapping file: {info['rows']} rows, {info['platforms']} platforms")
        else:
            _out("Mapping file: not imported" + (f" ({info['error']})" if info.get("error") else ""))
        return 0
    if args.action == "clear":
        _out("Mapping file removed." if mapping.clear()["removed"] else "No mapping file was imported.")
        return 0
    if not args.file:
        _err("mapping import needs a file.")
        return 2
    try:
        info = mapping.import_file(_abs(args.file))
    except mapping.MappingError as e:
        _err(str(e))
        return 1
    _out(f"Imported {info['rows']} rows ({info['platforms']} platforms).")
    return 0


def _cmd_spend_rules(args) -> int:
    if args.action == "show":
        info = spend_rules.show()
        if not info.get("present"):
            _out("Spend rules: using the built-in rules")
        elif info.get("error"):
            _out(f"Spend rules: imported but not usable ({info['error']})")
        else:
            _out("Spend rules: imported." + _ignored_text(info.get("ignored_keys")))
        return 0
    if args.action == "clear":
        _out("Spend rules removed; the built-in rules apply."
             if spend_rules.clear()["removed"] else "No spend rules were imported.")
        return 0
    if not args.file:
        _err("spend-rules import needs a file.")
        return 2
    try:
        info = spend_rules.import_file(_abs(args.file))
    except spend_rules.SpendRulesError as e:
        _err(f"Not imported: {e}")
        return 1
    _out("Imported the spend rules." + _ignored_text(info.get("ignored_keys")))
    return 0


def _ignored_text(names) -> str:
    return f" Not used: {', '.join(names)}." if names else ""


def _cmd_config(args) -> int:
    if args.action == "show":
        _show_settings()
        return 0
    if not (args.name and args.value is not None):
        _err("config set needs a name and a value.")
        return 2
    if args.name not in setup.SETTING_NAMES:
        _err("Unknown setting. Known: " + ", ".join(setup.SETTING_NAMES))
        return 2
    try:
        setup.write_settings({args.name: args.value})
    except config.SettingError as e:
        _err(str(e))
        return 1
    _out(f"Saved {args.name}.")
    return 0


def _read_profile(path: Path) -> dict:
    try:
        raw = tomllib.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError):
        raise config.SettingError("the profile could not be read") from None
    except tomllib.TOMLDecodeError:
        raise config.SettingError("the profile is not valid TOML") from None
    unknown = [k for k in raw if k not in _PROFILE_FIELDS]
    if unknown:
        raise config.SettingError("the profile has a field that isn't allowed; allowed: " + ", ".join(_PROFILE_FIELDS))
    values = {name: setup._clean(name, raw[name]) for name in _PROFILE_FIELDS if name in raw}
    if not values:
        raise config.SettingError("the profile has no fields")
    return values


def _cmd_defaults(args) -> int:
    path = config.defaults_path()
    if args.action == "show":
        if not path.exists():
            _out("No defaults profile imported.")
            return 0
        try:
            raw = tomllib.loads(path.read_text(encoding="utf-8"))
        except (OSError, tomllib.TOMLDecodeError):
            _err("The imported defaults file is unreadable; run `defaults clear`.")
            return 1
        for name in _PROFILE_FIELDS:
            if name in raw:
                _out(f"  {name}: {raw[name]}")
        return 0
    if args.action == "clear":
        path.unlink(missing_ok=True)
        _out("Defaults profile removed.")
        return 0
    if not args.file:
        _err("defaults import needs a file.")
        return 2
    try:
        values = _read_profile(Path(args.file))
        atomic_write(path, setup.dump_toml(values))
        setup.clear_review()
    except config.SettingError as e:
        _err(f"Not imported: {e}")
        return 1
    _out("Imported defaults: " + ", ".join(values))
    return 0


# ── parser ───────────────────────────────────────────────────────────────


def _parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="apptio-mcp", description="Apptio Cloudability MCP server and setup tools.")
    sub = p.add_subparsers(dest="command")
    sub.add_parser("mcp", help="run the MCP server on stdio (the default)").set_defaults(fn=_cmd_mcp)

    login = sub.add_parser("login", help="store the Apptio key pair and review the settings")
    login.add_argument("--stdin", action="store_true", help="read the public key then the secret key from stdin")
    login.add_argument("--from-env", action="store_true",
                       help="read APPTIO_PUBLIC_KEY, APPTIO_SECRET_KEY, APPTIO_ENVIRONMENT_ID from the environment")
    login.add_argument("--environment-id")
    login.add_argument("--view-id")
    login.add_argument("--accept-defaults", action="store_true", help="keep every default without asking")
    login.add_argument("--no-verify", action="store_true", help="skip the key check (marked unverified)")
    login.set_defaults(fn=_cmd_login)

    sub.add_parser("logout", help="remove the key, status and caches").set_defaults(fn=_cmd_logout)

    st = sub.add_parser("status", help="show setup status")
    st.add_argument("--installer", action="store_true", help="names and states only, one key=value per line")
    st.set_defaults(fn=_cmd_status)

    mp = sub.add_parser("mapping", help="import, show or clear the mapping file")
    mp.add_argument("action", choices=["import", "show", "clear"])
    mp.add_argument("file", nargs="?")
    mp.set_defaults(fn=_cmd_mapping)

    sr = sub.add_parser("spend-rules", help="import, show or clear the spend rules file (optional)")
    sr.add_argument("action", choices=["import", "show", "clear"])
    sr.add_argument("file", nargs="?")
    sr.set_defaults(fn=_cmd_spend_rules)

    cf = sub.add_parser("config", help="show or set a setting")
    cf.add_argument("action", choices=["show", "set"])
    cf.add_argument("name", nargs="?")
    cf.add_argument("value", nargs="?")
    cf.set_defaults(fn=_cmd_config)

    df = sub.add_parser("defaults", help="import, show or clear a defaults profile")
    df.add_argument("action", choices=["import", "show", "clear"])
    df.add_argument("file", nargs="?")
    df.set_defaults(fn=_cmd_defaults)
    return p


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    fn = getattr(args, "fn", _cmd_mcp)
    return fn(args)


if __name__ == "__main__":
    sys.exit(main())
