"""Import, validate and describe the owner's spend rules file (`spend.toml`).

It is optional: without it the built-in rules apply. A file is accepted only if the server could use it on every call
(the same merge and validation as `spend.load_config`). Keys the server ignores are not an error; their names are
returned so the owner can be told. Errors never contain file content, cell values or the path."""
from __future__ import annotations

import re
import tomllib
from pathlib import Path

from . import filepick, spend
from .paths import atomic_write, data_dir

MAX_BYTES = 256 * 1024
IMPORT_COMMAND = "~/.apptio-mcp/current/bin/apptio-mcp spend-rules import <file>"
IMPORT_HINT = f"Import it in the settings card (ask Claude to open Cloudability settings) or run: {IMPORT_COMMAND}"
_MAX_NAMES = 20
_MAX_NAME = 60
_REGEX_PROBLEM = re.compile(r"^(spend\.toml: invalid regex in environment_rules #\d+)")


class SpendRulesError(ValueError):
    """Fixed text naming the problem; never the content, a value or the path."""


def rules_path() -> Path:
    return data_dir() / spend.SPEND_TOML


def _safe_problem(exc: Exception) -> str:
    """The server's own message, except where it could echo a value (a regex error quotes the pattern)."""
    text = str(exc) if isinstance(exc, spend.SpendError) else ""
    hit = _REGEX_PROBLEM.match(text)
    if hit:
        return hit.group(1) + "."
    if not text or len(text) > 200 or "\n" in text:
        return "The spend rules aren't valid."
    return text if text.endswith(".") else text + "."


def _name(key: str) -> str:
    return "".join(c if c.isprintable() else "?" for c in key)[:_MAX_NAME]


def _check(text: str) -> list[str]:
    """Parse and validate `text` like the server does on every call. -> the names of ignored keys."""
    try:
        user = tomllib.loads(text)
    except tomllib.TOMLDecodeError:
        raise SpendRulesError("The spend rules file is not valid TOML.") from None
    try:
        data, notes = spend.merge_user_config(user)
        spend.parse_config(data)
    except Exception as exc:  # noqa: BLE001 - any failure here would also fail at call time
        raise SpendRulesError(_safe_problem(exc)) from None
    return [_name(n.removeprefix("Not used: ")) for n in notes][:_MAX_NAMES]


def _decode(raw: bytes | str) -> str:
    try:
        data = raw.encode("utf-8") if isinstance(raw, str) else raw
    except UnicodeEncodeError:
        raise SpendRulesError("The spend rules file is not valid UTF-8.") from None
    if len(data) > MAX_BYTES:
        raise SpendRulesError(f"The spend rules file is larger than {MAX_BYTES // 1024} KB.")
    try:
        return data.decode("utf-8-sig")  # strips a UTF-8 BOM, which tomllib would refuse
    except UnicodeDecodeError:
        raise SpendRulesError("The spend rules file is not valid UTF-8.") from None


def import_content(raw: bytes | str) -> dict:
    """Validate the content, store it verbatim atomically at 0600 in the data folder. -> {"ignored_keys": [...]}."""
    text = _decode(raw)
    ignored = _check(text)
    atomic_write(rules_path(), text)
    return {"ignored_keys": ignored}


def import_file(src: Path | str) -> dict:
    """Read the file at the absolute path `src`, then import its content."""
    try:
        raw = filepick.read_file(src, MAX_BYTES)
    except filepick.FilePickError as e:
        raise SpendRulesError(str(e)) from None
    return import_content(raw)


def show() -> dict:
    """{"present": false}, or {"present": true, "ignored_keys": [...]} or {"present": true, "error": "..."}."""
    try:
        raw = rules_path().read_bytes()
    except OSError:
        return {"present": False}
    try:
        return {"present": True, "ignored_keys": _check(_decode(raw))}
    except SpendRulesError as e:
        return {"present": True, "error": str(e)}


def clear() -> dict:
    """Remove the imported spend rules (the built-in rules apply again). -> {"removed": bool}."""
    try:
        rules_path().unlink()
    except FileNotFoundError:
        return {"removed": False}
    return {"removed": True}
