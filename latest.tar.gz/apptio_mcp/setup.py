"""Setup completeness, the gate error, login/logout and settings writes.

The card and `login` share this module: both verify before storing and write the same places.
No function here returns, logs or raises with key material."""
from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import shutil
import sys
import threading
import time
import tomllib
import unicodedata
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import urlsplit

from . import __version__, config, keychain, spend
from . import client as cloud
from .paths import atomic_write, data_dir

LOGIN_PATH = keychain.LOGIN_HINT
STORE_DEADLINE_S = 40.0
KEYCHAIN_STORE_TIMEOUT_S = 5.0
TITLE_MAX = 120
ENV_KEY_NAMES = ("APPTIO_PUBLIC_KEY", "APPTIO_SECRET_KEY")

_SETTING_STR = ("environment_id", "frontdoor_url", "region", "view_id", "view_name")
_SETTING_BOOL = ("show_owner_emails", "check_updates")
SETTING_NAMES = _SETTING_STR + _SETTING_BOOL
_REVIEW_LABEL = {"frontdoor_url": "Frontdoor", "region": "region", "view_id": "view"}
_STATUS_SETTINGS = ("environment_id", "frontdoor_url", "region", "view_id", "view_name")


class SetupIncomplete(RuntimeError):
    """Raised by get_client() when setup isn't finished; the message is the gate text (names only)."""


@dataclass(frozen=True)
class SetupStatus:
    complete: bool
    missing: list[str]
    to_review: list[str]
    key_stored: bool
    sources: dict[str, str]
    settings_error: str | None
    last_login: str | None = None


# ── small helpers ────────────────────────────────────────────────────────


def _now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


def _stamp() -> str:
    """A unique key-saved marker: microseconds plus a random nonce, so two saves in one instant still differ."""
    return datetime.now(UTC).isoformat(timespec="microseconds") + "-" + secrets.token_hex(3)


def mask_env_id(s: str) -> str:
    return "…" + str(s)[-4:]


def sanitize_title(title: object) -> str:
    """Strip Cc/Cf/Zl/Zp (and Cs), collapse whitespace, cut to 120 characters."""
    text = "".join(" " if c.isspace() else c for c in str(title or ""))
    text = "".join(c for c in text if unicodedata.category(c) not in ("Cc", "Cf", "Zl", "Zp", "Cs"))
    return " ".join(text.split())[:TITLE_MAX].strip()


_warned_env_keys = False


def warn_ignored_env_keys() -> None:
    """One stderr warning (names only) when the key pair sits in the environment: the server ignores it."""
    global _warned_env_keys
    if _warned_env_keys:
        return
    present = [n for n in ENV_KEY_NAMES if os.environ.get(n)]
    if present:
        _warned_env_keys = True
        print(f"apptio-mcp: ignoring {', '.join(present)} in the environment; the key is read from the macOS "
              f"Keychain only. Run `{LOGIN_PATH} --from-env` to store it.", file=sys.stderr)


# ── settings.toml ────────────────────────────────────────────────────────


def _settings_file() -> Path:
    return config.settings_path()


def _read_settings() -> tuple[dict, str | None]:
    """(parsed settings, error). A missing file is ({}, None)."""
    try:
        text = _settings_file().read_text(encoding="utf-8")
    except FileNotFoundError:
        return {}, None
    except UnicodeDecodeError:
        return {}, "settings.toml line 1"
    except OSError:
        return {}, "settings.toml"
    try:
        return tomllib.loads(text), None
    except tomllib.TOMLDecodeError as e:
        line = getattr(e, "lineno", None)
        if line is None:
            m = re.search(r"line (\d+)", str(e))
            line = int(m.group(1)) if m else None
        return {}, f"settings.toml line {line}" if line else "settings.toml"


def _clean(name: str, value):
    cleaned = config.validate(name, value)
    if isinstance(cleaned, str) and any(unicodedata.category(c) in ("Cc", "Cs") for c in cleaned):
        raise config.SettingError(f"{name}: contains a control character")
    return cleaned


def dump_toml(values: dict, reviewed: dict | None = None) -> str:
    """Render known settings as TOML (json.dumps strings), then prove it parses back to the same data."""
    lines = []
    expected: dict = {}
    for name in SETTING_NAMES:
        if name in values and values[name] is not None:
            lines.append(f"{name} = {json.dumps(values[name], ensure_ascii=False)}")
            expected[name] = values[name]
    if reviewed:
        lines.append("")
        lines.append("[setup_reviewed]")
        for key in ("at", "version"):
            lines.append(f"{key} = {json.dumps(str(reviewed[key]), ensure_ascii=False)}")
        expected["setup_reviewed"] = {"at": str(reviewed["at"]), "version": str(reviewed["version"])}
    text = "\n".join(lines) + "\n"
    try:
        ok = tomllib.loads(text) == expected
    except tomllib.TOMLDecodeError:
        ok = False
    if not ok:
        raise config.SettingError("the settings could not be written safely; nothing was saved")
    return text


def _save(values: dict, *, reviewed: bool = False, allow_owner_emails: bool = False, clear_cache: bool = True) -> list[str]:
    """Validate and write settings.toml atomically. A None value removes a key."""
    cleaned: dict = {}
    for name, value in values.items():
        if name not in SETTING_NAMES:
            raise config.SettingError("unknown setting")
        if name == "show_owner_emails" and not allow_owner_emails:
            raise config.SettingError("show_owner_emails can only be changed from the command line")
        if value is None and not allow_owner_emails and name != "view_name":
            raise config.SettingError(f"{name}: not a valid value")
        cleaned[name] = None if value is None else _clean(name, value)
    existing, error = _read_settings()
    path = _settings_file()
    if error is not None and path.exists():
        stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
        try:
            atomic_write(path.with_name(f"settings.toml.bad-{stamp}"), path.read_bytes())
        except OSError:
            pass
        existing = {}
    before_env = config.lookup("environment_id")[0], config.lookup("region")[0]
    merged = {k: v for k, v in existing.items() if k in SETTING_NAMES}
    for name, value in cleaned.items():
        if value is None:
            merged.pop(name, None)
        else:
            merged[name] = value
    review = existing.get("setup_reviewed") if isinstance(existing.get("setup_reviewed"), dict) else None
    if reviewed:
        review = {"at": _now(), "version": __version__}
    elif review is not None:
        review = {"at": review.get("at", _now()), "version": review.get("version", __version__)}
    atomic_write(path, dump_toml(merged, review))
    if clear_cache and before_env != (config.lookup("environment_id")[0], config.lookup("region")[0]):
        spend.clear_all_caches()
    return list(cleaned)


def save_settings(values: dict) -> list[str]:
    """Card path: validate, write atomically, return the saved names. Never touches show_owner_emails."""
    return _save(dict(values))


def write_settings(values: dict) -> list[str]:
    """CLI path (`config set`): like save_settings but allows every setting, including show_owner_emails."""
    return _save(dict(values), allow_owner_emails=True)


def record_review() -> None:
    _save({}, reviewed=True)


def clear_review() -> None:
    """Forget the first review (used when a defaults profile is imported), so the card asks again."""
    existing, error = _read_settings()
    if error is not None or "setup_reviewed" not in existing:
        return
    merged = {k: v for k, v in existing.items() if k in SETTING_NAMES}
    atomic_write(_settings_file(), dump_toml(merged, None))


# ── status.json ──────────────────────────────────────────────────────────


def _status_file() -> Path:
    return data_dir() / "status.json"


def _read_status() -> dict:
    try:
        data = json.loads(_status_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def fingerprint_of(public_key: str) -> str:
    """A short, one-way marker of the public key (a sha256 prefix, never the key). It names the cache folder and
    lets status code know which key is stored without reading the Keychain."""
    return hashlib.sha256(public_key.encode("utf-8")).hexdigest()[:16]


def _write_status(*, code: str, region: str | None, key_saved_at: str | None,
                  public_key: str | None = None) -> None:
    body = {"last_login": code, "region": region, "time": _now(), "key_saved_at": key_saved_at,
            "key_fingerprint": fingerprint_of(public_key) if public_key else None}
    atomic_write(_status_file(), json.dumps(body, indent=2) + "\n")


# ── completeness and the gate ────────────────────────────────────────────


def _key_exists() -> bool:
    try:
        return keychain.exists()
    except keychain.KeychainError:
        return False


def status() -> SetupStatus:
    """Completeness. No network."""
    parsed, error = _read_settings()
    key_stored = _key_exists()
    sources = {name: config.lookup(name)[1] for name in _STATUS_SETTINGS}
    reviewed = error is None and bool(parsed.get("setup_reviewed"))
    missing = []
    if not key_stored:
        missing.append("key pair")
    if sources["environment_id"] == "unset":
        missing.append("environment ID")
    if sources["view_id"] == "unset":
        missing.append("view")
    to_review: list[str] = []
    if not reviewed:
        for name in ("frontdoor_url", "region", "view_id"):
            # Anything not from the environment needs the first review, including values a key check just
            # saved to settings.toml (those must not look "already reviewed").
            if sources[name] not in ("environment", "unset"):
                to_review.append(_REVIEW_LABEL[name])
    complete = not missing and not to_review and error is None
    last = _read_status().get("last_login")
    return SetupStatus(complete, missing, to_review, key_stored, sources, error,
                       last if isinstance(last, str) else None)


def gate_error(cards: bool) -> str | None:
    st = status()
    if st.complete:
        return None
    parts = []
    if st.settings_error:
        parts.append(f"{st.settings_error} doesn't parse")
    if st.missing:
        parts.append("missing: " + ", ".join(st.missing))
    if st.to_review:
        parts.append("defaults to review: " + ", ".join(st.to_review))
    head = f"Cloudability setup isn't finished ({'; '.join(parts)})."
    if cards:
        return (f"{head} Call cloudability_settings to open the setup card. When the owner has finished it and "
                "sends their next message, call this tool again with the same arguments.")
    return f"{head} Run `{LOGIN_PATH}` in Terminal, then call this tool again with the same arguments."


# ── key and client (server side) ─────────────────────────────────────────


@dataclass
class _State:
    lock: threading.RLock = field(default_factory=threading.RLock)
    key: tuple[str, str] | None = field(default=None, repr=False)
    key_saved_at: str | None = field(default=None, repr=False)
    client: object | None = field(default=None, repr=False)
    sig: tuple | None = field(default=None, repr=False)


_state = _State()


def reset_cache() -> None:
    with _state.lock:
        _state.key = _state.client = _state.sig = None
        _state.key_saved_at = None


def _read_key() -> tuple[str, str]:
    try:
        return keychain.get()
    except keychain.NoKey:
        return keychain.get()  # one more read, then NoKey propagates


def _key() -> tuple[str, str]:
    """The cached key pair; re-read from the Keychain when status.json's key_saved_at changed."""
    saved = _read_status().get("key_saved_at")
    with _state.lock:
        if _state.key is None or _state.key_saved_at != saved:
            _state.key = _read_key()
            _state.key_saved_at = saved
        return _state.key


def _reload_key() -> tuple[str, str]:
    """After a 401: forget the cached pair and read the Keychain again, once."""
    with _state.lock:
        _state.key = None
        _state.key_saved_at = None
        return _key()


def current_settings(*, allow_key_read: bool = True) -> spend.SpendSettings:
    """The settings as `spend` needs them. The key fingerprint comes from status.json; only when that has none and
    `allow_key_read` is true is the key read from the Keychain (status code passes False and never reads it)."""
    stored = _read_status().get("key_fingerprint")
    fingerprint = stored if isinstance(stored, str) else ""
    if not fingerprint and allow_key_read:
        try:
            fingerprint = fingerprint_of(_key()[0])
        except keychain.KeychainError:
            fingerprint = ""
    view = config.get("view_id")
    return spend.SpendSettings(
        view_id=int(view) if view else None,
        view_name=config.get("view_name", "") or "",
        environment_id=config.get("environment_id", "") or "",
        region=config.get("region", config.DEFAULT_REGION),
        public_key_fingerprint=fingerprint,
    )


def get_client() -> cloud.CloudabilityClient:
    warn_ignored_env_keys()
    env_id = config.get("environment_id")
    if not env_id:
        raise SetupIncomplete(gate_error(False) or "Cloudability setup isn't finished.")
    frontdoor = config.get("frontdoor_url", config.DEFAULT_FRONTDOOR)
    region = config.get("region", config.DEFAULT_REGION)
    view = config.get("view_id")
    with _state.lock:
        key = _key()
        sig = (_state.key_saved_at, env_id, frontdoor, region, hashlib.sha256(key[0].encode()).hexdigest())
        if _state.client is None or _state.sig != sig:
            cfg = cloud.CloudabilityConfig(public_key=key[0], secret_key=key[1], environment_id=env_id,
                                           frontdoor_url=frontdoor, region=region)
            _state.client = cloud.CloudabilityClient(cfg, key_reloader=_reload_key)
            _state.sig = sig
        _state.client.default_view_id = str(view) if view else None
        return _state.client


# ── login / logout ───────────────────────────────────────────────────────


class _Abort(Exception):
    pass


def _fail(code: str, message: str) -> dict:
    return {"ok": False, "stored": False, "code": code, "message": message + " Nothing was changed."}


def _verify_message(res, env_id: str) -> str:
    mask = mask_env_id(env_id)
    hosts = ", ".join(res.hosts_tried)
    if res.status == "rejected":
        if res.frontdoor_host is None:
            host = urlsplit(res.hosts_tried[0]).hostname if res.hosts_tried else None
            return (f"Apptio rejected the key pair at {host or 'the Frontdoor host'}: check the public and secret "
                    "keys, and that this is the right Frontdoor host.")
        return f"Cloudability rejected environment {mask}: check the environment ID."
    if res.status == "unexpected_redirect":
        return "Apptio answered with an unexpected redirect."
    if res.status == "region_unproven":
        return f"Couldn't tell which region environment {mask} is in."
    if res.frontdoor_host is None:
        return f"Couldn't reach Apptio (tried: {hosts})."
    return f"Can't reach environment {mask} (regions tried: {', '.join(res.regions_tried)})."


def _choose(label: str, current: str, tag: str, ask, validate_name: str) -> str:
    answer = ask(f"{label} [{tag}: {current}]: ", secret=False).strip()
    return config.validate(validate_name, answer) if answer else current


def _choose_view(views: tuple, preselect: str | None, ask) -> str:
    print("Views visible to this key:", file=sys.stderr)
    for i, v in enumerate(views, 1):
        print(f"  {i}. {sanitize_title(v['title']) or '(untitled)'} ({v['id']})", file=sys.stderr)
    ids = [v["id"] for v in views]
    default_no = ids.index(preselect) + 1 if preselect in ids else None
    hint = f" or Return for {default_no}" if default_no else ""
    for _ in range(3):
        answer = ask(f"View number{hint}: ", secret=False).strip()
        if not answer and default_no:
            return preselect  # type: ignore[return-value]
        if answer.isdigit() and 1 <= int(answer) <= len(ids):
            return ids[int(answer) - 1]
        if answer in ids:
            return answer
    raise _Abort(_fail("no_view", "No view was chosen."))


def run_login(*, ask, environment_id, view_id, accept_defaults, from_env, stdin_lines, no_verify, interactive) -> dict:
    """Verify, then store key, settings and status. Returns a result dict; never any key material."""
    try:
        return _login(ask, environment_id, view_id, accept_defaults, from_env, stdin_lines, no_verify, interactive)
    except _Abort as e:
        return e.args[0]
    except config.SettingError as e:
        return _fail("invalid_setting", str(e))
    except keychain.KeychainError as e:
        return _fail("keychain", str(e))


def _login(ask, environment_id, view_id, accept_defaults, from_env, stdin_lines, no_verify, interactive) -> dict:
    deadline = [time.monotonic() + STORE_DEADLINE_S]
    ask_orig = ask

    def ask(prompt, secret=False):
        started = time.monotonic()
        try:
            return ask_orig(prompt, secret=secret)
        finally:
            deadline[0] += time.monotonic() - started

    def remaining() -> float:
        left = deadline[0] - time.monotonic()
        if left <= 0:
            raise _Abort(_fail("timeout", "The 40 second limit passed."))
        return left

    if not interactive and not accept_defaults:
        return _fail("no_terminal", "There is no terminal to ask in; pass --accept-defaults to keep the defaults "
                     "without asking.")
    prompts = interactive and not accept_defaults

    # keys
    if stdin_lines is not None:
        lines = [ln.strip() for ln in stdin_lines if ln.strip()]
        if len(lines) < 2:
            return _fail("no_key", "Expected the public key on the first line and the secret key on the second.")
        public, secret = lines[0], lines[1]
    elif from_env:
        public = os.environ.get("APPTIO_PUBLIC_KEY", "").strip()
        secret = os.environ.get("APPTIO_SECRET_KEY", "").strip()
        if not (public and secret):
            return _fail("no_key", "APPTIO_PUBLIC_KEY and APPTIO_SECRET_KEY must both be set.")
        environment_id = environment_id or os.environ.get("APPTIO_ENVIRONMENT_ID") or None
    else:
        public = ask("Apptio public key: ", secret=True).strip()
        secret = ask("Apptio secret key: ", secret=True).strip()
        if not (public and secret):
            return _fail("no_key", "Both keys are needed.")

    if not keychain.key_ok(public, secret):
        return _fail("key_too_long", keychain.KEY_TOO_LONG_MESSAGE)

    # environment ID, Frontdoor, region
    current_env = config.get("environment_id")
    if environment_id:
        env_id = config.validate("environment_id", environment_id)
    elif interactive and (prompts or not current_env):
        suffix = f" [current: {mask_env_id(current_env)}]" if current_env else ""
        answer = ask(f"Environment ID{suffix}: ", secret=False).strip()
        env_id = config.validate("environment_id", answer) if answer else current_env
    else:
        env_id = current_env
    if not env_id:
        return _fail("no_environment", "An environment ID is needed (--environment-id).")
    frontdoor, fd_src = config.lookup("frontdoor_url")
    region, rg_src = config.lookup("region")
    if prompts:
        frontdoor = _choose("Frontdoor", frontdoor, "default" if fd_src in ("default", "profile") else "current",
                            ask, "frontdoor_url")
        region = _choose("Region", region, "default" if rg_src in ("default", "profile") else "current",
                         ask, "region")

    # verify
    views: tuple = ()
    verified = not no_verify
    if verified:
        res = cloud.verify_key(public, secret, env_id, frontdoor, region, deadline_s=remaining())
        if not res.ok:
            return _fail(res.code or res.status, _verify_message(res, env_id))
        frontdoor, region, views = res.frontdoor_host or frontdoor, res.region or region, tuple(res.views)

    # view
    current_view = config.lookup("view_id")[0]
    profile_view = config.validate("view_id", _profile_value("view_id")) if _profile_value("view_id") else None
    if view_id:
        chosen = config.validate("view_id", view_id)
        if verified and chosen not in {v["id"] for v in views}:
            return _fail("view_not_visible", "That view isn't visible to this key.")
    elif verified:
        ids = [v["id"] for v in views]
        preselect = next((x for x in (current_view, profile_view) if x in ids), ids[0] if len(ids) == 1 else None)
        if prompts and views:
            chosen = _choose_view(views, preselect, ask)
        elif preselect:
            chosen = preselect
        else:
            return _fail("no_view", "No view could be chosen: pass --view-id, import a profile, or use a key that "
                         "sees exactly one view.")
    else:
        chosen = current_view
        if not chosen:
            return _fail("no_view", "--no-verify needs --view-id or an imported profile.")
    if verified:
        title = next((v["title"] for v in views if v["id"] == chosen), "")
        view_name = sanitize_title(title)
    else:
        view_name = sanitize_title(config.get("view_name", ""))

    # store
    prev_env, prev_region = current_env, config.get("region")
    prev_public = None
    try:
        prev_key = keychain.get(timeout=KEYCHAIN_STORE_TIMEOUT_S, deadline=deadline[0])
        prev_public = prev_key[0]
    except keychain.NoKey:
        prev_key = None
    settings_file, status_file = _settings_file(), _status_file()
    prev_settings = settings_file.read_bytes() if settings_file.exists() else None
    prev_status = status_file.read_bytes() if status_file.exists() else None
    saved_at = _stamp()
    keychain.put(public, secret, timeout=KEYCHAIN_STORE_TIMEOUT_S, deadline=deadline[0])
    try:
        remaining()
        values = {"environment_id": env_id, "frontdoor_url": frontdoor, "region": region, "view_id": chosen,
                  "view_name": view_name or None}
        saved = _save(values, reviewed=True, allow_owner_emails=True, clear_cache=False)
        _write_status(code="unverified" if no_verify else "ok", region=region, key_saved_at=saved_at,
                      public_key=public)
    except BaseException:
        _restore(prev_key, prev_settings, prev_status, settings_file, status_file)
        raise
    if (prev_env, prev_region, prev_public) != (env_id, region, public):
        spend.clear_all_caches()
    reset_cache()
    parts = [f"Saved: {', '.join(saved)}." if saved else "Saved."]
    parts.append("The key was not checked (--no-verify)." if no_verify else "The key was checked and stored in the "
                 "macOS Keychain.")
    return {"ok": True, "stored": True, "verified": verified, "code": "unverified" if no_verify else "ok",
            "message": " ".join(parts), "saved": saved, "region": region, "frontdoor_url": frontdoor,
            "view_id": chosen, "view_name": view_name, "environment": mask_env_id(env_id)}


# ── card helpers (cloudability_settings / save_settings) ────────────────


def verify_message(res, env_id: str) -> str:
    """The fixed text for a failed verify (no key material, no response text)."""
    return _verify_message(res, env_id)


def fail_result(code: str, message: str) -> dict:
    return _fail(code, message)


def save_reviewed_settings(values: dict, *, reviewed: bool = False) -> list[str]:
    """Card path with an optional review stamp: like save_settings, and `reviewed` also records setup_reviewed."""
    return _save(dict(values), reviewed=reviewed)


def preselect_view(views) -> tuple[str | None, str]:
    """(view id, source) to preselect from a listed set: the current value if listed; a profile's view if
    listed; (the person's own Cloudability default is not available); the only view; else (None, 'unset')."""
    ids = [v["id"] for v in views]
    current, source = config.lookup("view_id")
    if current in ids:
        return str(current), source
    raw = _profile_value("view_id")
    try:
        profile_view = config.validate("view_id", raw) if raw else None
    except config.SettingError:
        profile_view = None
    if profile_view in ids:
        return str(profile_view), "profile"
    if len(ids) == 1:
        return ids[0], "unset"
    return None, "unset"


def stored_key_views(timeout: float = 10.0) -> tuple[tuple | None, str | None]:
    """List the views using the stored key in this process only (never returned or logged).
    Returns (views, None) or (None, fixed reason)."""
    box: dict = {}

    def work() -> None:
        try:
            box["views"] = cloud._parse_views(get_client().get_views())
        except BaseException as exc:  # noqa: BLE001 - reduced to a fixed reason below
            box["error"] = exc

    thread = threading.Thread(target=work, daemon=True)
    thread.start()
    thread.join(timeout)
    if thread.is_alive():
        return None, "timed out"
    exc = box.get("error")
    if exc is None:
        return box.get("views", ()), None
    if isinstance(exc, SetupIncomplete):
        return None, "setup isn't finished"
    if isinstance(exc, keychain.KeychainError):
        return None, "the Keychain wouldn't give up the key"
    if isinstance(exc, cloud.CloudabilityAuthError):
        return None, "Apptio rejected the stored key"
    return None, "Cloudability didn't answer"


def verify_stored_key(env_id: str, frontdoor: str, region: str, deadline_s: float = STORE_DEADLINE_S):
    """Run verify_key with the key from the Keychain (read into memory, never returned). Raises KeychainError."""
    public, secret = keychain.get(timeout=min(KEYCHAIN_STORE_TIMEOUT_S, deadline_s))
    return cloud.verify_key(public, secret, env_id, frontdoor, region, deadline_s=deadline_s)


def check_and_store_key(public: str, secret: str, env_id: str, frontdoor: str, region: str,
                        deadline_s: float = STORE_DEADLINE_S) -> dict:
    """Card path: verify within one deadline, then store key, environment ID, Frontdoor and region (not reviewed)
    and status.json. Nothing is stored on failure. Returns {ok, code, message, views, frontdoor_url, region}."""
    deadline = time.monotonic() + deadline_s
    if not keychain.key_ok(public, secret):
        out = _fail("key_too_long", keychain.KEY_TOO_LONG_MESSAGE)
        out["views"] = ()
        return out
    res = cloud.verify_key(public, secret, env_id, frontdoor, region, deadline_s=deadline_s)
    if not res.ok:
        out = _fail(res.code or res.status, _verify_message(res, env_id))
        out["views"] = ()
        return out
    frontdoor, region, views = res.frontdoor_host or frontdoor, res.region or region, tuple(res.views)
    try:
        prev_key = None
        prev_public = None
        try:
            prev_key = keychain.get(timeout=KEYCHAIN_STORE_TIMEOUT_S, deadline=deadline)
            prev_public = prev_key[0]
        except keychain.NoKey:
            pass
        prev_env, prev_region = config.get("environment_id"), config.get("region")
        settings_file, status_file = _settings_file(), _status_file()
        prev_settings = settings_file.read_bytes() if settings_file.exists() else None
        prev_status = status_file.read_bytes() if status_file.exists() else None
        if time.monotonic() > deadline:
            out = _fail("timeout", "The 40 second limit passed.")
            out["views"] = ()
            return out
        saved_at = _stamp()
        keychain.put(public, secret, timeout=KEYCHAIN_STORE_TIMEOUT_S, deadline=deadline)
        try:
            _save({"environment_id": env_id, "frontdoor_url": frontdoor, "region": region}, clear_cache=False)
            _write_status(code="ok", region=region, key_saved_at=saved_at, public_key=public)
        except BaseException:
            _restore(prev_key, prev_settings, prev_status, settings_file, status_file)
            raise
    except keychain.KeychainError as e:
        out = (_fail("timeout", "The 40 second limit passed.") if time.monotonic() > deadline
               else _fail("keychain", str(e)))
        out["views"] = ()
        return out
    except config.SettingError as e:
        out = _fail("invalid_setting", str(e))
        out["views"] = ()
        return out
    if (prev_env, prev_region, prev_public) != (env_id, region, public):
        spend.clear_all_caches()
    reset_cache()
    return {"ok": True, "stored": True, "code": "ok", "message": "The key was checked and stored in the macOS "
            "Keychain.", "views": views, "frontdoor_url": frontdoor, "region": region}


def _restore(prev_key, prev_settings, prev_status, settings_file: Path, status_file: Path) -> None:
    """Best effort: put every store step back so the key and settings never disagree."""
    for path, raw in ((settings_file, prev_settings), (status_file, prev_status)):
        try:
            if raw is None:
                path.unlink(missing_ok=True)
            else:
                atomic_write(path, raw)
        except OSError:
            pass
    grace = time.monotonic() + keychain.RESTORE_GRACE_S  # bounded: a restore never runs unbounded past the deadline
    try:
        if prev_key is None:
            keychain.delete(timeout=KEYCHAIN_STORE_TIMEOUT_S, deadline=grace)
        else:
            keychain.put(*prev_key, timeout=KEYCHAIN_STORE_TIMEOUT_S, deadline=grace)
    except (keychain.KeychainError, ValueError):
        pass


def _profile_value(name: str):
    try:
        return tomllib.loads(config.defaults_path().read_text(encoding="utf-8")).get(name)
    except (OSError, tomllib.TOMLDecodeError):
        return None


def _clear_local() -> None:
    folder = data_dir()
    for name in ("status.json", "session.json"):
        try:
            (folder / name).unlink(missing_ok=True)
        except OSError:
            pass
    tokens = folder / "settings-tokens"
    if tokens.is_dir() and not tokens.is_symlink():
        shutil.rmtree(tokens, ignore_errors=True)
    try:
        spend.clear_all_caches()
    finally:
        reset_cache()


def logout() -> None:
    """Delete status.json, session.json, settings-tokens/ and the caches first, then the Keychain item. A Keychain
    error is still raised (the caller reports it), but only after every local file is gone."""
    try:
        _clear_local()
    finally:
        keychain.delete()


def is_reviewed() -> bool:
    """True once a Save or a finished login recorded setup_reviewed (and settings.toml parses)."""
    parsed, error = _read_settings()
    return error is None and bool(parsed.get("setup_reviewed"))
