"""Built-in spend rules. An optional `spend.toml` in the data folder may override only these tables:
`[cache]`, `[[environment_rules]]` and `[categories]`. Nothing here is secret or specific to one person."""
from __future__ import annotations

DEFAULT_METRIC = "total_amortized_cost"  # amortised, net of credits, incl. tax/recurring/one-time

CACHE = {
    "current_month_hours": 6,
    "previous_month_hours": 24,
    "older_month_days": 30,  # closed months older than the previous month
    "view_index_hours": 168,  # 7 days; a stale index is served while a background refresh runs
    "provisional_lag_days": 3,  # data fetched within this many days of a period end is provisional
}

# Matched against the project name. First match wins. The final rule must be the default.
ENVIRONMENT_RULES = [
    {"pattern": r"(^|-)(prd|prod)(-|$)", "env": "Production"},
    {"pattern": r"(^|-)(dev|test|stg)(-|$)", "env": "Non-production"},
    {"default": True, "env": "Unclassified"},
]

# Overrides are checked before ATUM. "AI" is not a label in the billing data, so it is derived from the GCP
# service names below.
CATEGORIES = {
    "base": "atum_service_category",  # or atum_service_type / atum_service_name
    "unset_label": "Unclassified",  # used when the ATUM field is "(not set)"
    "overrides": [
        {
            "name": "AI",
            "vendor": "GCP",
            "service_name": ["GCP Vertex AI", "GCP Gemini API", "GCP Vertex AI Search",
                             "GCP Gemini Data Analytics"],
        },
    ],
}

# The only keys a spend.toml may hold, and the keys allowed inside the two tables.
ALLOWED_TOP = ("cache", "environment_rules", "categories")
ALLOWED_CACHE = tuple(CACHE)
ALLOWED_CATEGORIES = ("base", "unset_label", "overrides")


def defaults() -> dict:
    """A fresh, mutable copy of the built-in configuration, shaped like a parsed spend.toml."""
    import copy

    return copy.deepcopy({
        "metric": DEFAULT_METRIC,
        "cache": CACHE,
        "environment_rules": ENVIRONMENT_RULES,
        "categories": CATEGORIES,
    })
